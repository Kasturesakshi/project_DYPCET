<?php
// Database connection parameters
$servername = "localhost:3307"; // Change this if your MySQL server is hosted elsewhere
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "user_registration"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process registration form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile_number = $_POST['mobile_number'];
    $city = $_POST['city'];
    $event = $_POST['event'];
    $book_the_event = $_POST['book_the_event'];
    $decoration = $_POST['decoration'];
    $e_invite_card = $_POST['e_invite_card'];
    
    $message = $_POST['message'];
    $status = $_POST['status'];
  

    $sql = "INSERT INTO booking_form (name, email, mobile_number, city, event, book_the_event, decoration, e_invite_card, message,status) 
        VALUES ('$name', '$email', '$mobile_number', '$city', '$event', '$book_the_event', '$decoration', '$e_invite_card', '$message','$status')";
 
$stmt = $conn->prepare($sql);
//$stmt->bind_param("sssssssss", $name, $email, $mobile_number, $city, $event, $book_the_event, $decoration, $e_invite_card, $message,$status);
$stmt->execute();


    // Execute SQL statement
    if ($stmt->execute()) {
        echo "Booking successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close statement
    $stmt->close();
}

// Close database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking wedding</title>
    <style>
        .booking-form {
    width: 500px;
    margin: 0 auto;
    padding: 50px;
    background:skyblue;
    background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://tse3.mm.bing.net/th?id=OIP.LI7Qxss3dia7t7bRmFO-8QAAAA&pid=Api&P=0&h=180");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 190vh;
            width: 100vh;
  }
  
  div.elem-group {
    margin: 20px 0;
  }
  
  div.elem-group.inlined {
    width: 49%;
    display: inline-block;
    float: left;
    margin-left: 1%;
  }
  
  label {
    display: block;
    font-family: 'Nanum Gothic';
    padding-bottom: 10px;
    font-size: 1.25em;
  }
  
  input, select, textarea {
    border-radius: 2px;
    border: 2px solid #777;
    box-sizing: border-box;
    font-size: 1.25em;
    font-family: 'Nanum Gothic';
    width: 100%;
    padding: 10px;
  }
  
  div.elem-group.inlined input {
    width: 95%;
    display: inline-block;
  }
  
  textarea {
    height: 250px;
  }
  
  hr {
    border: 1px dotted #ccc;
  }
  
  button {
    height: 50px;
    background:blueviolet;
    border: none;
    color: white;
    font-size: 1.25em;
    font-family: 'Nanum Gothic';
    border-radius: 4px;
    cursor: pointer;
    padding: 0 12px;
  }
  
  button:hover {
    background: #333;
  }
    </style>

    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Nanum+Gothic'>

</head>
<body>
    <form class="booking-form" action="book.php" method="post">
        <h1>Booking all the events</h1>
         
        <div class="elem-group">
          <label for="name">Your Name</label>
          <input type="text" id="name" name="name" placeholder="John Doe" pattern=[A-Z\sa-z]{3,20} required>
        </div>
         
        <div class="elem-group">
          <label for="email">Your E-mail</label>
          <input type="email" id="email" name="email" placeholder="john.doe@email.com" required>
        </div>
        <div class="elem-group">
          <label for="mobile_number">Your mobile number</label>
          <input type="tel" id="mobile_number" name="mobile_number" placeholder="498-348-3872" pattern=(\d{3})-?\s?(\d{3})-?\s?(\d{4}) required>
        </div>
        <hr>
        
        <div class="elem-group">
            <label for="city">City</label>
            <input type="text" id="city" name="city" placeholder="sangli" pattern=[A-Z\sa-z]{3,20} required>
        </div>

        <div class="elem-group">
            <label for="event">Select event</label>
            <select id="event" name="event" required>
                <option value="">Choose a event from the List</option>
                 
                <option value="Wedding">Wedding</option>
                <option value="holi">Holi</option>
                <option value="dance">Dance Compition</option>
                <option value="Naming Ceromony">Naming Ceromony</option>
            
            </select>
          </div>

        <div class="elem-group">
          <label for="book the event">book the event</label>
          <input type="date" id="book_the_event" name="book_the_event" required>
        </div>
         
        <div class="elem-group">
          <label for="decoration">Select decoration</label>
          <select id="decoration" name="decoration" required>
              <option value="">Choose a decoration from the List</option>
              <option value="decoration 1">decoration 1</option>
              <option value="decoration 2">decoration 2</option>
              <option value="decoration 3">decoration 3</option>
              <option value="decoration 4">decoration 4</option>
              <option value="decoration 5">decoration 5</option>
              <option value="decoration 6">decoration 6</option>
              <option value="decoration 7">decoration 7</option>
              <option value="decoration 8">decoration 8</option>
          </select>
        </div>

        <div class="elem-group">
            <label for="e_invite card">Select e-invite card</label>
            <select id="e_invite_card" name="e_invite_card" required>
                <option value="">Choose a e-invite card</option>
                <option value="e-invite card 1">e-invite card 1</option>
                <option value="e-invite card 2">e-invite card 2</option>
                <option value="e-invite card 3">e-invite card 3</option>
                <option value="e-invite card 4">e-invite card 4</option>
                <option value="e-invite card 5">e-invite card 5</option>
                <option value="e-invite card 6">e-invite card 6</option>
                <option value="e-invite card 7">e-invite card 7</option> 
                <option value="e-invite card 8">e-invite card 8</option>
                <option value="e-invite card 9">e-invite card 9</option>
                 
            </select>
          </div>
        <hr>

        
        <div class="elem-group">
          <label for="message">Anything Else?</label>
          <textarea id="message" name="message" placeholder="Tell us anything else that might be important." required></textarea>
        </div>

        <div class="elem-group">
          <label for="status">status</label>
          <input type="text" id="status" name="status" placeholder="status" pattern=[A-Z\sa-z]{3,20} required>
      </div>

        <button type="submit">Book The Event</button>
      </form>

<script>
    var currentDateTime = new Date();
var year = currentDateTime.getFullYear();
var month = (currentDateTime.getMonth() + 1);
var date = (currentDateTime.getDate() + 1);

if(date < 10) {
  date = '0' + date;
}
if(month < 10) {
  month = '0' + month;
}

var dateTomorrow = year + "-" + month + "-" + date;
var checkinElem = document.querySelector("#checkin-date");
var checkoutElem = document.querySelector("#checkout-date");

checkinElem.setAttribute("min", dateTomorrow);

checkinElem.onchange = function () {
    checkoutElem.setAttribute("min", this.value);
}
</script>
    
</body>
</html>