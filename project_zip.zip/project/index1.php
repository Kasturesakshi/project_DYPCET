<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fontawesome-iconpicker/3.2.0/js/fontawesome-iconpicker.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    
    <style>
         
:root{
    --main-color:#3867d6;
}
*{
    margin: 0;
    padding: 0;
    
    box-sizing: border-box;
    outline: none;
    border: none;
    text-transform: capitalize;
    text-decoration: none;
    transition: .2s linear;
}

html{
    font-size: 62.5%;
    overflow-x:hidden ;
    scroll-padding-top: 7rem;
    scroll-behavior: smooth;
}
html::-webkit-scrollbar{
    width: 1rem;
}
html::-webkit-scrollbar-track{
    background: #444;
}
html::-webkit-scrollbar-thumb{
    background: var(--main-color);
    border-radius: 5rem;
}
body{
    background: #222;
}
section{
    padding: 2rem 9%;
}

/*service*/
.heading{
    text-align: center;
    padding-bottom:2rem ;
    color: #fff;
    text-transform: uppercase;
    font-size: 4rem;
}

.heading span{
    color:var(--main-color);
    text-transform: uppercase;
}

.btn{
    margin-top: 1rem;
    display: inline-block;
    padding: 8rem 3rem;
    font-size: 1.7rem;
    background: #666;
    color: #333;
    cursor: #fff;
    font-weight: 600;
}
.btn:hover{
    background: var(--main-color);
}

header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 10000;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1.2rem 9%;
    
    background-position: center;
    background-size: cover;
    position: relative;
    min-height: 100vh;
    width: 100%;
    text-align: center;
    text-decoration: underline;
    

    background: #e4e9f7;
            background: url('image/homeimg.png') no-repeat;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
}
 
img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100;
    height: 100;
    
}

.navbar {
    position: absolute;
    top: 0;
    right: 0;
    color:black;
   
    padding: 1.2rem 9%;/* Adjust padding as needed */
}

.navbar a {
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 30px;
    color: black; 
    /* Set text color */
}

.navbar a:hover {
    background-color: #ddd;
    color: black;
}

.navbar a.active {
    background-color: #04aa6d;
    color: white;
}


 
 /*service*/
.Events .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Events .box-container .box{
    border-radius: .5rem;
    background: #333;
    text-align: center;
    padding: 2.5rem;
}
.Events .box-container .box i{
    height: 6rem;
    width: 6rem;
    line-height: 6rem;
    border-radius: 50%;
    font-size: 2.5rem;
    background: var(--main-color);
    color: #fff;
}
.Events .box-container .box h3{
    font-size: 2rem;
    color: #fff;
    padding: 1rem;
}
.Events .box-container .box p{
    font-size: 1.4rem;
    color: #eee;
    line-height: 1.8;
}


/*gallery section   like ch option nahi yet*/
.Gallery .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Gallery .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 25rem;
    cursor: pointer;
    overflow: hidden;
}
.Gallery .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Gallery .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Gallery .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Gallery .box-container .box:hover .title{
    top:0;
}
.Gallery .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Gallery .box-container .box:hover .icons{
    bottom: 0;
}
.Gallery .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Gallery .box-container .box .icons a:hover{
    color: var(--main-color);
}

 

/* About */
.About {
    background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://evently.qodeinteractive.com/wp-content/uploads/2017/06/home-2-slider-img-3.jpg");
    background-color: #000;
    padding: 50px 0;
    text-align: center;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #fff; /* Set text color to white */
}

.About .btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #333;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.About .btn:hover {
    background-color: #555;
}

.About .content .p {
    font-size: 20px;
    color: #fff; /* Set text color to white */
}

 

.About .content h2 {
    color: violet;
    text-shadow: 2px 2px 5px red;
    font-size: 30px;
     
}

.About .content,.About .mission,
    .About .team,
    .About .why-choose-us 
   {
      margin-bottom: 30px;
      text-align: center;
      color:white;
    }

.About strong {
    font-size: 25px;
    color:purple;
    color:orange;
}
 
    .About li{
        font-size: 20px;
    }
    p.italic {
        font-style: italic;
      }

    .About p{
        font-size: 20px;
    }
    .About h2{
        color: violet;
        text-shadow: 2px 2px 5px red;
        padding:20px;
        font-size: 30px;
    }

.About li {
    font-size: 20px;
}

.About p.italic {
    font-style: italic;
}

.About .ul {
    list-style-type: disc;
    margin-left: 20px;
}

.About .ul .li {
    margin-bottom: 10px;
}

    

    </style>
</head>
<body>

    <!--Header section-->
    <header class="header">
        <a href="#" class="logo"> </a>
           
        <nav class="navbar"> 
            <a href="#Home">Home</a>
            <a href="#events">Events</a>

            <a href="#Gallery">Gallery</a> 
            <a href="#About">About</a>
           
            <a href="php/logout.php">Log Out</a>
        </nav>
        
        <div id="menu-bars" class="fas fa-bars"></div>
    </header>

    <!--events section starts-->
    <section class="Events" id="Events">
        <h1 class="heading">our <span>Events</span></h1>
        
        <div class="box-container">
            <div class="box">
                <i class="fas fa-map-market-alt"></i>
                <h3><a href="bday.php">Birthday party</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-envelope"></i>
                <h3><a href="wedding.php">Wedding</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-music"></i>
                <h3><a href="engement.php">Engement</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-utensile"></i>
                <h3><a href="bride.php">Bride to be</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-photo-video"></i>
                <h3><a href="naming_cer.php">Naming ceromony</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-birthday-cake"></i>
                <h3><a href="holi.php">Holi Celebration</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-birthday-cake"></i>
                <h3><a href="dance.php">Dance Compition</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-birthday-cake"></i>
                <h3><a href="anniversary.php">Anniversary Party</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

            <div class="box">
                <i class="fas fa-birthday-cake"></i>
                <h3><a href="baby_shower.php">Baby Shower</a></h3>
                <p>Loren ipsum dolor sit amet,consecteture adipisicing elit.Possimus,distinction</p>
            </div>

        </div>    
        
    </section>
    <!--events section ends-->


    <!--about Gallery  section start-->

    <section class="Gallery" id="Gallery">
        <h1 class="heading">our <span>gallery</span></h1>

        <div class="box-container">

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.de5sJfAlcU3Hd4XetbXccgHaFj&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.zeIsL78EwWtRuDxjGkfq2gHaE7&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                   
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse3.explicit.bing.net/th?id=OIP.qvlVBan1NUgQMlCs6Bh5IgHaE8&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.BDWhUK-8bxOZQPPntirjTgHaE7&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.DhkO4ntXWXUarVBZb_cV6wHaE8&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.23dqV3NlnTjDaM0r_2ogrwHaFV&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.HlvbiS_g9K9C1A7XSj2-xgHaE8&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>

            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.8WYStXLUl6RVPSzNr6Ih_QHaE8&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">photos and events</h3>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>
            </div>


        </div>

    </section>
    <!--about Gallery  section end-->

    
    <!--about section start-->

   

    <section class="About" id="About">
        <h1 class="heading"><span>about</span>us</h1>
        <div class="row">
             
            <div class="content">
                 
                <p>Welcome to Memory Makers , your premier event management solution. With a passion for creating unforgettable experiences, we specialize in crafting events that exceed expectations.</p>
   
            </div>
            

            <div class="mission">
                 <h2>Our Mission</h2>
                 <p>At Memory Makers, our mission is to bring your vision to life. We strive to deliver exceptional events that leave a lasting impression, ensuring every detail is meticulously planned and executed.</p>
            </div>

            <div class="team">
            <h2>Our Team</h2>
            <p>Our team of experienced professionals is dedicated to making your event a success. With expertise in event planning, coordination, and management, we work tirelessly to ensure every aspect of your event is flawless.</p>
            </div>

            <div class="why-choose-us">
            <h2>Why Choose Us?</h2>
            <ul>
                <li><strong>Experience:</strong> With years of experience in the industry, we have the knowledge and expertise to handle events of any size or scale.</li>
                <li><strong>Personalized Service:</strong> We understand that every event is unique. That's why we offer personalized service tailored to your specific needs and preferences.</li>
                <li><strong>Attention to Detail:</strong> From the initial planning stages to the final execution, we pay close attention to every detail to ensure your event is perfect in every way.</li>
            </ul>
            </div>


            <a href="#" class="btn">contact us</a>
        </div>
    </section>
    <!--about section end-->
    


    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <!--custom js file-->
    <script src="script.js"></script>

     

</body>