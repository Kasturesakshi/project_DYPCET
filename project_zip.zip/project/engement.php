<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Engement-----Planner</title>
    <link rel="stylesheet" href="all_event.css">
    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://i.pinimg.com/736x/07/0e/08/070e082d06b5d721affc5ef5e2900691.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

        /*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}


          /*-------------------cake--------------*/
/*gallery section   like ch option nahi yet*/
.cake .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.cake .box-container .box {
    height: 40rem; /* Increase the height to 30rem */
    width: 100%;
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    cursor: pointer;
    overflow: hidden;
}
.cake .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.cake .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.cake .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.cake .box-container .box:hover .title{
    top:0;
}
.cake .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.cake .box-container .box:hover .icons{
    bottom: 0;
}
.cake .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.cake .box-container .box .icons a:hover{
    color: var(--main-color);
}

@import url('https://fonts.googleapis.com/css2?family=PT+Sans:ital@0;1&display=swap');
:root {
    --clr1: rgb(21, 12, 104);
    --clr2: rgb(236, 68, 90);
    --clr3: #fff;
    --clr4: #000;
    --clr5: lightgray;
    --clr6: yellow;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    font-family: 'PT Sans', sans-serif;
    box-sizing: border-box;
}

html {
    font-size: 56%;
    overflow-x: hidden;
    scroll-behavior: smooth;
}

html::-webkit-scrollbar {
    width: 1rem;
}

html::-webkit-scrollbar-thumb {
    background: var(--clr1);
}

section {
    padding: 7rem 9%;
    margin-top: 7rem;
}

section h3 {
    font-size: 3rem;
    color: var(--clr2);
    text-transform: none;
    text-align: center;
    letter-spacing: .2rem;
}

section p {
    color: var(--clr3);
    font-size: 1.5rem;
    text-transform: capitalize;
    line-height: 2.5rem;
    justify-content: flex-start;
}

section h4 {
    margin: 0 0 1rem 30rem;
    width: 40%;
    font-size: 4rem;
    color: var(--clr3);
    text-transform: uppercase;
    text-align: center;
    align-items: center;
    letter-spacing: .2rem;
    background: var(--clr1);
}

.btn {
    margin-top: 2rem;
    padding: 1.3rem 4rem;
    font-size: 1.5rem;
    text-transform: capitalize;
    letter-spacing: .1rem;
    font-weight: 600;
    color: var(--clr3);
    background-color: var(--clr2);
    border: none;
    box-shadow: 0rem 2rem 2rem rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease 0s;
    cursor: pointer;
    outline: none;
}

.btn:hover {
    transform: translateY(-1rem);
    transition: all .5s ease;
}

.title {
    text-align: center;
    font-family: sans-serif;
    font-size: 2.5rem;
    letter-spacing: .2rem;
}

.title span {
    color: var(--clr2);
    font-size: 4rem;
}

.title p {
    font-size: 1.8rem;
    font-weight: 600;
    color: var(--clr4);
}

    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#cake">Cake</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book_cake.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1>Diamonds are forever, and so is our love.Engaged</h1>
               
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.k6QIde9g9ft71zodakmXBQHaFj&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 1</h3>
                 
            </div>

            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.sPsrp20IRNBGIVN_XcG_uAHaFj&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 2</h3>
            </div>   

            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.d8Yu4r7s_ErHCXEMo9JgHAHaEK&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 3</h3>           
            </div>
    
            <div class="box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.wAu_LeVoxSyFS1qo7IRNLwHaE8&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 4</h3> 
            </div>

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.iiVeUo1RI0Jl20pHXz_QPwHaE7&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 5</h3>
                 
            </div>

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.5FIDitISKdgdDXHHFGe7KgHaJQ&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 6</h3>
            </div>   

            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.QwLZc9KnmTtDp-JcjbABcQHaFj&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 7</h3>           
            </div>
    
            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.liobdIaiyM6nFXu_UT046QHaHa&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Engement 8</h3> 
            </div>
        
        </div>
    </section>

    <!------------------------cake-------------------->
    <section class="cake" id="cake">
        <div class="title">
            <h1><span>C</span>ake</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.gPphAVp_L_zRD6Eo9BqmbQHaJ4&pid=Api&P=0&h=180">
                <h3 class="title">cake  1</h3>
                 
            </div>

            <div class="box">
                <img src="https://mrbrownbakery.com/image/images/LfMh81ZUJTv1JKRQyHFURSVevOXqr3qxjXgaRm0Q.jpeg?p=full">
                <h3 class="title">cake  2</h3>
            </div>   

            <div class="box">
                <img src="https://i.pinimg.com/originals/a7/f9/90/a7f99057b8c845d50abffa6cc52246ff.jpg">
                <h3 class="title">cake  3</h3>           
            </div>
    
            <div class="box">
                <img src="https://i.pinimg.com/originals/17/37/8f/17378f4773d69ddb5246b5791106f4a7.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  4</h3> 
            </div>

            <div class="box">
                <img src="https://cdn0.weddingwire.in/img_e_61638/1/6/3/8/cake-engagement-1_15_61638.jpg">
                <h3 class="title">cake  5</h3>
                 
            </div>

            <div class="box">
                <img src="https://pic.cakesdecor.com/m/dmypx7oooopo2beafc2r.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  6</h3>
            </div>   

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.pr3rlmHutsvfPHMJyQQBzAHaIM&pid=Api&P=0&w=300&h=300" alt="NO IMAGE FOUND">
                <h3 class="title">cake  7</h3>           
            </div>
    
            <div class="box">
                <img src="https://i.pinimg.com/originals/8e/c9/65/8ec9658b3c27f55a07eaf0ce1085e411.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake 8</h3> 
            </div>
        
        </div>
    </section>

    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src="https://blog.bridals.pk/wp-content/uploads/2017/08/engagementbanner.jpg" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Kolhapur</h2>
                    <p>Hotel Paveline</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://i.pinimg.com/736x/9c/66/0b/9c660bd9ad55bd1b20a4fc7a2a624341.jpg" alt="no data found">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>Swaraj sanskruti bhavan</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://www.meltingflowers.com/blogs/wp-content/uploads/2016/10/Backdrop-2.jpg" alt="img">
                <div class="venue-info">
                    <h2>Mahableshwar</h2>
                    <p>The moon restaurent</p> 
                </div>
            </div>
            <div class="venue-box">
                <img src="https://www.eventsource.ca/blog/wp-content/uploads/2017/04/NGStudioHeader-1.jpg" alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>The pearl</p>
            
                </div>
            </div>
            <div class="venue-box">
                <img src="https://cdn0.weddingwire.com/vendor/539207/3_2/960/jpg/westchesterfloral-179163079-289948719325474-4731517677828533323-n_51_1702935-162221744137113.jpeg" alt="NO DATA FOUND">
                 <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>The diamond</p>
                </div>
            </div>
            <div class="venue-box">
                <img src="https://media.weddingz.in/images/eae39f62cb66be2718b2ebd57c271645/finding-the-best-banquet-halls-in-vashi-is-not-as-difficult-as-you-think-2.jpg" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>The star</p>
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.xmdvZPkCCAVoDwXPBoBGPAHaKe&pid=Api&P=0&h=180" alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src="https://tse2.explicit.bing.net/th?id=OIP.wHBXYDWf6QffBh5HYB1s3gHaFj&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.jNnEmdsDBTPqa7ylJxNEswHaHa&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://www.desievite.com/thumb_img/invitation/thumb-Mandap-elephant-3D-engagement-invitation-card1-97.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://www.desievite.com/thumb_img/invitation/thumb-engagment_pink-113-98.webp" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://www.desievite.com/thumb_img/invitation/thumb-sakharpuda-nimantran-patrika-khalita-theme-template-178.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://www.desievite.com/thumb_img/invitation/thumb-engagement-%20invitation-elephant-banana-leaf-koyari-167.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.SotHY9wQf7sAGwKufxPh3wHaKc&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.7FX2yCSwBY8gw39aPZ9hwgHaKe&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.hXtgY6pk9-T6_S5dmmzsIAHaKj&pid=Api&P=0&h=180" alt="">
            </div>
            
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>
