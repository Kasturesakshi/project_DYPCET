<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baby shower</title>
    <link rel="stylesheet" href="all_event.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://www.photojaanic.com/blog/wp-content/uploads/sites/2/2022/01/image9-1.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }
        /*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}


          /*-------------------cake--------------*/
/*gallery section   like ch option nahi yet*/
.cake .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.cake .box-container .box {
    height: 33rem; /* Increase the height to 30rem */
    width: 100%;
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    cursor: pointer;
    overflow: hidden;
}
.cake .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.cake .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.cake .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.cake .box-container .box:hover .title{
    top:0;
}
.cake .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.cake .box-container .box:hover .icons{
    bottom: 0;
}
.cake .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.cake .box-container .box .icons a:hover{
    color: var(--main-color);
}

@import url('https://fonts.googleapis.com/css2?family=PT+Sans:ital@0;1&display=swap');
:root {
    --clr1: rgb(21, 12, 104);
    --clr2: rgb(236, 68, 90);
    --clr3: #fff;
    --clr4: #000;
    --clr5: lightgray;
    --clr6: yellow;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    font-family: 'PT Sans', sans-serif;
    box-sizing: border-box;
}

html {
    font-size: 56%;
    overflow-x: hidden;
    scroll-behavior: smooth;
}

html::-webkit-scrollbar {
    width: 1rem;
}

html::-webkit-scrollbar-thumb {
    background: var(--clr1);
}

section {
    padding: 7rem 9%;
    margin-top: 7rem;
}

section h3 {
    font-size: 3rem;
    color: var(--clr2);
    text-transform: none;
    text-align: center;
    letter-spacing: .2rem;
}

section p {
    color: var(--clr3);
    font-size: 1.5rem;
    text-transform: capitalize;
    line-height: 2.5rem;
    justify-content: flex-start;
}

section h4 {
    margin: 0 0 1rem 30rem;
    width: 40%;
    font-size: 4rem;
    color: var(--clr3);
    text-transform: uppercase;
    text-align: center;
    align-items: center;
    letter-spacing: .2rem;
    background: var(--clr1);
}

.btn {
    margin-top: 2rem;
    padding: 1.3rem 4rem;
    font-size: 1.5rem;
    text-transform: capitalize;
    letter-spacing: .1rem;
    font-weight: 600;
    color: var(--clr3);
    background-color: var(--clr2);
    border: none;
    box-shadow: 0rem 2rem 2rem rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease 0s;
    cursor: pointer;
    outline: none;
}

.btn:hover {
    transform: translateY(-1rem);
    transition: all .5s ease;
}

.title {
    text-align: center;
    font-family: sans-serif;
    font-size: 2.5rem;
    letter-spacing: .2rem;
}

.title span {
    color: var(--clr2);
    font-size: 4rem;
}

.title p {
    font-size: 1.8rem;
    font-weight: 600;
    color: var(--clr4);
}
    </style>

</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#cake">cake</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book_cake.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1>Baby shower</h1>
                <p>Find the best baby shower decoration ideas and venue-list</p>
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRF7Q0NtYSLQAWmpe9DQjWxK5IjM76Js_oNZVZ9tBmUyw&s ">
                <h3 class="title">Decoration 1</h3>
                 
            </div>

            <div class="box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ28ZaM2BpjFwc2Ivz6CbTOuyUMtNtoZWgl39g5QpqgbEjVRjwq60wWVUcErzOjdzoipyc&usqp=CAU ">
                <h3 class="title">Decoration 2</h3>
            </div>   

            <div class="box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStoUHMF4kqHC6eyD5rGxd7G1JrxkRlkmcpuWpYHPr1-4ngvoHCmDM9hbcmQhk1iHTAWoc&usqp=CAU  ">
                <h3 class="title">Decoration 3</h3>           
            </div>
    
            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfq-rYVQsliqIN3rTgHlTFPjT31Wk5OnnJWZpxiHHegg&s " alt="NO IMAGE FOUND">
                <h3 class="title">Decoration 4</h3> 
            </div>

            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqKtJewx_gCx7IwfFyhDHO7FcAx3WyoT7duw&s " alt="NO IMAGE FOUND">
                <h3 class="title">Decoration 5</h3>
                 
            </div>

            <div class="box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVelgPxhoZxsakzIkI3ADLioTjEOTRSFnaoNN18jWLpQ&s " alt="NO IMAGE FOUND">
                <h3 class="title">Decoration 6</h3>
            </div>   

            <div class="box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRz9T_hCIKAKqyV6STUKTtHy0SvA2_XWEV3ZB_9G6wNX3duOV80PataSPYT7M7KDULRjUM&usqp=CAU" alt="NO IMAGE FOUND">
                <h3 class="title">Decoration 7</h3>           
            </div>
    
            <div class="box">
                <img src="https://i.ytimg.com/vi/KGqHEUrDbHs/maxresdefault.jpg  " alt="NO IMAGE FOUND">
                <h3 class="title">Decoration 8</h3> 
            </div>
        
        </div>
    </section>

      <!------------------------cake-------------------->
      <section class="cake" id="cake">
        <div class="title">
            <h1><span>C</span>ake</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://honestlybecca.com/wp-content/uploads/2021/06/B41AE0F9-BC3C-4702-9F84-62AC6D209380.jpeg">
                <h3 class="title">cake  1</h3>
                 
            </div>

            <div class="box">
                <img src="https://preview.redd.it/66jdxamk6rfz.jpg?auto=webp&s=4239658ccc9b9fcda5f1dec2d9487a6411adf558">
                <h3 class="title">cake  2</h3>
            </div>   

            <div class="box">
                <img src="https://i.pinimg.com/originals/65/eb/ca/65ebca441eea9199577e8b458ab0b49d.jpg">
                <h3 class="title">cake  3</h3>           
            </div>
    
            <div class="box">
                <img src="https://thebakeshop.in/wp-content/uploads/2023/05/Baby-Shower-Cake-4.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  4</h3> 
            </div>

            <div class="box">
                <img src="https://i.pinimg.com/originals/53/60/e0/5360e0c672d4de9813babd8c7cc14d28.jpg">
                <h3 class="title">cake  5</h3>
                 
            </div>

            <div class="box">
                <img src="https://2.bp.blogspot.com/-yfFdz000AXQ/TZKCIuhHdCI/AAAAAAAAAhM/MHKmLMWUl24/s1600/IMG_5195.JPG" alt="NO IMAGE FOUND">
                <h3 class="title">cake  6</h3>
            </div>   

            <div class="box">
                <img src="https://www.handsoncakes.com/wp-content/uploads/2016/05/2tier-baby-shower-cake-girls-582.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  7</h3>           
            </div>
    
            <div class="box">
                <img src="https://www.cutest-baby-shower-ideas.com/images/GenderReveal-OhBabyCake.jpeg" alt="NO IMAGE FOUND">
                <h3 class="title">cake 8</h3> 
            </div>
        
        </div>
    </section>

    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src="https://i.pinimg.com/originals/bc/e0/e2/bce0e2144a9269bce93ba789ccafa5c3.jpg" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Kolhapur</h2>
                    <p>Sayaji hall</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://i.pinimg.com/736x/92/53/78/92537822070beb56cfca7928bc9f2ffc.jpg" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>victory hall</p>
                     
                </div>
            </div>

            <div class="venue-box">
                <img src="https://i.pinimg.com/originals/1a/32/1e/1a321e2284f262ad4d2044997d0d3729.jpg " alt="img">
                <div class="venue-info">
                    <h2>Karad</h2>
                    <p>Ossacions hall</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://img.peerspace.com/image/upload/ar_1.75,c_fill,g_auto/w_500,c_scale,dpr_auto,f_auto,q_auto/ucnbcal67dmturmky8r5 " alt="img">
                <div class="venue-info">
                    <h2>Kolhapur</h2>
                    <p>Pearl plaza</p>
                     
                </div>
            </div>
            
            <div class="venue-box">
                <img src=" https://cdn0.weddingwire.in/vendor/7001/3_2/960/jpeg/hotels-welcom-heritage-traditional-haveli-stage-decor-12_15_397001-164252752940817.jpeg" alt="img">
                <div class="venue-info">
                    <h2>Mumbai</h2>
                    <p>Grand hall</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://cdn0.weddingwire.in/vendor/7001/3_2/960/jpeg/hotels-welcom-heritage-traditional-haveli-mandap-decor-2_15_397001-164252751131943.jpeg " alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>Tarabai haveli</p>
                    
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src="  data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhIWFhUXGBcYGBgYGBoaGhoXGhcXFxcZFxYaHSggGR4lHhUVITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy0mICUuLS0tLS8tLS0vLS01LS0tLS0tLS0tLS01LS0tLS0tLS0tLS8tLS0tLS0tLS0tLS0tLf/AABEIASwAqAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAAAQIEBQMGB//EAEAQAAIBAwIEBAMGAwcDBAMAAAECEQADIRIxBAVBUSJhcYETMpEGQqGxwfAUUmIVI3KCktHhM7LxVGOj0lOTov/EABkBAAIDAQAAAAAAAAAAAAAAAAABAgMEBf/EACYRAAICAgIBBAIDAQAAAAAAAAABAhEDIRIxQRMiUWEE8IGRoXH/2gAMAwEAAhEDEQA/APe27Fr/ANPa90T/AGqH8PZ68PaPfwL/ALVnWvtCCbnw0JCEAHUFn+7ZjAaCDqXR2yDO4rW5TzhbxZGgunzDBIDFgmptpIAaNxNWcWjfKMautHK6lpVm1wtlz1DW0hV6mAJPt71z4c8KVL3LVhTqiNCR0PhkYEGrt5gpkCM7VV+0VhfDcLQxKoJHhjJlm3Efp9LMbTdMwflYnjXOD18MtWuU2GK6bNkzBBCJEbzMbRVTmvwUukLw/DxGJtjPmIAEZj2q1y/hvgoLYad9UY3JJAHaafM/hi2WuToTxsFEkgfdiCSDjAyaPby3szuTarpmDeu2XtFXtWkdFUs6rbUOwMXFUEGFwCRMwSAZE1DlXA2zM27a636LbJCIwIcscKrIhWIJJuCCINZ/GJrVwUVbT/d1MItxLFpOW8/CPSK1eI+zICpbs3YJUhD8MMFhFJIfSQJUgjUc9zFXuEYqurGnezdv8DYCk/As/wD6064HSqvDcq4c5PD2z/kX/arrWyLKqREBQR7R0qVuAGAPQRWNrZ0sSSx/Zkcbf4ZH0Lw9okFQ2m3b1LqjSWB6QScdFNUk4rhDcNu5Yt2zoRvGiCS2qVBGCV0iTMeIVa5hy63dY61yYlgSrR0GoZI8tqOE+z1jUWFssTBOpmYSoAXwnGIBG+c004+TQ8fFWjq/K7GIs2/9CfjiuvEcLbVFuDh7BUYabazvjbpmPpVx7MDJz26/Wl8VRaufEkqFZjAnCwSANyfKiLSZRnhzxv6MB7tl7RV7NpHVZZ1W2oZh8yoCDHhIJBMxI3INcuWcFbOrwWl1sACq2yQi6SLmo4VYVhsZLiNqpcSPiB/AFtvHhJYHQR4y2TLRPQD6TWpc+zai3bSxdgssJ/dh1VvhltYfSYBWYLHORNa3CMVXVnMTvZvvyqwVMWLPfCJt5Yqte4PhEgvbsrOBKJ+AjNc+XcO1tSNW8Y6CN/c+VVee8KMXi4wApU77kjR57mPLcVXHGk6sjKbjG0jpca2rlLPC2LmxgopnE+EgYx1zVi7w/D/+nt+fgTBPSQMx9KsG0LVoIskSdwAc5M9thUuFUDOkHzP6TVMpK6RvwYKjzyb+imnD2unD2v8AQv8AtTqpxP2jlmVF1KpZTDhYdQ8qwOdwgn/3AdhRS4NmrgvgXEcg4cFibIkgAkFxgGR97v2j9KtcDZVcKAo2AAxVr4LRtPv+5p2lI2EHpvUW35ZNT9tI6cTBJPpRzDhRctqjkwSu2/p171JrYWC5nsI3jf0FZ/NOKIGsKzRAAHXOSJie59KsxrdmD8nJHjw7L73OmOmIM1N+UNetlS2gGIkZwZ27SKx+X8TcdiFsmZ8JDA+7RGn95Neu4C26oBcbU3ft5T19TUXN/FGTGlke0ec4PlaWy4aHOVMjEbEaevUZq7duJbkwF1FdUQCxACqPMwAB5CqPORctX1gkJcc/d1AlhInsAwgxHzCrPOeSi/w6FVm4hFwf4oIMT1gkehI60Sm5PbIpPaXg0kspcUlG1DbtHkeoNUbnDOvTb8qwuTcya1dCldPTB8Lr1AB+VgZ8Mz7GvZ8XZF1FhiBKuCOo7e81W212asGf20kYNxP6f39Kel+gP1rQ5tps29eTkCJiSfOq3LeIW7BPgBUMCSDghT6fe/CjnG6bNPrq+Pk42rFw4iPpVx+U67TJq06gM74mcVbv8stuoB1d5VoM98YrhzfjxYtqobxEQC0YAGWPc/vpRyadohmzNxal0ZXDcpW0zBzraIkjEEbaeuCRVnjOISyrPAWdIJAiYhUB9PwFZHI2e9fXS5NqCzGPnBiCJyJ77mQcCBXb7SErcRBGk3VwTLMBbZiB6QDPXbzq1ycn7jm3UW10XhbKKDEggEGMR28q4cZYW6kN0YMCOh2zPTJFW+I4S+ttIJZQo1JsQd9h83pXn7nMG1QbLAagMMCY6ll+7Hr02qUcjb6/0cpJaaN7jROmdp/5qJ+UjsfwrnZujTpYGOmDI7EDtXQ2SADuCJGNwdqhJU6Ophyqcasx+K4C1cIL2wxBkbgz6g59DNKtI2mPT8/2KKSv5NbyI4DnBFzQyJpIXTcDwGJnV4emmATmcntS/t0lhoRQoDBtWSTq/u2RlMaSAx2zqHY1i825CiravAh3GUBHwwJTUBAE4UAmRIkYGa6ct0G58O6CrXCBaurLGQJAbUGXoQJEdOta1CFcls4sskurN7jOZt/CfEUD4lt9SwSNRyYBjZsp1Gat8PxxuWjdsr4goc2yMXFInA2D+Ywcbggh3UBBwPSNu0VT+yVxlf4bNOgskEEQp8aAHYgCF7gqd6ySrtFcZe5JlzlX2nsXADhQe2wjB1CAVgyDjEZreBnIyK8hzrkL23e5w8aWliIJAb+pRmD/ADDI+oM/s7zrRFu94QTtuFPk0nB84PWN6g0WQyuL4zPUcRYV1KsJH72PQ+ddLaAAAbDFOadBpryUuL5Xauz8RASdyJBPrG/vXTg+FFtdKliJJEmYnoD2qxRQJQSd1szftDZLWGjcQf0/WsCyv8MFtlFuOVREEwoxkkxsBn8K9bfthlKnYiKweacvvF7VwBSyMPFJgjbxDdcT32qDirs1/iwx8+Uu/wCv37M3ird1cshkfK1smB6TkGrK8qu8WqvddNLKoIGZjeYjEzKzuTPl24sXm1KlpiZidlBH9RxWxyng/g2ltkywksRtqYljHlJprst/NUcmKPKrvx8E+B4FLSwg9T1P/HlsKg/LUa6LjZI2HQHv5nAq7VfjeKW0hdzA/M9h50znuMVHfSHxfFpbEu0Dp3PoOtYX9vi9eWzYRTcYE6jDaE6uwH0AnJx3jF4vir3EXfAJB6lZIXoqJP4sAOpnavQ8k5T/AA6Pcb/qsCSd4AGBP0ppeX+/9M/qSyS10ZvPOZaWWygY630vcJyVGWluxMKFX+fpibHNuaaLulVWAABJOfSMRmPas7hAX4hiTqW2oQDTADTrcid5lBM7oYq/zNbfwy1wkInjbSASQuSsQSQdsZ86tx0qtFSk30UrXOxoIdV1qoLEEKrMDDBASTjDZ2E9RRXneKt/EDDQFtOcLqYHQR4mMn5p9B9MlbFiguy+OVvtv+FZ7luGtnxG2sli5JUElymhmzsSvhJ7Vm2+R/3iFHhdeFjMqpfedvCB71ocn4C6wm4xiScgA6caVGOm8nvVAc0njgqiLVoBF/qZ2i6T3wEj3rFHI4p0ylq6ciPDc2m4UKQVOAxHjAiSB5TkdPQifT2Ldu4VvKsN1O2eoPes7mvIQ7i7bIDgzB2kiCQehP0q3ya26qwuLpM+oONwfaoPvRZji4y4yRozUHQHdQfYVOlSNQUUUGgBMwAmQB51Xu8fbWBqknYLk+8YG3Woc3LC0zKRK+ITsekH61jWdNpJMkgF4VSzNpiYCjJzt51TkySUuKRfjxRlHk2al/j3nwp4QMk5P0WTVkX9SIwHzwQPUTVV7oUBiGUEA+IQZP3Su4Iqrw3GBbmmDE6lxgagdQ8tmNRWRxl7iTx8o3FG2qximBQKdaDMEVFlB3ANSmg0ARAjYR5VG4gIIMwRB/4qdI0CoyuMW3aT4aKBOT5eZPU+tYS3P4hbiKCAqlg+4YAapHkSAPOZGInV5lwV667oqgIcFmO4gYAGa7pwK8PZYLkkBSxx/SB5AA7VUsk03L4M0ocn1oyOE5UtstrIuEiMjw6WH8p3kGKddvs5eF601t8XLUqG6m3J+GT3xAoq95nLeyMIyq49HpT8vt+leB5Oha+V0/ftwfYM+f8AMfoa9+tZfB8q0cQ9wfIRI8mJMwPc/Wo+KLc0HJo1qZWo0wKC8IpU6VAAKhxF9UUs5gD9TAx3k1M/jXO/YDqVPWPYgyCPQgGk7rQ1V7Kz8Rbuoy6okEeLBHnB3jeqXAXwphiNQxAIg+a96nd4QpJgt1MAtnvAyMAeVQ4KwLw1uvg6A9QOp7f+KyylNyWtmuKgovejrx/MUCkTkH64nwjc7/nWdbU/ORknA9cKPeY/zVqWOU2gJVQpOZz7b1xKyQvQmDG4Inb3AqDi3JWOM4qLUTXWIEbQI9KdcOHb6SRH8rbkeh3/APOLBNbqMViiiiaKAACiilSAKp83TVaYdoJ9Ac/hNXai6g4PXB/KlKNpoH0eT+zU/wATdxGG/wBMWyPxaitvlPL/AIYdm+ZifZQfD/v9O1FLEmo7KscXGOzSU4pg0k2qQqZaKnSFOgANKnSoAdKnRNAFDjOIhtI8vLJkkmPKPrS4R5VliN8djkEfUfjXHmwZWFxRIgTvE5BmMiQRB7rXHlyt4mYGD1ggEkkmPLass2+X70a1Fenf7ZqXLgWB1OwHl+lZzv4+x1oR7lf1muXFXQ7hZgGB7QzR7kAVPl1rW4j5UJP/ANfbUCfaov3dfI4wUI2zTeAxPQQSfZhPptXc0is0ya2mIVOKNVRpDJUiacURNAECfpTBoK/+KjTAkwpUi2M7UUBRJNqmBUVqdIQbUgaZpUABpCpVGgY5pUVVdLvihhnVG2P5emaALdFVWW7JyI1CPSIM+Hyn3plbmlQCJjxHzjpjv18qdALi+BS58wztI7dj3rpw3DrbELt1nJJ8zXJUuyJYROR5SvWN4B+vpEtNzUMiJ8siT5doEeXvUeCu/JLk6q9Fig1VZLvRx1/Mx0ziB696kBc8GQYnX59ox5z02qVESwBRFFI+VICVRIomg0AH7mo/hQ1OmIRGP0opmikManapVFRTigAqVKigAmiaZpGgBflXO9dIgASx26DG5J7D9RXTV5VU46BDE4yDmMEqYJ6A6Y9x3oHFWzpavNq0OAGiQR8rDrE5BGJHmK7kVk8RfUKWT7jqV2IDEH4iwDsEJJANOxxP9+qJeNwFWLgxAiNLLAGCTGJFOiz029mrFcn4hQwQt4iJA8tvbOM712istc37oO5+D7KgLn2kfjSSIxV2adFE0ie+KCAE0TS1CYkT+Jjypn8KACiiKKAEaKYoBoARopOcGigCSHFOojapUAh0UaqKACaU06KAFRFV+P4r4Sao1GQAO7MYAnpVVOKukkFdLQxQLBDlTDAlo27YkZmiiag2rO3G2l0kQAoS6cY+7H5M1VOLZRbDqAGRkaQI8UhbgJiDgkH/AIrRUrcAOCBjBkT1EjceVUF5bcOlWZTbVtWJ1N4tQDA4GdyN4ponBrz4I8Pfe4XuayF1m3aQQASOpn5pzjyNdfgBuJaYgW7ZI89TxPlgn2HauVvl72ipDara3C+kL4gGVlJkfNGrYDvVs8NqVvuO/WASADKg9DA3HmaY5NJ6ejPst4jpj4S8SsepWCFHbUxPvWj8ebj2iMBEaeuSw/QGq/DWB8P4dtS4kzcLaQXmSwMEkgjcCMb1z4dHHEPBUkW11EzuWY5PeB2iIxSY3Tv6M3m1xrfEpcdTCxpg/MBP03Ej/evQcBxi3U1rI3BB6Eb/AKfWmpV5V1ExMGGUg9VMbe36V0tW1VQFAVegAx+FFkck1KKVbRMURRQaRSKiaCaKYAxoobalSAkm1SqAOMVKgB0UUTQA4rP51x5soGC6paM4GxP6VfrzvEcju3LjM90aSZ3Pyztp2ECmq8luJRcvc9GjxgN60dAyVDr3DjSyj9DUuCfWi3JEAMVEZDGQQ3+HIp8KdCJAATEDOoBjgkzkyROOp7VxRdF+4gwLiG4PJx4Xx54NMfhpfvyS5MPAI20Wh/mFsT+BWr124FBLGANzWFwiFbfDvLAs9sASY0EQZGxJgmfQdKuc7vx8OflW5bZz2EnT+IJ9qTWxyhczStuGEjY0ztVFZ+KfhlWlZPiIAmAswDvDH3PrWfw/Gm1Zu3T4i15tM41ZCkx0GD9BRRFY2+votcOL9pRaW2twLhW1hTHQOsflUuB020uXHcO8lrhXIEYCjyEEfWo8XbNu49xCPFbdiDuNKoJBjP3cHr1FduU2NNlBvKLPpEx+JPuaZKT9t/P6yxwiKBKAjoQZJABjSMmAM4GK5jmNrUU+IshtMExnsO9UPg6HsfCJXW7EqCdBt5Y+HYQNO3eoJyZW4hruoG3OqAfvzJB8gc+4opBwjtyZuNQT5ZoApeVRKAoqQFIimIR2opNtRSHZIdKlUV2p0ASqM+VFOgApMJBHQ4oqQoAyOHNxiUJONKssCAF0ksDvmGjvI7VJGFziSy5W2jIW6F3IJAPWAKvX+FR/nRWjaQCalbQKIUAKNgBA+gp2WOa8FXi+C1W0RDpNsoUJyPBgAxviutvhgUK3Ictl8QD5AdAIEeneu9OlZHk6OPCcIlpdNtQomfU9yar3OU2yrrmHnczpk6joB2GqDHlV2aCRFFsObu7KfAcCUB+I5uMRpk7af5QJ+p60rHBMqhDcJtjAGmGK9FZ5yOmACRV4mKKdhzbKToDez1tEL/q8cf8Ax10sNJJGRAWcZImYjGJj2Paut20Gwyg9c/pUgsDEe3T0oBvQ/wA6CP8Amo06REc9tqVE0qAButFDUUxAh+ldK5oa6D0pDCadIiigB4pGiqfFcwVQxUFyMQoJGraC/wAq5858qKsC3Qc1zUkJNyJCy5E6ZA8UTmN96hwXE61krpIJBBMx139CKKAhb4NVkCYOmc9m1Y7f8VE8vSPvR7T93MxP3RVyaq/xDtJRV0qSJZiJKkhsAGACCJPbanbAP4BMZOCCNvPyzud6j/ZybSdo6diO28GPYUXeOKCXtPOwCQ4J6ARn6gUcBx3xS0IwAOCcAg7GDBG3b37PYHS5wisZM9MekdYnp3/GrFOKVRARFI1KoN50AOj9+lOKQoAY/ZpRRTFFgRO1KmTv3opDBek1MGoqdqc0xEhRSp0AI1k8Q5S18IAMU+GPDgABlKl5wpMDAk5mK1way7KkoloqwbUGuMQYkMHYhtm1EDacHMRUogPjuOU27y5Hgvdvuk28DfLYHpXOxxCW5LvtaN14PhHxHLDHU4IB7DzrRPDJOrQuqdU6ROqImY3jrUV4K2Ii2kgkjwjBO5GOtFoCPD8YrYOG1MumQTKiWkjAiQD5+oqF7hUHzMQrNlJ8Jdj1xOT92YJO2a72eHRcqirgDAAwNhjoKncQEEEAg4IIkEeYqPnQHDif+pZHXWzH/CLbqT9XUe9ZvKeOVLbF521E4gxpthRn5vl/zMR0rVscMiTpVVmJIG8bZpnh0xKL4ZjwjE7xjE9adroZRPO0EgqwKvpcGJXYAmJmSywNzmNq6W+bISZDLpD6iYhSh8SmCZIkHGMjrVtbCgBQqhQZAAEAgyCBtM5pNw6GJRSASwwMMZJPrk586LQFBucBbYZlOvSWdRHg0kI5MnYNInyNSHNkLFQpYSsERBVm0a8n5dWPPpirScBaAAW0gAMiFGD3GK6XLKtOpQdQhpAOoCYBncZP1p6ASXFYSDiSJ7wSMfTepmgCBjbaO1FREH50TSooAG60qG2opioku1MUgMVIUhnO9fCwDOeuMepPrXI8wSQM5jp1OiP+8fQ1YZAYkAxkeXpUVsqBAVQPQd5/MA+1PQHFOOQ6ZkFiAAY6gMJztlR6kVMcSChcAwJ3wcb/AKj2NTWyoEBVHsPL/YfQUwi5wMiD6ZO3ufrRoDgOLExDHxR07sJ32lG88UDjl0M+YWJxkyAQB5+ID1rutsdhkzsN+/rRoHYRjp22/IUaA4njF8z0ERn5Ns/+4v40hxyxIBPkAD0B7+ddfgLnwrkAbDIGwNHwV/lXaNht29KNARt8SDJyAADOIgieh7UrHFBtMA5XVJjGYIOZma66BtAg426Uwg6QPbvk0tAVl45SuoBvTE7au+PDmg8esxDHMCBv8wkCZ3RvOu3wEiNKx6D1/SpC2JkATvMZmIn6U9AcE41DO8KpY42AJB98fl3pNxqg6SCGmMgb+GBIMffB+tWFQDYAew/fQUlsqBAUR6DvP5gH2o0BW/tJILZ8MSY7xHXzP+lu1NuNWWABMGDEdmPfsp/CrHwl/lX6ev8AufqaGsqd0X6D2/M/U09Ac7N4NMdO/Y7EDeMV1I9KEUCSABO/n696dIRE/jRQ21FAEl6Vh8t5l8TiXk+Ewij0lpjzx/qFbKuGXwkGRuM9K8VycabrY8WtMdtMLPvC/hVGWVUVZJVKJ7oCiiiri4KRFOkxwTQAoqrevuCQFwCMwTIJGRB6DVPtUf44wDpBkE4YnIYLGFzuNvxoXmEkDSMlF+b+ZNc7e3nTpgJuKuZm2esYJn/qaf8AtSfXzFdRefSTpkh4Agjw6on6Znak3FELqK/eIgGYA1Sdh/KcVD+0l6qY8MnyIlj5hetFfQCXjHifhnZDsRkldY9g2PNTXThr7sx1LpEEjB/mYDPoFMedHDcXrMRpwME5k9IoHF9gN4jVn73zCPD8vnvR/AHL+Luf/jjwk5BOQikDfuzD2rtw/EMTDjTgdD8xJETMdBjO+8VKxxJbdY8Afed9htvhvp51xt8yBiVIJMHO3hU593UfjTAvGlVGzzIMVGmJ0zJiCwYkbZjTHnV4dxSqgETSqZpCkBGoX7oRWc7KCT7V0rN+0J/uGjeVGOviFSirdEJuotmb9l+ZFjdssZKlnUzOGIYifLWpH+Lyp1kfY63PFXmT5YYk/wCIIAP/AOaKnmSUtCx9Gxys3LSiWBEn/T0X2zmpW+CU8Ut5cC4Icdnt+If6gT/prne5iiAEhtJaFYAFWHwxcDyDhWmATufrWOvN7hu21DBdbwqYzIIMHcnSWPtUY/jco6Mzk40mavH84e5d+FaJVZMsN4G5Y/dGYHetnkfDBEMTk7ncwNyfrWRw3BopJCwCZaN52xPkK0eD55be78GyupUwzTABiQAPvbb1THFPlyZZjle32a0UVG9cCgs7BQOpMD6msxvtDw2qPiS3YI5J9IXNWKLfSL3JLs1RRULq6lYAxIIntIgGqw4ZgEGr5TM5zknb0x5fgQkW6Kqvw7HV4vmBA38MjMd8xHYUrnDHwQxGk5k75B6ehHvRQFsr39qKq/wp0gajMkzmeoH0BA9qinBGB4oMEYnEsGET2AIz3ooC7QTVZrDaQuvqSW6kSSNvpUBw7wZfJBGJwwjSRO+Vn3ooC3NE0IsADsI71x4niVtjUxMTEgEx9BSbS7Edwag34VU4bmtl403BnaZE+kjNWrrQCY2BIpckwTT6PK8+4ZkuPdssy3IDDT97GxGxODXflXOv4mxcW5i4qapiJA8WR91gRBH/AIFi7xtq+pERcQwVxg9c7Ef8Vk8bwyWbd26kKxU62P8ALGliZMDwk/StEJqaSMrkk2u7LnIeF/hrGhR/e3JuXD2LywUD+kMBRWfwPOzk3TqBEh1Ak4wIGDtA9qKc4TUtiuU9oyeZcdxD/CtNbZlbOtV0MoC+HCySMtBHnE135ZeFtnYJquGIdjKpO4UAA7AzmZMYBrfHKres3fGXIWSW/lkqQB4QQSTgdu1JuVWSwKlk+eVUiGZmDamLSZB1R/iPYRb6sKqiyWGVWiXF8wRbRuDK7A9idge3/Fc/sdw8AMWBENcaABp1fKGO5YLA8tO1T5pwCHh1sEx8R/ExP3ACGJI/phQB1Iqd+5YFo2i3w7JEPA8TqBGgKJ+GkYzkiRjeqqVUiMVR53jOZtxtwsrMlkEqhAmR/MsjTJ31H2B3HqvszyQWl1MsH7oMah5sdyd98ifp05Pf4MkCyRq6BpDf5dQ/7au845mnD2jcfMbAbk9h+dE5N+xKicY3tl2lVHk3FtdthnEMcwBAAIkDPYGPavPc6+1Ta/hcNvJGqJOPmYCDCiYmCSdhVUcbbpFvNVZ6/wB6QrK+z3DuENy5ca4z9W20jaF6TJ9orWAqMtOhxdqyg3M1HECwcEpqBnduqx6QavzXzzm3Gt/EJc6anYHsQUAH4L9DX0M1ZOHFIhjnyHSrI5vza5Yb/o60IwVbxCPmkR6bd/WuvKedWuIHgaDE6TEx3BGD7VHg6vwS5q6NKosJBBGOo71R5vzQcOoZwSs+IjdRtqjrkirlm8HUMpDAiQRsRUeLqx2ujyvOeT6W1glR0YAEH+lx94+e/arP2b5oWLcNdnWFJUmcrsYkAmJHT9K9FcIgkwBGZ2jzmsHiLvCFgVuFXUyrKGIDbYBEEbggbgms7hwld6KJRUZckzOvt8K+GZpDjSRGQ4MSY3kFc9kParPMOOCYgFpAZCJlPvDyMbTXTmlu3eAaVFxCGBB8LdG0noSsjSesetd+P4O3cf4mpgGUHBAmfUYMaavwUnUitwbb4nh+LWPiPbR4B1C3q/lERhfkP9RM9zinXq7HLLSppALMVCsxMM8HVLAYnVnAHToIores8S1YWu0n/aGyEfMcjzp2WBxJH+/0xWAv2i+IW0WLjhcSCvzSZXE5AE/ua0OU8aLjMqyHUKWUiCNc6T2IMHIJGKxuLXaOskuN2awukYaCvX99DVbmfL1bwlQymN43mRvjsQfKrPF3ACcbx9a5c34s2rSsAC0qADOfIR1xU8bd0jF+Slw5szV5Lak+Ehid9ZIHoWJAFL7U2Lgt2Ue58QtqVXAkgkqBJnxHpPXbrnadfM9MVwZBqBbCW5fMALAyxJ2xJ9qt5eTEtHfxLauW1Ma5GsmSCREx1P08qzfs/wDZ5ohyNI+YjBc9p3j6R5kkm9xHMUQAkMFJYAhZVgFDagQYCsCNJMTWZwnO7vxkRWCC40BYWSIyQSJJgE+1RgptOiN7UZHp+acTdt6PhWw+TKk6YAiIOw96b8adwsd+uazuJ4lmMTv+xVccIxOPqcCqL+jpxwUrkwucusyCUEgyCWO/h6T/AErjyq/xnMLhUi3p1YyY7iYnG01mPjrnyNTtMD5dqfK2P0Fx+Df47hlvWyk+hHQ9D++5rwHMOBucO+u2jC4rB9KmQxwJUHqdsYPWDXqLF9lIzg1d4m7qB1hcZkiNMZJk7YFShNxMufHxfIpc2Bv29JGmVKsDDDxKARHl0INH2TtPbV7TmQCpDd5B1QOmVJioXeZW1UNDaSYV1AZWHw/iBwymNJBgHEnHnWTb57cF1ArBRcYKFIWW32JEkxJx2NThCUotLoz83GWz0HO+FLEF7ng6JMSe5/mrGfl1vJCzkGC0iZGynA9hWlcBJ1MZPU9fT/iqnNOKNpNQEywUkgwoMmcb7R6mqoYIuSlbsUpRdtosW7YRQzL4jsD09fOkxJyW/fauvHmNJ3E/v8KiBKGO+acnb2dPHHhFV/ZULAnr+/aisi9zZdRCW3uQzKxXABUgNk/NE9MedFJRfwaml8mgeU2XZ2KCXjUZIkBDbAx00s2O5J3q/wAHYs2lhTPzHE9SWME+bHeutjhlPcehoHDLPX60bZneSFeSuSGPZRkz08zVHnPMCwi3lAVIcK2pXGYUxIwR0zWo/AJdXS0jSdQK4ztnofenw1kWwVXaTvuT3Jq2CUd+TB+Rkll9q0v9K3LRde2vxAQ2d94kwSO5EGPy2rO5tb4pXBtyACThSwZIPhgMIMxOrFbpuGRXLm0FdDKGV7ltGDCQVZwGBHWRI96l6jUuinjVKzyfM+Y33+Faa2xBk60UppCrKyIbpIBGCJ3irv2euIl0sylmLAayQVQMAIQ6QdtySSCSMVwsXT8U3SSXLWwSdpAEEAYBBYnGNq27nKbYugLqUaLjEAzqb4iQWLSSRqYb7HyEWzlGK4vyNfK8FriRpaOn7FU+Z8z+Emsq7DAAA79TjCiJJ6AbHau/FCAmSTpyTuckZ+lFk9O21Y+mdaD5RUjztrn1y4pYcP4dRWfiZgASTK4OoxBitzknE/EkgMul9LBhpIIgn1G2QYNcv7Nswf7pN2bInxM6uxnvqVT/AJR2rXscMiWwFUQFEDsBgD0iKb4+ESnOo0yrduZ0jYmq/wBoVvf3ZsEggtqIBMrG2CIkxk9qsJ/1AOx/LNPnLxaggMGeyhDCQVuXbaOCPNWYU4OpGX8quKivJ5bmXMb7i1aa2xV/vImgqAvhkDVMamgrjfeu/LLwts7hNdzBVmyiSIxChtgZzIJjANBc/FNwmWm0snYQfCQogKRqkQOg7Vu3+VWxdULKgrdZoM6mLI0sWk4LN7GNgI1SnGKp+TB30XbBFwf3ZkQcnAH+LzrE55dugqufhEdASGM5V/LbBwZ69N7hrQSxAnxGST1zH6Coq9UwaTtCeO41ZTtcWLi6X0rdn5ACvSRE7SD3rpYvKPmB7fsUXOVpec6iwmJ0mJ9ce012+EpMaRgYjsBgVCUV2jZgzNR4T68MocZyqxcbV82CIJYRIdcREYuOJ3z5Cir68KPP606inJeTV6kT/9k= " alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUSEhIVFhUVFxUVFhUXFRUVFxAQFhUYFhUXFhUYHSggGRolHRUWITEhJSktLi4uFx8zODMsOCktLisBCgoKDg0OGhAQGi0lHyUtLS0tLS0tLS0vLS0tLS0tLS0tLS0tLS03LS0tLS0tLS0tLy0rLS0tLS0tLSstLS0tLf/AABEIAQ8AugMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAABAIDBQEGB//EAD4QAAIBAwMBBgMFBgUDBQAAAAECEQADIQQSMUEFEyJRYXEygZEGQlKhsRQjYsHR8DNygpLxU7LhFUOTotP/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QALBEAAgICAgAFAgUFAAAAAAAAAAECEQMSITEEBSJBURNhMnGBkdEUFaGx8P/aAAwDAQACEQMRAD8A+40UUUAFFFFABUS4qBvUtdv5xTSJckhvvBXGueVZ5uHzrhY+dVqRuOd76/nUjejmkKJp6i3Y8NUP7mrBdFZtSD0tRqbNMMPOu1nC7Vi3/elqUpodopddRV6tOaVFJpnaKKKQwooooAKKKKACiiigArlcdoE0sb/pTSE2kXl6pe/UGu0u14e9UomcplpPpVN5qgbpqL3D1NWkZuR1Wqc+oqjcKV1mn3lSHZds8EiWlSJ9PD+Zp0JM0Cs9a6qCsh9NdYt+927tsRuO3aBECR94T68dTXbOjuhwxuEjcxI3NmYjywM4zHmaQ+DWZKqpPU6d2YsGMYx3lxdwxzt+HI5HPXrNB7Ncz+82sfvKDLeDaQwJyOT8+ZzQLg11arQfT9KytZYuNOxgARByQQRJBWPOfy61FdM+xVLtIMsQWkjxYkRPI+nA4ooLNgV1WI4NYH7C5Klrhlcj4n3GQSSWysxwsR+rzhzcV98AAqVj4geTM8yF6dD5miitkbNrU9G+tMbh51jrdNX29UOs1DiXHJ8mlRSH7WPWprqvelqyt0OUUr3/AL0ftHvS1Hshqioo0ialSKK76SPzpFj6xWhc4PsazLwxVxMplFyfxT7VCPWu0VoYnJ9aS1/atizHfX7dueA7qpPsCc02xr5X2nobmlsOl1d2s1d42xdkMXseGSh5UMzBTMHxeQFDBKz6Loe2tNebbav2nbnarqWjz28xT1fNeyNPu1ums3VGnbSJKWz4n1DRuZu8HhgmTycbvWPT3Ptlpg0Auy7xb71bZNvvDnaG5b/SDTTBr4PRhvWuF/WvnnaHb6DtJ7zm53OlQ2z3YJDXGO07oxG5iMnJtiJr1Z7dsC6bO47ha7/jBtxPPQxBgxgiixNNGtilX7VsKhuHUWgi4Ld4u1T5EzE+lJWtRa12lY22YJeR0kiGU5Q49CD714Lt7sJdKunuBVbujt1BtOQ/eFpRt3KEiYBwCIzORhFX2fUdFr7d1d9q4rqZG5WDCRyJHWmN1fOftG1uzoks6Z3dtbcW53jku7qdpLHaJn/DEATzya9FoPtTpRYd91zbp9lpy6EO7fCMZJYlTM5GZilY9X7Ho5orFs/ajTsL8i4jadd9y26hXCkSIEwSZGJ6jzqVv7TaZntIGYm9aN5PDgoAxIP4TCNzjHNFi1ZsV3dWGn2r0ptWrqs7d8Stu2EJuuwO0gIPIjmY9arP2x0YW05ZwL3ebfASQbR2sGAkzOBEyaLDVnowa6rRSPY/aKaiyt63uCPMbhBwxU49xTwoGX23mp1G2sVKpLQ7pvhH99atqrTfCPn+tW1mzddEbnB9qz2prWHHzpF2gVUUZzYvNRNBFcINamFnK8z292Deu6qzqrT2z3QgWrm4LMsd0r18Q6fdFekNE0xJ0eRvfZS7de7fvXlN97bW7exSLdgMpXqdxwWH+o84hbRfZC+p0xe9aK6cuRbCMFDGWDz99t+0mQMKIr2sURSoN2eD0n2Jv7RZu3rZslxdu7A3eXrkRtYnG0Zg+pMTwj9qOzr2nN+53tstq27q2gUm4bRb4AThV2hVPM+EYmvo1+yHVkJIDAglSVYAiJDDIPrXndB9j1S+NRdv3b7JlBcM7SOCT1jkcCc0NFKfybfZOhFizbsj7ihfdvvH5mT868vY+yupSxd0guWWtXrm83m3m7ypMpEM3gGd3n8vaUU6JTo8jqfs3dtXDftEMLGlNrTJkut5UgN5E5c+5Fef+znZPf2rCWxF2xcu3Ltu9auG1dLFQpZwIkKoG05+L1n6gCPKpF6VFKZ4rW/Yi69i9+/B1GouK91ypVCikkW1AkgAlTPXYBArl37H6suzi/YBuWRpzFtx+z2BA2WRuyIESSDk8TNe17yjvaVBueI1n2DcXbTWLibLdsWyt3vAT8W4nuiu4MXYkSOSOK19D9l2TWLqHZGS1ZFq0qps7togkIBtA8Vzj8fpNeiVqlNFD2Zy3aCgKogAAADAUDgADgVfbtiq5rqtFAkM1C7cipIcVRqTkCpRbfBr2kgRU6KKyOgX1g8PzpC7xWlqh4T8v1rPfg1pEyyCtFFQvPtUt5An3gTWhzi1/UGSqiSOT91JzB82gzHlyRImt7d7aXVkIX4gQBGJ85j51facoCgPUySBls7m9CZNR7olSYwIn54FCZnJ3whXR9o7jscbW6eTe3kfSn6x7mwK+5SXAOwzARvOPMcj5VpaS7vRW6soJ9DGfzqmZ4Zt8N8l1FFFBuFFFFABRRRQAUV3aaNppASBqwLVSL51eDSKQRUlFcqy2oNIpFirFL3h4h8qZqpskehpIbRr0UUVidJC6PCfY1mXODWsax7nkauBlkKKjdSVK+YI+oipkVytTnKbtxSo8MNkkz5kyD6g4+VV94Y2yY8px9KuuWp4/wCT/X+/Ks3VdqKEKAW9wxuLRALEDgHqD0wCKSRnPjmyntNAqb9ykuSAqmTmI465iKf0dnZbRTyFAP8AmjP5zSnZ+jnbdcySAVWIFuR+bZ5+grSqyMcKbl8hRSt/X20IVmgtMYJGCBlgIGSOaaqU0+jZprsK6K5XVpgSx5Ubq6BQyg4ImkMzrnbNpbvds6iVkHcPik+E+4GPUQYlZjpu2VcqmA+221wEmLYe3vwY8XQf6vlXL2gt3wGfdtB8ADEDaDEkcENHHlBwchez9ltIuRa+4LeWYwikEAZ8xM88+Znll4lJ0dsPCOUbZt27ykxIJHQGYqzcPKsNrB0q7rZuPbUKptElj1m4GOZ4kZ9uoetX+8IAONiu21pncSFAcdPC0x5DpNbY8imrRhkxSxumPgirrBrNdEnaEkjkiF2zxLcz7ZqFnWmywW7PdvIDkhu7cAttZhnbtDHcRjaZJkVbIibRNVTmsT7RfaLuGFu2m64dp8WFCknyyTCt7evFaOk1qOiXJ2hwCA0A5gR9SBjzHnWUckXJxT5RbTPQ0VxTORXak3CsvWL4z8v0rUrE7VvkXMKSBG6AWPTAA6hZaM4X1FVF0yMitFbxQKqvX1C7ywCQDuJAEHgz5VYCa2OU7FI6yykoNi796ssASIdXuNPTAyesgdafJpHTMC9wn4gwX2TaGEehJJ/4oGMNS+s1CopZpjiBySaYmo3EVhDAEetKak4tR7CDSknLo8/o0AG4MQpYAAwODzIOSJIx613V9rPbCEK0sJKtBKiODnB9jzSQuBDcs3SCVYMjXG2hnwF8RmOhHPJ9qc1qqwBaSYYfh2MCA0jkjiPrXzmOOaE3GLrX71x+R76eGVSmrv8A7s3dPdDKrDhgD9RNXACsKz2owHCsIEAY8PSI/pWrpr4ddw9fXgxg9RX0GPNGfCfJ4mXDLHy1wMgioXr4UTyZAA8yTA+WfpNFU6m2SMEAqQwJ4BHn6ESD6E1pK6dGcatX0Q0ilVKqwfYAoBG2GVQIY5gGJ4+91EUxbYkZEHykGPpWfo9WplRcjbgqc7Z4C3QYZfLk+easS7btyTcXHTcJ9MTXkP7nuRaq7HLsQZiIMzxEZmsL7Hah7h1DMZVbot2uJFlV3KDAH/UMehHtVPamue8DbTwJIk/eIBBABHBwMg9TkEA079kE/cM/47tw5AEhCLKmBiCLQPzrXwmRPK4r45OLxc01SNMW3V2ZdrB4MElSrBQpggGQQFxiCDzOOs4yzgEIGJXlVlYJZiMnaSIA4Y4MiGKjZ0ygk553RJI3EzO0mOc+9eizhT5Eh2KlxLLXxuuW7Socddo3bgZDmQefxNjJrN7B7SOq8DqAyLDLI23LNxShXC4HwnaQQdscjHqKrTToG3hFDHBYKASCZgnk5rJw9Sa/X7mikauj02wHMsxDMYgF9oBIXoMcUxRRUm5C85CkgFiASFHLEDgeteb1mld7gJJDSzBocBWybbFTAICk2pBDEMTjp6ekdb8Xypx7Jk6R4bt/R3r9y3bVdoVRNssAlvY07lPDK0qMCQFMgcVt6RTZtW0clz8M+uSAC3oNonJgdTXn73bGou3wi29pD7Qp2zbIMMxYZkZJ+6RjMzXo7V8OilgQ24AqsGLttvEATggMhyeRUYdJSlOF31+xlK+ExhbkyMgwDBBBhhKmD05+hHINJhZvMeCqAerh2JBPoNhA9Wf5s2dKy/CwUdVILgnzkkR8oHpxGP2kl9nBtOuYCOZCI8fCRBJVoAwYnknAroshpDmuusIUKxB5YGAqznxQYPyz+lIYqCVAmOIwfpWXqtFqy4JuquYA2tb3k4g3VZpmcLKyY8IpW9ZuIYu2fmDvn2nJ8yeB1NeH5lg8RLNHLib4/L+f9nVhyQjDWSsev22uAuwhgV2tG0wOR6Lk/nSGjBuXC1tdxYL495O8jERwIAGR/OuIbRjwrniVGfY8H5GrRp0/Av8AtH9K87HmcG3O227On+pSVKJdqiVY70CMecASxJbnrJJ/OtHQdorAQxPCKoOVAHJmBHmSP65B06fgX/aK73K/hX6CuyHmTg7UTnyyWRJNG6+tQfFeQH8KEOw/Ik/QVnavUI54u3PIO/dp8lUTPuB70tRWeXzHLNUFxX4YosbUPG0NsX8Nsd2PqPF+dVKoHAj2rtcdgOf+T6VxSnKfbE5N9lequQvME4B/DiS3yAJ+Vem7H0/d2LaxBCLI8mIkj6k153R6Q3bgDe7Dotqfh92Ig+gMfDXrd1e75ThcYOb9zDK/Y7U7YqFSt8165ki2iiipKNmigUVidQUlrhke1O0rrhwfenHsmfRka/aitcCqGJRS0D7zBAWIyQJn2FZVpCL24u212uKrCAN5Wzjjqbdz5j1zvssilntgjaQCOIIkEe1ao52Ia5LgUDcHVmQHdAIlxglRBVvhOMbpyJFMXFZ9oKlQGVjJWTtIZQNpPUDnpVgsLxkgEGCzNkGRyeh/Spk1QrK9Vb3KVkCcZE4nOJFUXh3iFbkId0AzwwyroxAzwfQgjNOUvdsAkEzIDLIJHhaNwx/lGecUCM1dFbvotzAdlUsyRBYqJDDhvnmOorL1HZ1y1xO3zUFk+dv4k+WB51t6sLbKMoyNqFR1tE7RPQBSQQT5MByabG7yH1P6RXLn8Hizdqn8opTaPKW78iYx5qd6n2Iz+VS75fxD6j9K9FqOzrTmWQbjywlWPuywTSrdiD7t1x6HawH5Bj9a8nJ5RkX4Gn/g0WVGQLg8x9RUia0T2K//AFV/+I//AKVJOxD968f9CBT/APYtWP8Aa/EfC/cf1ImTLHoB75P0H9alpbBc/u/F0Nw/Cvnnr7L15jmt232PZHILn+M7h/t+H8qd2V24PKUneV/ov5Ill+BTR6dba7RmcljyzeZ/vFMg1MJXQBXspKKpGPLOiuiiaKBlymu1FTijeKRZs2zgewqVVaY+Ee1W1gdK6CqNYPD86vqjVHFNdhLoQNLmm3FLXDmtUc0iFcM1KKKokoXUljttruMkbphARyC0ZIg4UEiMxXdLbD/+6xfrCqAvSApB/Mk55rt3b3ZVvuDckEiVjbtx/mj5iq796IQAoI8KJHeuJ+iLj4iR7+fn5cuTfVHfixY9NmKaqw63DaaGFxlcOMEImzcpXP4eZA8fnitEAVCzbMs7RuaBAMhEUQqg4n7xmOWNWzXbj219XZxTq/T0c21zZUpomrJIbaNtS3VGaBHdtcIomuUwO0TXKKBEga7UK7NIZbbbzqcUuTV6GR/fNJlJmpo/gHz/AFq+oWkgAeVTrFnUugpXVnIpqk9QfFRHsUuiqqb4yKvpW6wJ/KtEYy6AComgtUZqiDtxJGDtPRhEqeMSCPqKhasqsx1ySSSWPmzHJPvU91RLUaq7C+KOxVdy+i/EwHviBBMk9MK30qdKarQ23O4jxiIYASu2SIkHqZj0FMRcuptnIdTxwQcE7Rx0kEfKqv2+1iHBBmCp3DEAyyyByOfOl7nZaNJfczHliQGI8vCAIiMRGB1E11uzlJDOWZhlWMArxEbQB08qOR8FyaxDMNxPQjgwYkZgkCp2L6uJUyPOCAfUEjI9Rilz2chjcWYglgTAKkncYKgevyJFS0uiW2SQSSYBnbwOOAJ9zJo5FwNTUS1drh9qZJzfRvrlcpiO7qA1cooES31Zpm8a/wCYfrVNWaX41/zL+tJ9DT5PSUUUVzHeFI3Tk+9PVnk1USZHCazNXf2LvPAKyfwqWALH0AM/KtC82Kye19b3NpnAlsKi/iuMYUfU1rE58jI6rXw4tWhvuEbomFtofvOw4HkBk/nViaRj8dx2P8J7sA+gXMe5NLdk9jLatgEnvG8VxlZl3OcnC4gcDHFV3V33xZQllQbr5ZmYQwOy3tJiTycYA9aoz59xrs64WDydyhyqPjxoAsmRgw25Z67fnTcelZ+p7atW94IaLZVPCsguYhFA6iVnoJAmcVaO1be51n/DXe7R4UU8S3Xg8TwaATQ1HpS2m1qXGYISdhgmPCTJB2nrBBFIa/tk90SqlGcKtstz+8JCsV5GAzAcwvSuaIbHS0pZAib2WFINrKIrsTKmdzGOpbNOhOXPBr7qo1mpFtdxBOQAoyXc4VVHmaq0faQuEbVO0hirGBvVSBuA5CknBPMGqrzbtUgPCWndf87MEJ9wv/fSoGy21pmbxXjn/pqTsT0P4z6nHkBS73Bb1AUeFGtXHcfdUoyQ0dMMwMcwPKmtbdI2FWMl1XbiGBPi5E4XccH7tZ2k/e6m7cPwW9tpf4mQl2+jEH3VfKmhMav6x1a1KgLdfZtM71lWYMTx93I9eat1mrKBtq72UFiJ2hQBPiY8e2T8s0j2jfnUWkWCUV3A6b38Ck+gHeH5R1Fd7TWVTTKTN5jvbqbQ8V1ifM4X/VToV9j+jv8AeW0uQRvVWjy3CY/Ol17UtFWeTtUgTB8ckqNn4pIIFZ2o1ZNk7XaL793bG0A27Y8LbNvxYViPUiuG3N1LSiBaAcgcI7Dan+xBjzYg+dOhbG5ZublDCcgGDyJ86lFZidpAr+7UlQGVDgByojwj8Mwu7zI96n2XqS6QxJdIS4Su0G5ALR9fzpUFj5HrVugE3FHqPyzS9P8AYq/vPZSf0H86UuEXBXJG9RRRXKd4Gs9hBg1oVn6n4j/fSqiRMo1B4rJ7YtybLQStu6HYAFjGx1B2jJhmU48q0L5zVdao5pclJvs+LcqOtxlI2j+BWEs3qRHvwcnslmtWry20LXzdvHaZ53EIXZvu7QDJOfWtyuzVE0YtrsQjuUZpVC126Zzd1BOJ/hlnP/NVP2dda2ysuWvi5dEr+9tC4IRDOALajmOI863qKLFqjMvaZjdtP3Z2IXO2V3d4VAW40nONw5JGPkrqezrzJqBjfdbLSIa0AAttOoxuEkDk+dbtcK0WDQnp9PBwuxQMAnxMYgTBOAMAT16QKsvaVWgkkMs7WBgrPPuD5HFX92K53dFhRndpN3Vs3BL3I2pMEl2wAAAABME46VPs7SC1aVOdoyedznLH5kmne7qWwU7FRjdj6Vpe/cUh7pwp5t2hhF9DiT8qp1ll2v3guG/Zwtvp8TNvI9ZC/lW93YqNywDyAY4kAx7UbC1MgaVluW2CeBLbIiyv7tvCAWz1AIkTFUfsd7u76jFy4znvJEMCsKBBkYAGeMnPXcrkU7FqZ2n08KAqbAqiAxBJYCFBIJ8I/X8+dkaZktqGBDAeKSCWuMZdiRjnj0rSiuqBRYakFUmtTsW1DMfQD6n/AMUlWr2QvhJ8z+g/81nN8G+KPqH6KKKwOsKz9WfEf76VoVn6s+I/30qo9kT6M8muVY2ea5FbHLRGKIqdQu3NoJgmATAEkxmAOpoCjlFK/wDqa+HnxEKOD4iSAsgkT4W+lSfWAMV2sYMSAIL7d+0ZmdueI9aAoYqm7qlVghJkx0JAkwsngScCeTVa65du4hgNrOCYzbUKSwgn8Qwc1SzI9wEo+9SNyyo27SGUuA0MAWDCJ5NAUW2u0bbKWUkgOLZgEw5IEe0sM1KzrUdSy7iBGArSQQCpAiSCCDNI2GsC1vXebcgjJM7ANoGeF2R8uvNdVLXdeDvSrME8LQ3S2FliCFGBHT60h0Np2jbJABJkSPC2fDu28fFtzt5rqdoWyQuZJjKsNp3MsNjwklWAnmKSRrO4Bd8/4YhgNrbSm6JADBQRIzEVwdwjBBuLWyiRuGSQzpukgNHjOcyfOgKNiok+lJt2mo5Vh/ifg4tQGOG8z71Ue2LeORILDAyBvmCDB/w24PUedMVDhNcmlDrlJgqwMgN8PgJO1d0HqT0mu6TVLcG5ZjAMiCCQGgj5iqIdjYNWAVWhFWUMaCtvs5Ytj5n6msSa3dEf3a+1ZZOjfD2X0UUVkdBwmsxjJmtG/wDCfY1m1cTOZXcXrVdMGqZ/uK0RiyNRuKCIOQeQRIIqc1ygQuulToq4/hGMz+uamNOu7ftG6I3QJjymrYpPV6RmYMpj4JlmEBWYkiMSZj+xAKi0aG30ReSfhHJ5P5UDRWxEW18JlfCvhPMjy4H0pazoXDKzXN0OzE+ISGTbt2yRE55xAqK6MhpZsd5uGT1DCJ92XBn4eeAAY5+zJEbRB5G0QcbePYAfKpC0vEDndx96Zn3nM1jW9G3wC+GIQr8Y3KW4MQeSY6fOnbenB3gONxtquGkoYYbsREyMgD4aAobOmQwdq4MjAwfMfU/WotZUHdtWcmYEyef1P1rMuWvDP7Uu2Lq7t0bt8gSwb4l8PHUGImmdPpCtwMbm8CfiYFsk54jmRiBigKLnsoeUUxu5Axu+L69ahdsJ1VevQcndP/c3+4+dJ/sDjbLkxPJ81QCIGYKk+fi55mOn0LowO/eAu3J/jYzEeTRiPh+lIhjA0yCIRfD8PhHhJyY8s1JLYHAA44EcAAfkAPkKkaKogmlTDVWCKkGpDTJE1udlPNsehI/Of51hVq9ivhl9j/L+VRkXBrhfqNOiiisDrIX/AIT7Gs2tO4MH2NILbPl+dXEzmuSuoXE60zs9PzrvdCqsjURIoFMXbZHBxUArU7Io7HrUTbqZtN1rgWgdFJqu9bDKVPDAg+xEU1sFSFiixasyR2ao4ZgBlQNsIdysYxnKDB/pHbXZqKSZY7lKGTyCqA4HB8AyI59BGr3PpQLXpRaHTM0aPiWYkbcnaMKysPhA6qKmllU3ED4m3HA5gD+X5mnLtk9AKVeTTRLtFTGekVWWq3u6quVaM2RrlFE0yAoqJmpJYY8Kx9gaA5Cnux7kXAPMEfz/AJVVb7NvH7se5ApzSdksGDM4wQYGfzNRKUa7NYRladGxRRRXOdoUvdWDTFRZZoQmhairDaNQKmqIo5VbWvKrQKkLZp2FWUd35moEL602bBqs6U9I+poTE4sWrquRV/7Gep/Wuf8Apy9SadoWsivvvSoPf9QKZHZ9vyJ9yasXSWx9xfpNK0PWRlPqAeTNAJPAP0NbSoBwAPlUqNxfS+WYv7LcPAPz/wDNC9kMeSK2qKPqMf0Y+5mW+x1HLE0ynZ9sdJ+f9KaopOTZSxxXsVrYUcKPpVlFFSXQUUUUAFFFFAH/2Q==  " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUKGgNKg7jpT6D4CorNODE2NSlUWF2k8pW5Q&s " alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZ0FRtEjesdYHDA4IyfdpmIkhmuKq8MGgPKg&s" alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqWLrlpYirDekqsxOpr9s3Oq2sVC7JuvThEw&s" alt="">
            </div>
            <div class="invitation-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUWFxoYGBgYGBcYGhgYGBcXFxgYHRgYHSggGBolHRgaITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy0lICUtLS0vLS0tLS0tLy0tLS0uLS0tLS0tLS0tLS8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAQsAvQMBIgACEQEDEQH/xAAaAAACAwEBAAAAAAAAAAAAAAACBAEDBQAG/8QAPhAAAgEDAgMHAgMGBQQCAwAAAQIRAAMhEjEEQVEFEyJhcYGRMqGxwfAUI0JSYtEGFXLh8TNTorKS0iRDY//EABoBAAMBAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAtEQACAgIBAwMDAQkAAAAAAAAAAQIRAyESBBMxQVHwInGhkQUyYYGxwdHh8f/aAAwDAQACEQMRAD8A9yXI9KftcewIk4mNhWeDRa5MRz3rulCzzceWlVjHEcc7E+IgTEeVUAmd62k7JU2wSciTqXMjp51ik5wMcp3rOLT8G8k15J1HOee1ESZgeXSPeitLJ2p+zYjlUTkomuODmT3ZPoftVndRWpZ06cgTGRSbHpXM5M7YQT0KXLRjBoFJien4imytCymhSB4i08fKgGZK5jHlWa6nr0p0ITyqGTypqZPasSYZiYxV/AzqXzmdto86sKdRUoCNsU+ZHadjjINBKgSQfj8qzdJG+/Onu8MRt1qt1mlzL7ToUaeVQpkfrerXSqzVpmbVGeGOPOoYmOVNvZB5UFzhiJBG3KtlJHO4MoMzFRqwPWOtEc8q72qiRjguHa5McgTPIxy8qi5w7J9WCcxM45Vf2dx5SQZKwYHnj450HFcRrOqIMQc7xU7srVGc4oApphLRYwN6cHZbdRW/JLyedxb8C9vjriqqhoCztzkznrRWOH1CZo37Pg/VI+KKzagmJBHn/fBrjy55JvhBte/+jtwwTX1TX2L+H4YgwN60bfDRuZoLbGATExmKvDyI51DTezrhljfFAsgGTAHUmPvS11hugZvQY9dTQD7Gq9Ym6qqe8SdLNLSdKmAzfTkgR5z6RdQM8vA8QYIx1mNJUroBI6MInJ8qmjVTaKG4zDGUAUSTJcgear/eq3vt4PEx17aVUdB/FJ5zjkDVzcHJhVcjxbwg0u2oqR9UDYY2pm3whEYQEbE6rhzvk6SPmlRo5oyk4sEISX8R/nbwiFydIAGWA6ZmarXiWKzpbbbXcaSVYgAzmSAPeN63l4Q/zAf6UUfjNQ/BHlcf/wAP/rRQlMy2UjvJ/hYAQ1wTIUz9X9UexoLdzwk5ENp/6rxnqTIHx5b4p82GH/7H/wDD/wCtcbLf9wn1CH8AKRpQjw3Fl20hnBgHIQiNKt0k/VHr61db4w9V5/UGt/SwU5Mg5IFXC04M+An/AElTmJ8UnoOXIUu/DAwTbMqRBVg0Q2v+ODk7xvQLZcL/AD0mOqw4/wDGT9qBWDfSQesHb25Uv3QFsW0uaGkeJgVYwI/i+o/byjFRddx/1EDAKTq/q1J4VIyIDEDmSOXNp0RKNmpwLEEzEefXyo+PMnAHWetUWLfhEyPInUR5TzqzTT5CWIRu2JztSzqQYrVvMFUscAAk+gyazLt1WAZTM/r5rbFJs588YwKHc0K1zGa5BXZFUjzZybZq8FY0hXyZ38qLibpnE88TvioS6cjYUJmuZ3Zpw9CpLuJfB5iZAz6bedcdRMqeh8U7Hy5GOtWsW5CaJVPOlQlCTfgi1eIjrOR5U3kGfMc/TlVSofKrrV0jBFSzox4q8h3bOpvqaDmAYGPSCZ8zV1pFUQqhR0AAH2omcASSAIknlVVzikBAmZmYIhQNMkknH1L55rI6yy6kjG9Qx8M7Yqq3xamYYYYrkjJUwYzOD1j4qVvqThlO3MfxZHyNqAKOM43Q4UyARIORJmIGMtkYP94k8XPd6QZeTklYUDJPuQPcV02yzghZBAbVEFiBGCd4AzHLyrtVpxqKpABALaPp6jOFO2Y2oAovcYHJChj4SVOwMaee5nVjH8JobV7WqsJgrO8fhTXd2xEC3BlBhc7yv2Mj1ouEuhlGmACMDw7CMwDt+HOk0aRnWhfVgEGasAqeFv2ysiApzJI2wJ3x7xtU3yqsBOTmJGFESxk/SJpNexUcnud3JYYoV4RAJUlcbA4/+Jx9qZa8oUtqGlQSYzgCTtRMPKmkZym2AUB8sTS3GMFiD09M1fxF2IJWRBziB/eYrPsE3HEjzjyq4wT2zGeZx1HyWlGYCYUEe5HPlH/NJN2XoUaRCmT4evoa1eMeWiNsfn+vSruFeZBG4H9j+VUvp2jOT7jqRgGz4Z/RqUsEVpNbgkEYmD+R/D5ohwZOwrXn7nO8fsUFcxRiz51XwDjvCpO6jT7Ez+I+Kc4u8tsSdyYA5k1nzOl4+LafoVCyaPufOrLN9WwDB6UbXFGDU8jXt06KO786juz1ps6a6VFLkHErbhpABYiCDiORB5gilR2OgjxMYMmdPiyfq8OZn7DpTrXhMagDjE5zMfMH4owetSUIf5WnVgf5hpndD0j+AD3brUWeylUqQzHTsDpjCoo2G4CDPrWgxHOpLUAZt3skatak65J8REZLNMaTJUsSNj50Y7JQEGTgiBiBAQYx/wDzU+opu5eA3IAO0+Qn8AT7Vz31WNTATtnfIH4kD3FACN3s6LaopbwSB9MmVZSTjeGOaLhuzVQsVLeIEcoWSzHTAxlj8CnmuAbkZrnuACSYFAqfuY1zsI6gVfw4DAxkAxEBf5WYctlp3ieyw7M2twW6FcfTtK/0A550ytwwSYAznyFRddtJK/O+KdbC1RRY4SA8+EuADpggAKF5qJJAE45DpV925GSRA51W906RqgEnHpQmIjBkfNNRJlIW7S7RCqofKudOAfbMQD6kbVZ2bcUsdGSADvnM/wBqDirSspGkHA6RAyPXevOp2ittyVDHRpLACCZYZIG2CT/zUylWgx4nNuXov1PUPBZgTBmrbODC5x+YrMe4ohhhGAIk7SJg5Oc09wPELkyMADceZqmteTKLfKqCvHxNPv8AAq63xTRyrNvXpk/zfh/xR8NexHSr4kdzYhcIbGxGQfMedEEmCJY9SST6Saoa2S1O8FaGpR5z8Z/KsrPbyY4L6q2McHwThgzELmYGT6E7ew+a0ismfKoCj9frzriooPP35bsE2zkDYmalrW/nFdIqviLqqpZjAHucmAAOZJxHnQLSK+L4IO4eSCEZMb+KIaf5lzHTU3Wu4XgdLBu8Y+EiDtli0+UTAHQCkuK428NAUKrXDFtCNTHElmaYCgZMA9JMii7E4m6730ukFrThZUQhBUOIGSDBEgk1XDVkd36q+e4Y7G8Ok3HOAJnlqZjseer/AMV6Vbf7N1av3jCRHp+o+c09NZ/Z/aPftdgQiOUVp+sr9ZiMAHG+YNKmW5JOiu92TMEO0+P5cOJB5EB//FelH/lcmTcJOstnYS1toHl+7HyafCj9frzriopD2J2+AIUDUZ1ajknZpCg8wBC+cdaqtdjaVVe8fCsJnqZB9RLD38hQnji3EPYQqvdorEkaidU/SJGBAk9W5c6+G7Sc9zbe3pvPqLrOERGI14nfwwJO5ziq4sz7kfn6Fl3seVZe8YagRHLLljjzpi/2eHMh2XwquMYUOB/7k+qqeVOKAKIipNNiXE9mq765Iypj/TI39DXcPwuhQpJaOZ396cmguZ51SImZN8EEHoDWLxXCkziJ2HPpg7jHSvQ8Xw/OdqDgkIfkRpyxwQQQABjMyfgdacvFmUHKMvolTMQM4RFAnSRuT9JwQPar7EohUMCS8zgeHO4CgYOOfrypy9wTNccgyJBziMDHn196rHYy3PrI1CQAdLCJBmPUfYUkoJXQS70ptNlXDyQZyZneM8oxTnCpAzEnf4iq+AsBBBk77kzv/UZ+af4e1irdXZlG64iMU32aniJjYfjStu07HwgadtTSM+XWtHgLTJIYCSdwZBEcufzWVHqzzwkml/T+41oroihVyekVKuZjFBzhgCsO5xN66bbpaTu9epdTkFhofSxAUhRMEb507Vqi7JHmYpZuCGVV3VZjSrEfB3UeQiqi0iJxkzM4a6L3GuxOkW7XcplZ7xoe7pmQzKNIO+1K8D2m3C9/ZYd6bd22ltsK1x741AOdtQmS1bL9k2pQImk250Mu6hvr35nrv96sPY9k2+7KmNQedR16wZD65nVPOr5R9fBh2p+U97/Pz8CPEduOq8SGRVNi0G1BpBd1YqoBA6D5pbsXi2sLZ4c2hmwbgOoatQjVqBEKCWmZMedaT9hWR3jaNRuCH1Fm1CIJyd4570PF8Mlm29xUa6xUJksx0HETk6RJMD/ejlHwkNwyJ8m/H9L+32B4TtcunDsbYD3zhQZhACxeYyIA5bsKt4u/ea4bVnQuhVLu6lvq1QqqCOhJJPP4z/8AD/ZbI/eaQITQitqLqm4lizROMSQABHOtjiOGDMGBKvGnUpIMCTB5MN4kYk0pUnocOco/Ued7cLG0OIlf2izdVLboCBeDFfBpJJIOoiJOVMYNDd7UKX+LvrbFwoUsqC2kBVgETBlmuOYHl8+hHZy69Zl2XYuSYn+UbL6iqbnZFkoU0wrv3rZadeoNMgzvVKcfDJeGd2n/ANp/5/BXxPaxm8LaBu4QM5ZtIkrrCLAMnSN9hI9qk/xINQJQra7jv9RPig6YGkddUDOSD601d7JsmToIDqquqkhWCiFDKMHGPTBq09lWi/eMvi0BIk6dImBpmMajnzqbh7Fcct+RLiv8Q93lrY0slo2/EJZrsgK0iEiDmThTS/Ff4hZLdx+5Vu7ZQGVz3baomHIzBOnEyfQxo3OxbPdd3pJEqZLNqBSApDzIKgCM0Z7LtFACCwDC54mYksu0knIHQ4+KE4ewOGZ+vz9COGuO7tqtabcAo2rxHMeJI8PXc/jFl3hsbU0bnIDlNcz7YqbL7f8AEz07StMSFII3kTtz96puLqYEH4nMGfyrOvdmXbbsEtgocgg5EiIIPOZNaPZ1h1CGABnDGIwfzrCMm3TRtKKrQxa4TrTqJG1QtzAMev66UaN1rezGONI4nkag+fKq76kwRRWwQIFSbUqCwOVSYmuAPOozQIAWwDMZooHMedEGNRqPSgDrrhVLRsCftNJr2rbM6pWPI8kV52x9QHrTmmdxIND+zr/KvwOYg/YR7UALDtW31J5RpaZ1BIiN5IxQN2paEhiRAkiGiNYTeOpHzTotJyVfgdZ/HPrVN7hUYFSiwd4xsQ24g7iaNhoq4ztG2n1BogEmDhTPLc7HFTf7QTQXALaXCYBGSwXGMjxcp50weHBgFVIAjIBgdM1wsgfwrBMkQN8GfWedACh7Ut89QIHiBBlfCWIMdAp9xU/5nbJjxTgRpI3Cnn6jHnTQtLJOhZO5gZ5Z9vxoVtryRPYDlEfED4oDRWOPt6UOdLfTjoQB9yBTFq8rhSCDqUMvUqYMxvzFQbIIgqpA2ECAP+KsCxt8UAJcF2mlzTEywBiD4ZXVkxG2x502VxGwzUJbURCqCJjAETvHSakv5UBoBEgbn/ajMQK72rvQUBZDe9cIx5fnU6/Ku1+VAHKoiOVWVXnpRaaAEe1OK0ad4M5ETIiBJ2FBwXFO1rUdwY2yRiT+hyrr1xSwMBgcEHOJ3INPC3BEDAB9BtWKxz7nLlr2Nm0oJOO78i3B3yzHpykzHuacDUlxFwLpBBG5kAbirOAbUCSBMxtSXUQeXtevz/JMotrl6DRFZXDcQ1+7dAcpasv3fhiXcKGckkGFGoAARkHPKn0QiIGef651l8Lwj2bt0hC9u7cNyVjUjkAMCCRKnSCCJ3OOdbihVP3APF3hfs22JVWe9/IS6IilCSogZJxg4E1rpxam4bedSqGODEMSB4ognBxNYna/C3rt206qyaVvxDLIY2wEkjAlhsCdsneqeIHGshgXATYtRBtiLyuwuTnmCD0xy2pGrgpJbS/6enIrq8z2twnFqYtNduKqoUIKTq77VcDzE/u4A9OuaG5d4gcXaD6wty88CV0G2OHLKsA/UGBJ9N4iglYb2mvX8HoOO4nu7bPIAUTLYA9fKo4XiZw31GYOllDAGJAO3pPntWT23wTtfDZKG2UEANofUG1aCRqBUFTGYPQmo/w3ZGq8NOLdw2wSAW0hVYSc5hgCP6ZOSaA4Lhd7C/xJfbu7kOyhWtWxpJUzdZAXJGcB4A2wZnkfY9zRxF7h1YtZtpbKznu2bUDb1bkQAwBkiap/xX2c1y2dCMzlrf0xBVbisdWrGMkf7xUnsy536aGdLQtajAtqO8FxTpKgRldQMD3mKC049uvv/b/ZtcJxS3UDpOltpBU7xswBFGzGMb14/tC9xluwrv3gIslWOpMP3yeIweaSJpxbfGayD3kEcQCVZNIOoHhyomQNII2mTnOaLE8HryXr6+x6YDGazuCvs3E8Qpbw2xaCriBqUsT1JrHaxx3duAbms2rDKdSYuT++XcEeg5AwZqmxwnFrN0rc1n9m1DUhLhVK3Z2BPxvQNYlT2vlHquG4pbgJSfCzKZBGVMHcZHnVs1ndmG6O8F7Vi4+gyMoWJSNJ5CN6ecTG/wChTMJKnSCuE8hNEKqcZO+2N6HfzgZAPPGMc6CbLWeuS5O2fTyrG44nWYJMBfYkZEfB960+zli0g8s+pyfvTCtJ+9/hlTcKi+LnvnY0PGcYVAOQCYJiYEE45TRXzrcLyH6NM3LSkQRI6GpyRbjUfJOPLynctpGf2bdN2dWQpxI3nr5jy61oi3G2PKhtcOFEKAo6CjjrWeLG4xXLb9zScouT4qkdmoz1qdAqHEAwJMYHX35VqSGFqNNZ9jtEGC406mZViWkrcFo7AR4iPY+tF/nFqASxAIYglWEhVDkiRkQZxQA9qpTieCD3LdwkzaLFRiJZShJxJwTz51Una1sg6pUgOxEEwqOyE4H9MxV13iQAjKuoOQN4MMRkCPF/Ny8IJ9QabRdd4cMIbPP0PUdD5+dRa4cIAqAKByAxkyT6nelE4piY7pvqKkg6hAC5mP6oPQq28VN7tAI5DL4QyqWnm4LA6Y2xnNAvSh3PM12aTHaNqJ8UASZRhA8UEgjE6Wjr7io/zO1qC+IE6RlGEFioAMjGWAz1oAu4/gBetm27GCROmASAQYyDvHrTRFZnC9rW3CHxBmAOnSxjCNuB9P7xfFtmmDxvgR1UsrlYnwmGIEgESd5jGATQO9UNTUEnlWfZ7U1gaUmWUb50vEMBGTBJI5BTmrez+MF0EgERG/MMoZT5GDtQIbCmhY+YqdJ61VesTmaAVep1+42klRJ5R+OayNLAz4lPM+JZ9+dbip50N6yGUgmgqL3Tpr+KPPPejA3mnrF8qMVVxHDCf1g8x+utSKDuqLiklo1bdoBj1NWg59prmG08qjczT2eckl4OFzyqDdwcbVKADnXQM/rypD2QjzGCJqVfy5xQjHPbauCj0/W1AaK3sWzC6Fw2oeEGDOosPOcz1ol4O1Ed2kZxpH8WGx5irguZqSKA2ZnGWbaMii0AHlNaiNM5iQJGqT055kiV7vF2VeO5ltShSR/Gf2dBgjwQLtvP9JxgTr3LSkgsoJEwYyJ3g8qqbhLZEaF2A2GwiB9h8CgBDg+17AUd2hWQrQEIy4twMCGP723MdasPH2SvfKgYllUErBJfSq/UJAhxnofamF7PtAsdI8RBMgfwhAIxgeBfirBwlsDSFUL/ACgCDgAY9APigZmpxHDzoNkAjXbgJIgTqUECIPTz2qU47hTDAKRqVQQuzE+EbY+kH48qf/Zbcg6VxtAGOZgxjf70LcBaODbSJBA0jBA0gjG4AAnyoEJPx3DgoBbByT9EFfDcOoCOfdECN48qd4bh7LqrhFIMFcCMCFI5DGMUZ4C0dJ0IdOx0jEzPLnJ+TV62wBAAAHIUDKLvC28Eov1avpH1Hn6438qIcMinVpAIJMgRloBON9hRC4DjepKyImgQTXAP9q43B51GnMg71LLMeVAbOYiukevOhYb53qCoPPERQAp2mBGv5/vSlu05E6G+w+xMitg2wRHp9qOKNF9yaVJkFqHV5UZWhZwu5A9aLSI2D6ipnyotVSDQAAbyri3lRla6KA2CM1NdqqQaA0dqqq7dA5cwOQ3IHP12q0rUEgbxvz68vegNiHGcboRbmmUkaoyQDIBGnB8WkehPSqbna4QlWQlk0hoKgam0YGppjxjPka1A4iRBHXlVTuxymg5zJ6YjHPegNGe3b9oT4TIAxKidQUjcwPqG8U+/EgRjeOajdlXmf6vy3q1gAJaB1PLHrRLByIPnvQAIoqkmuDUBoERk1DOKMiuAoDZXg/r9dK4jpRlq4GgNCJu7gzTFkgKKtuWwd6ICgtytAA0UUF69EACSTAG33qh+O0nS6wfIyPyrKeeEP3nQljcvAr2vxxtlV1Rq8s/7frpWd+0sSstrCyYOQY8xnlPxVt/g3eXYgM/r4U6evL2PWkW4B0lpEATIn4iK3n08MipnDj/ac8ctwuP5+fp9z0/B8RrUNIE7joelWic+X9qX7PsBUXw5IBPqd6Y22FTVHZae0tAqxxzmoViTnqft50YI6Zri3QUBor4i8EDFvpUFj/pAn5oH4+2BJMeLQZ3VpK56CRvtV72gQQwBBEEHmDy9KE8MsRpEZxAjMz8yfmgBQ9q29IcNiAxBB1aWUsDG48Kk+xoO0Lttz3TsQYW5jEDVCkHkdW3nFNrwlv8A7a7QcDaCsfBI9DXXbCE5QExExyGw+9AaMtLFgQFuGAVVQCpGdJB22yM8p6k1W1qxrKd7cUjvNWwgiEM43PeCOZkdMav7Ba3NpZ/0ifwom4NN+7U+oHMg7+oB9qAMmLYF4d8WV10EY1BRFpmnaNR3iOdFfSyWYm4wlQSuPD+7cDljwktJO48orT/ZbZJJtLJBB8IyCZIONiTtUvw6Ese7UlsMYGRBGcZx+NACVriLdkeFyysCQMESAuxAHLl1mnl4u3pJBnSuogZMZ5exqF4C3H/TX00joB+AFT+w2wZCLPpvgjPXBNAFR7RSAQwMxjc5XWNv6c+lW2uJVwWUggRtPMKw9cMD7137Jb/7a7RsNoK/gSPQ0SW0UaVUAY2EbCBt5ACgNFhOSBGK5ycbZoSAcmakxigAXJzHIVi3OJ+llOCsyJ351scQoZWGQSpHyDWJ2XpZe7Ii4sj1EyR7Gqq1YoZ1jyqEvDv9fYLiOMLKsjb5zRWODdhIH3H50F3hyMRHkaY4e+yjBry59B3csp5Hr0o9K6j9BcWnIIj9RVHEgnSn87AewMt9h96budlrMoSh8tv/AInFFwvAFW1u+sgQPDpAnfnvXrckfO9jI3TX8/mxrxVMmiJrqzPRBg12amKkLQAIJqdXWpLRQlATP65/3oAjWDMESDBzsYBg+cEfNQ1wDcgUrd7JtNMrMsGOSPEJ8WOefsOgqR2TakmDJZm3O7RP4CgBkOTsRQ2uIBJAIMYPyR+II9qW/wAqth1cSCpLRgyT6/r7VPE8Pb3KsZuBzAJ8QUICY5QAPvQA07gAkkQBJPQAZNdbugiQwI8v15H4pax2ZbVWVQQGXQZmdPiMTy+o1L9lWiZK7/GVC7egH6JoAZDHqKIPSJ7Is/yn5M7Ab78quscEi6io+oAE7zAgUAMmhk1ypG1TpoAHUelTqPMURNcDQBXcBIrO43snVDKdLjn1P9/OtSK6KadeCMmOOSPGSMMji40lUYfzGPncfhTtjs+FGsy3ONq0Ca4Gm5X6CxQeN6m392VMxB8jiiJMgeR/KjoSx6VJoDa5Zz0/W1RsTnbqaT7V442wIHibby86wLlxmMnJ6mk3R1YeleRW9I9Vbu7Zmd6gMZ8pNed4W46+JTB+3uOdeg4TitahozsR0NCZObp3j3doq4/vRp7oA5lpj6YI59GIPnBHOjsNd0HUviAxGnJ0j+qJ1T0FUX+znZy63SsmQNwD3Rtzv5gxtjzmr/2dtDozyG1AHmoYQBIOY9vzpnPoTu8XxCwO6k5yCIaFG8Hwy0/26Sb3E6BC5PM6MYWMTGTI3o7fZ90TF85kkkTJKIq8+WknHWov8FdMjvsEEEaeqleuNwfagYAu8TqyoiVxK7EeIb50nnz286t1XyJK6WJXAKxEjX15TUfst7BN7AZTkDYCCszzJ3ruJ4e/LFHCyTA9dIkn2Pzv0BaKjxPEwQUAIUQZXLd2xOAf59K9M+VdcvcUGMJIAuc1HnbO/t/arBwN3J73xEbxMdPtjAE0Ldmvn96YOoRHJthvyOZoAK+/Ed2Cqw5ZZEp9JQEwTiQ0gf2o3uXwwi14QTzSSIMH6t5AHLc7xR8Lw10MC9zUBGNMfwwc+ZzS6dmXFt933uIIJ05IKgZzygx5eYkgaJN/id+7iBtKGTpJOdX80CnrV1jbDEaWKgkbwYyJ55pU8FdMTekShI076N+eJOfaKt4Sw6SGfWIUAaYjSIJ996AGTuc7Cq+IuhYlws9YpbtTiiqgAeI7TyHM1h3+pknqd6TZ04Om7it6R6VL4aYYGByg1LXTiOk7V5RXIMjBHOvR9mcd3iSR4hg/rzoTHn6V41adoaJIAPzRBaHflAoGaqo420i1k6GK4LHOke1ePNsQPqO3kOtefLlmlyT610YumlNW3SInlUX4He3Qe+Gf4MfNIR51bftYkcqCufLj4So9zo8qyYU16aJtE9a2ewwfHnEj5isQ+QknAHU1v2WFi2A2WOSBuT+Q5VCF1f7vFeWaE0QNZvD9sITBBXzO3v0rSiq0eZPHOD+pEMvtVC3lLMoaWUZq+aW/Y1Fw3dmYQfMchRshUL8axYhJmZMAHIxuIOxjnVlpLjYbCiecEmYMj+U7jNSUBAAV8mSQxU+7Az8YxS1niweIdDeDKQAqBYKtsw7zmcTG/i8qjVlU6HbhMxMQJ9fKTvV4TzpRPCsaCADiSTucxz9qbEnfFUnYno73oga4Ck+N7QRDEEnmBy9TTHGMpOkNlagKaT4PtRXOnIPIHn6GnaAlBwdSWzF7bJFxZ20/mZ/KspmJNeh7Z4QvblfqXI8+orzqmalnq9JJSxr3REGtX/Dimbh5Y+YrLby3pi0hVY1MOZgxnrWmHE8jI6/NHHjp+WekeeoqgtWHw/aTrgksOh/I1q27gYSNjW88Dx+TwnksyO3iTfJ6KsenP70m3L1rX7Y4Yv41+ofcdKw7PD/vFuAHUGBI6wI0+VdmLIu2q+xFRcnydfPAzbDA/S2+0GouKQNWlt4gA+s+la5s3NRP/wCVBnGogCTIiCIgAL6TOSTRcJwdwQ5fijsNDPjmJifMMf8ASNhiuXPNzjuP5Orpsrwz5J/y9yeyeAAAuZZzBEgjSD0FLdshu9fB2WDnAj+805b7JfIN/iTM7ueYgQRBxkjPPyEWv2QxB/f35M/xkblmjG31Y6BVGQK5KOiPUy583s89etkbggHBwa9DwnaKBUVnzpEyCMxnO1Jtw1yHBF99WkQ5kDQZkesxPOMzWbxOoGGBBHI109P06n5ZPWdW5JKto9a2RvQzjbMRSHYFwtbIP8LQPSAfzrSI6VjOPCTiZRdqxC/eS0V7xiA+wz9UqvLl4h8z1pBu0OGkXBcJkgxDfxZmI3P960uP4UXlNt/pI95yJB5b1mXewbSKzS2JbedizgRG0scVm0x8khzgO1Ld8tAOlY35k88elNs8AY6/rFef/wALWAveR0Xk4wJAw5PIcvKt+6PP9HH69DTXgltkgnTM7Z/2rz/FEhmB31GfmvRrWd2twUzcEAgeKdiBz9aclo6ejyxhOpepjTBBBggiD0zXpOH7RtsYDeLaDIn5rzVu4MHfEj5Iz8GhuOSZrpwdLzjchftDqV3OMfTyet1YWTAivO/4hVUh0BlpmNsQJON81s8BeZ7SFtyM/hNBxJkKsZLL8KdR/CPcVg4eUZYeo7c1L0MMoQRpDFSAQdJzIB/Oq3t3DEq+/Q/2p/jr8XG8d9dQUwrqFgALgEY2+9UDipWGu8QTqDBg6giNQiIIIIbIM7A4rtxOcYrjA5ss1kk5SkJlSBkEHzxWj2OSUM/zH/il+N4s3CgAYlVCyxBJ8zGK0OCtaECj39a0zSfBX5Od0nouZxSb8GNYuBmkEGMRI9p+9XmurjcU/JDd+TL7SS0jBu6LFi3h7xtOdZbwwR/G3p7VfZ4e1KubbhgOd1mjxav4pGDVvHHw+6/+wo2GKvhCvA3mn7kcLatFCugwfCw1k/SEUf6RptrERVtnsThyAIfBEeM8iGgmJIkDB/tFXDfW3op9/EPwA+KddoRiOQP4VlKKNoZJPyKcZ2bYt2tYBAUgAayJA7tQZiZ/dKZ33zmqRwdy6VhdKhVUFiT4QAAZOWNa72wbTKRI0xB6AYpiIwMAVWPJ21pb9zWS5b9AeFtC2oUbD5J5mqm4xA2ktnbynpVtU8RYVhkA1hPk9ryPlXghuNTWF1ZMiP16VYSGWDBOxB67fHOsUKInnJzV+5VzOrrJ9OVYrI0rYuY+1tFB0gCTBgDMb/nSv7TMETv/ALfr3pi/aGDHOPnemlsLEaRFVNTbpOilsLTQ3H36CjFLcTt7r/7CtkhSZj9rWwDbMgM3hjz3x7kj3FVcP2c7EapVefU+Q6etanEICVkA+Kc9QCQftVtdSzuMOKOd7dlgYQFGABEUqLkktOPpX0Byfc/YLUcYxCORuFJ+xotIAjkMViojc3RmcRxWm+moQsMA0SQzLAxkYJG4NOOjFWV7quCBGm1oIIYEmZ6Yqp/rX0Y+4Kifufmrq1bumvQzWRpUL2LIXC/NNLioIiiSiTtmas//2Q== " alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFXfhR_PP91nNGYGc8G6v0SWybZNZBsUSE2A&s " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAYsjuDsW1jGTGJUnccs71xtkZi7uOgeFiuA&s" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVrdAvAruP-BaQFeZU_yzsl3iHtK9-Itg0JA&s  " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIbegc4yRLK6Y09exNMUXPmFiLxREgIXLjOQ&s" alt="">
            </div>
             
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>