<?php 
 
 $con = mysqli_connect("localhost:3307","root","","user_registration") or die("Couldn't connect");

?>