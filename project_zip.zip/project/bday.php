<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B_DAY PARTY</title>
    <link rel="stylesheet" href="all_event.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://www.shutterstock.com/image-photo/birthday-desert-restaurant-260nw-2305158231.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

          /*-------------------cake--------------*/
/*gallery section   like ch option nahi yet*/
.cake .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.cake .box-container .box {
    height: 40rem; /* Increase the height to 30rem */
    width: 100%;
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    cursor: pointer;
    overflow: hidden;
}
.cake .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.cake .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.cake .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.cake .box-container .box:hover .title{
    top:0;
}
.cake .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.cake .box-container .box:hover .icons{
    bottom: 0;
}
.cake .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.cake .box-container .box .icons a:hover{
    color: var(--main-color);
}

@import url('https://fonts.googleapis.com/css2?family=PT+Sans:ital@0;1&display=swap');
:root {
    --clr1: rgb(21, 12, 104);
    --clr2: rgb(236, 68, 90);
    --clr3: #fff;
    --clr4: #000;
    --clr5: lightgray;
    --clr6: yellow;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    font-family: 'PT Sans', sans-serif;
    box-sizing: border-box;
}

html {
    font-size: 56%;
    overflow-x: hidden;
    scroll-behavior: smooth;
}

html::-webkit-scrollbar {
    width: 1rem;
}

html::-webkit-scrollbar-thumb {
    background: var(--clr1);
}

section {
    padding: 7rem 9%;
    margin-top: 7rem;
}

section h3 {
    font-size: 3rem;
    color: var(--clr2);
    text-transform: none;
    text-align: center;
    letter-spacing: .2rem;
}

section p {
    color: var(--clr3);
    font-size: 1.5rem;
    text-transform: capitalize;
    line-height: 2.5rem;
    justify-content: flex-start;
}

section h4 {
    margin: 0 0 1rem 30rem;
    width: 40%;
    font-size: 4rem;
    color: var(--clr3);
    text-transform: uppercase;
    text-align: center;
    align-items: center;
    letter-spacing: .2rem;
    background: var(--clr1);
}

.btn {
    margin-top: 2rem;
    padding: 1.3rem 4rem;
    font-size: 1.5rem;
    text-transform: capitalize;
    letter-spacing: .1rem;
    font-weight: 600;
    color: var(--clr3);
    background-color: var(--clr2);
    border: none;
    box-shadow: 0rem 2rem 2rem rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease 0s;
    cursor: pointer;
    outline: none;
}

.btn:hover {
    transform: translateY(-1rem);
    transition: all .5s ease;
}

.title {
    text-align: center;
    font-family: sans-serif;
    font-size: 2.5rem;
    letter-spacing: .2rem;
}

.title span {
    color: var(--clr2);
    font-size: 4rem;
}

.title p {
    font-size: 1.8rem;
    font-weight: 600;
    color: var(--clr4);
}

/*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}



    </style>
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#cake">Cake</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book_cake.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1>Your Birthday,Your Way</h1>
                <p>Find the best B-Day vendors with thousands of trusted reviews</p>
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.DVkiQu9EHGfac90jVHhnVgHaHa&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 1</h3>
                 
            </div>

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.mpxxKrvOk-cHo-m9FKGi3wHaHa&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 2</h3>
            </div>   

            <div class="box">
                <img src="https://sp.yimg.com/ib/th?id=OPAC.574I5SoZU3aYng474C474&o=5&pid=21.1&w=174&h=174" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 3</h3>           
            </div>
    
            <div class="box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.1W836D0Ou_ngzlMK-XdMLAHaHa&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 4</h3> 
            </div>

            <div class="box">
                <img src="https://sp.yimg.com/ib/th?id=OPAC.m7UB69dk%2fd%2bHfg474C474&o=5&pid=21.1&w=174&h=174" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 5</h3>
                 
            </div>

            <div class="box">
                <img src="https://rukminim2.flixcart.com/image/612/612/xif0q/balloon/v/j/u/3-1-foil-latex-bady-special-decorated-items-banner-balloons-original-imagd43yjcty5wjq.jpeg?q=70" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 6</h3>
            </div>   

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.6UMvPZfdW5N6dg2nK0nZ-wHaHH&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 7</h3>           
            </div>
    
            <div class="box">
                <img src="https://tse3.explicit.bing.net/th?id=OIP.59eBWwxMZEMvy7_b5rMThQHaIR&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 8</h3> 
            </div>
        
        </div>
    </section>

    <!------------------------cake-------------------->
    <section class="cake" id="cake">
        <div class="title">
            <h1><span>C</span>ake</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://cakewhiz.com/wp-content/uploads/2020/02/Kids-Chocolate-Birthday-Cake-Recipe.jpg">
                <h3 class="title">cake  1</h3>
                 
            </div>

            <div class="box">
                <img src="https://4.bp.blogspot.com/-1cC8seqs9FA/Tc4NOC9vjeI/AAAAAAAACXg/NEiHyjFcgAY/s1600/IMG_8904.JPG">
                <h3 class="title">cake  2</h3>
            </div>   

            <div class="box">
                <img src="http://thumbs.dreamstime.com/z/birthday-cake-14391154.jpg">
                <h3 class="title">cake  3</h3>           
            </div>
    
            <div class="box">
                <img src="https://oysterbox.co.uk/assets/oyster-uploads/2015/04/Banjo-and-Oyster-Box-Large-Birthday-Cake-Day.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  4</h3> 
            </div>

            <div class="box">
                <img src="http://hdwpro.com/wp-content/uploads/2016/07/Best-Birthday-Cake.jpeg">
                <h3 class="title">cake  5</h3>
                 
            </div>

            <div class="box">
                <img src="https://prayface.net/wp-content/uploads/2014/01/photos-of-30th-birthday-cakes-for-women.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  6</h3>
            </div>   

            <div class="box">
                <img src="https://i.pinimg.com/originals/28/86/bc/2886bc1187c03eda63ff764852836fad.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  7</h3>           
            </div>
    
            <div class="box">
                <img src="https://i.ytimg.com/vi/CzhyBI7iT_Y/maxresdefault.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake 8</h3> 
            </div>
        
        </div>
    </section>

    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src="https://static.wixstatic.com/media/3c8914_a144041ad92c4f4cb688dac4fd87c3b5~mv2.jpeg/v1/fill/w_640,h_426,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/3c8914_a144041ad92c4f4cb688dac4fd87c3b5~mv2.jpeg" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Kolhapur</h2>
                    <p>The grower</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrBMqx8ppoC8yblD0Eray16MNX2wA-fKiV45fDdnC4FQPffv-QEnkAg9eyeeR503rqask&usqp=CAU" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>The orient crown</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://media.weddingz.in/images/55d2490a4961fe7b0f345048f381da27/bluez-terrace-cafe-bluez-terrace-cafe-terrace.jpg" alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>Dehati</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGBxQUExYUFBQYGBYZGyAdGhkaGx8dHx0iHx0ZHBwcHyEcHysiHxwoIRkdIzQkKC0uMTExHyE3PDcwOyswMS4BCwsLDw4PHRERHTspISkyMjI2OTkxMjIwMjIwMjIwMjAyMDAwMDAwMDAwMjAwMDIwMDAwMDAwMDAwMDAwMDAwMP/AABEIALcBEwMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAEHAv/EAEgQAAIBAgQDBQUFBQYDBwUAAAECEQMhAAQSMQVBUQYiYXGBEzKRobFCUsHR8BQjYnLhB4KSssLxFjOiFSQ0Q0Rj0hdTc4Oz/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQIDBAAF/8QALxEAAgIBAwQABQMEAwEAAAAAAQIAEQMSITEEE0FRImFxkbEUocFCgeHwMlJiBf/aAAwDAQACEQMRAD8AqWWWFB1xBjb1j12v+GNMnIGbbeHmTtiGmSYEdb7bC+3O8f7Y0GAAk78+fL8xyxu1TwtO9yYCGWD4THhMX+njjDQ5A2Hzva3LED8j48/L9cueJYEeP6/XxwC0OmOuzOUL60W5LKR16bTtcfL0Z/8AYjSQInx2GPHYHMinXlrElIMxPfEjfe3yOOp/9nUn7+m5kzzEzOPNPUZA7Ko8/wAT0sPTqyBmnJm7P1CGYkWPIgYkocAYjUHWPHlbw+GOica4RTFKwMzB8d8L+PcJp06NN6S6SYmD4D8zhR1WTg8yrdKniVfgnBkaoEqMokGO8ImO6DaYnFtzfY6g9NYcKROphHeG8/4f1vifhHBl9ktR1lpnzABt4enMDDCplKZVBpjXzk2gSfWJGJtnyEyqYEAqpyKrwaGIBEeYJ369fG04acL4c8A6ZIPxjHScxwSiVssECxBOJqVFE9noUaZiZmJkc+ZtfFR1WVeZJulRt5xHOjQ5EbBSfgNhy8v9sL6h1MSZ9d+Rt8MOu1lL990lF+RYCPgPrzwjKQb/AK+Ppjd02TXjB+U8vJjCOZ7oOV+1z+v4Y2zyIPP9dMR0x162/W/6+GMkwOnK36541A7SRUXN1bX+X0/Xlhn2Rz/sMwKpE6FYx1tH4/TCp5tzPh6fngzgtDXVZdQXuNuCdoO3654RzQjAHxzOj0O3lBqRcj94P/Lnxj3oiMVfOdq8yzllq6R05b8tQ9bYDq8OpUveaoao3iFW/uypXVsevLGxTyq0w7o76p3qGRED7KiAT4Ex8MTY1uYXD18RhHCu1WYpd1KivqkkPBAvvJIv1vzxPmO3ua0NARdUlW3Kjw5Hw/HCDN1qQEU1KqWHPUefLck7RtjdCitVjTQgOBqBEALESQYtAHOfpieo3tFXVwDLR2d7eH2gp1yNDe69ywud4+z8/Q29f8a1ddSnEq3uG+pNhe195+VuVaydMGoUGiylRYCIG4I3a25wLm83UUg6jqaxaQSfGTf8vDDajUfUTsIXmeJVqj3d/aARAZp292ATJAHj08pM1xDN6UVvagLuSr3g90GYt+WM4dmBlylSF1gh9YglVdIC9Qe99MXmqtavlouGqU295ttQMT4DUMUWjGVLi/sp2tNQOcw0ABY7vO4JJUQNufpG2HbdoKATUalokGDfYWtffFSyv9nzBW1uCSvdgFQGje24nGs32azF0Wr7QC0XmnqJM9/3lt1Jt44dRGphH1fttl0zHsTq06QfaASATyIF42vffEvEO1WXTuiqNcEqINzDQL2uYG+KvV7H5jSVSvSBLGS0yQdPRDAsfjiKr2VzCiXq0bWEFrzbnTwLPqHS0Z9iuP52vViuF9kaZIIVRJ1AC4O0T8MPK3ajLAuntQHWRpIIuOXjfFZThObS1KtSCi4hgDGqRI03BLRG1xhRxTg1emNVXRqd/eWGlmJYz08rY4tpF1Oa5e27UZZFXXWEx0PryxmS7RUGBJqC5kWO1o2nHOMvkageddKZNnaQLRcQR6Y91aJqFY9lTE6SUZzJG5AnTz5KNhgDKKsxCfmJ0j/iLL/f+R/LGYojZejYLUEAAd5DJIABJvzIJ9cZh+6vudZ9iIVYE3/K8+G9sSuQQJvPhz8T6frnAhbeRGxHIbbx6fLHskwJi3j5/HCRCJ5Zbd34+X44IptFonyPy8sQypAsPExHr+uuMUr9k+v65YQxgLj7slUAryfum3z/AAGOn5/jvslsp3Y6iDEEsREi+6+U45JwTMFKytJm/IC+ki3r9cXLN9tw9LQUSQAIYNvETvyMk84JHn5GdG7xryBPU6RhoMs2U4/TqUhrUm5HSTvAnwODkcVQENIkAAgFhz2+UY5wnHiLMqyJgBTaYuCSd9IMjoPDBC9sGFwWBjoOXmLYTsve38TR3B5l3bj3sz7P2fu2iZJ28MS1KlVqaOqqoDTvfcgWIGOdUuP1S5ZqhAjfSkz/AIcHr2gaD+8MHa5t0uoicc2JwKJ/EHdWdAarUMrKKY31SOlvXA3Dc7Uqsw0qoUgkj7RFxfltihrxSsC01akc5Z7fPEdLtC6k6ajAnf3vjvblfyx2hjyYO6kW9r1/fCRBgg7WIdvpbFdrOZAJm/Tr/XDHjOakIDcwxjfcg/h6XwuqDvT8sep0i6cYH1/M8jOQXJmxMT8fDrz/AFfGRaDPp8OmPKmb8vP9dceSwHTfGyQnsAkmNsGcDdhV1KSDpcgi/Inl+WFusddjg/IUCzGEdgVIsrNvt7onlywrbjadUNrcRuWJfU25Oon4mYMDG62bQUwq0wCrXaHmdOqD3uQvHhienwLMMF05erCnuzrUbzfUVnmPGeWIq/Z7MIO9SrDYz7/QRs0RffCaKlAAPc9pxWn7P2ZS+lu9pJiQQI3tfljEr0TWLlu6y6B+7aRKKpY9wdZG+4wuzOTKyWYgSB36SzeegBnb54HsbhqZAndGHoAG58tvTB1UQI3w+5Ycvm8qdRqCmSAIhQAZQE7C9xHM3thXxwUStIUyDAM82HSTO3gYINhbAi0mBEBLXsWER5g48JTKwDTMRydTbf7QwS2ocTvhPBhfC8uSwNRS1NSWIn3vKCCSZAF/TebLwHtSzV0Vqns6WwUgtKxIBNyDcknZROKplcwWqFbyRDagkXJkTB3AAttgvJ0NBYsAYjUdRFjFhAJ2MH9TErGAI4Mvn9oWZpaaNOq7p7zL7MXkaRHlc49ZDPqtIezmqFRFgEapCEyZO/dHPfFTTjLqrq1QMuqwatUJiFspUi2+4k3wGeMQtRabBQWjUpYtEteWEx53MjxwyvpjM293LLX4vlXOuowE/ZI7w6yBtthFwfP6q/u09MVNEC5MaUEzuZwppZidLatRaBdAxG+0xOwPr4Y3VqIbRBBgQdJI0g94X70t4RERgnIYtn3LNX7RhZ9tTgiF7pBAubGYvIH63WZ3MV61Kkp9mNV6ZlJI923elRPW5jwwiuB1m+2w5em2D/26mTTHs/cbe0ETaYAnfr6Ynr1CiYhs8y8ZKoiU6arly/s1AfTSVtbAd6CLSfEjfAef7S0A6otBUIb96tWkmoCJgAH3vPHrs1x/LrqVswTqYBVZCAPIgekE2+ZVcQ4WlSu9Qg96ob/zNAN/h5Y1oAw2hsR9Q7SZSL013ItTXkSMZhFUzaUiaZCyvl5/jjMNS+51mU52jmbwT/uBzvjDVHOPrzt88XdeEZFftqfKi5+oIxMlHKDYVG/lpqPqMYu6s1DonMoYIMfo+H15YkpUGMaUJ8gT67HHQqK0vsZfMH+6o/ynE5Uj/wBK8fx1iv1GAcojDoj5M5/S4fmLFaNQsDYlDGx6iMGPlM2wvRAjmdP+pvri5gMRIoUAOrVQ3448isQffyS+QJP44i7IxsiXTpaFWf2lQp8KzMAFqajxemT8pwTlOA5k71qajwLE/BUxZf219WkVyPGnl9S+hK43Sr1GkF81A56KdOfKH+sYQlPQ+0oOmHm4jp9lK0/+Ic+VOp+MYnTsZVMa6tVh4U4kc7vUsbnlzw4NMncZlv5qwA+AnEJyRLf+Hpkfx1KjH5ADAtfA/aMOmT/TAKnYul9qpVH8z0l+s48L2Uyg3qqfOup+S08MUo6PeGWXp3Db/FVviQVRyqU//wBdJD/pY4By17jDp09RRW4Lk1FmB8NVVvP3QMDVG4fTMVMrVg7OuplPo7KR8MPoJEa658gyfMKtsDZlgrS7VUXaS8yb295mm3LCnqXB2EY9LiI43g+UzPB2Ewq/z02Hzgj54b5TJ8Pe1J6BO8KUn4b4T1KWWfenUqnxWo3+a2A+IcIoGSEAgE2JEERyB8cUx9Ux5H7yL9Ig4/Eu9PhFMCyj0/pgihkgpkWOOXZ7LHLvValUdAgQ90ke8SPskdMb4Z2hzcEU8zUtJGvvGysxHfDfdgDqRjYmbVYriZMmEJVkbzrPsvPGwmOY0P7Qs4u/sniJ1JHx0ML4aZf+055/eZYR1Vz9GU/XFNYkwt8S9wcD1uGUn96jTbzRT9RhFkf7Rcs5g06qeJQEfFGJ+WGWU7a5OpYV0B6NKf5xhe56j9oefxN1OzWWIIOXpiei6f8ALGBKnYvKEz7NlPg7f6icPsvxCk/uOrfysG/y4kaoP1/U4IY+oDhQynVv7PKEsUq1U1RPukWn+EdeuBf/AKeROnMb7TTuLRuG/DF5JH6/oMeWXw/XqcMAIhxKZSMt2Jq0xOumzdTqHO0TYGMLKnY3MKDFM1P5Wpj/ADE46PH6/wBhjI/X++CAJPticrqcBzNMXylU77MG5f8AtrJnALZSuLtl2QEzdKnKbSZa9ueOwH0xqT+v645sYM7TU41PdldQloiSIkkQSbAyQbjbmDON5dm9mS1NSPe1QZ9SB7pGOw1UBHeEjxjAVfguWf3qFI+OgfWML2hF0zlVOsq3QAHVIMQQR0k7XwxyPF4pFSza5nvyR02HeG+09MXbMdj8mxn2MHwqOPkGj5YGbsRl/stVXwDBh/1KcKMbjgwaDKL7Rj9ufX8zjMXj/gej99vguMwnYaPpHuQUnriGVw2/dWigAvvIj64ObNT/AOrZT0DIPlGA6dHNxoplFQE6Zo1JCzYX0rYW9MOKVKuU0MnKCYUT6BzGMvb+Znr9z5RdlyKikVGq1LXI1kEEwLJzPTEtPhNILC5dyvQgR8KjDDDh2SrqCpNgbFnDH5Uxb1wcmSfm4I6Q3/zwO2sPcaKaPDQPdyyr56B/lDYJp5ep92mvkxb/AErgnMUqKSalYCN5KCPiJwIO0OUQQtRnk/Yp1KnzVSBghVgLtJVylTm6eiH8XP0xn7Af/uv6BB/on54gbtEPsZbMP/cVP/6OuFg7bFiypQRWVipFWsFMjfuorEi++2GpRBqJjo8NXmah/vsPoQMaPCqfOmp/m73+acKG45mWBIfLoAJ9yrUMepQYSZ/j2bavTopmQuvUC3skAECeZYxHjgDIh2BEOl/Il1p5NV91VHkAPpjdRI3tioVeH1WJFbiFURvpYoDPQKfwwpy/BKNbPrl3d6tMqWDMxkkA8zeJGEOVDxvG0NLtmuKZdPfr0l83UfKcQ5fOUqyu1Jw4AgkbTcx8xjKPYnJptQB/mk4g7J5VVqZqmohFrQFHIFRYYkMqsaAjMjKLJhDZFwobSYhfquKzwrs89WpU0yArMCf7xGOtZynKsJt92BGK12SUAVx/7rH5nHnddkdE22Ny+Ag3KHxLKFa9TLv3jUVLk/d1tuL8sBU8kKNRWAJ08pEEbHlOHvaggcWp/wD4x/lrYA4mVk2PphsfU5FK0eQCfrOODHkB1DgkRNRydMTqZuX2Ok89Xj05YmppTOwYjazKOfQpjLE2f44LyBWrHdChaaJPWAxLfzGb49XH1TaCW8Tz83Q4wwrzBVUAjuj1ZieRnunSeXLFoyXZbMNQNcMqjQXGqNheAAIBgHcYTVIDKYEXuANyd+vTaD9DcKPaihpoU0fRT06agIM+8NV9t5v4nGbP1GscbfTzNGDpwhoSsP2V1U6VYrpNQgAkAFmJIBAjy54h4lw/M5aoaYzNRGHIOwU7ERBI2I3jF4zfG6NSvTLVh7JG1XA3EkEkjaQPHCLtVxKjXCMiS8ku9+9fu/IDw5YmnUlN4+TAK3iD/izP011e1DAbl1U7xHIHB+S/tGzAE1KFN+hXUk8iPtDCTitCacCTcb8gSD9BiHgTkIpEHex/mmfPfHoJ1VrqvaYWxADiXHK/2nUTapRqp5FWH+k4Z0+3GTJhqjIf40aPiARjnmY1RBSRzsJ2k+u/y35j5iioDfuxKqYIsNrc7/DFk6gNwRJHH7BnX8txehU9ytTPgGH03wX8ccUGVC0VMn94sxAInluLW8fjgnJ5SvTIFGuVJE6VYjbcd2RNtv6Yb9WgFtA2Gmq9/pOwmOoGN6Z6n5Y5UO0OfpwEdjae8VebTMMJ2IwZlP7QsyLVKdMdWKsBvcWMTh16hGFiKcRBradJ9j5D5417IdZ8v6YotD+0unMPRaPvK0j/AAsMOct/aHliAdTAbXQ2/wAN/lgnKPB/iMMZHI/mWL9m/hb4/wBcZhUvbnLH/wA+n/hqfljMJ3G+X3j6F+f2iTM9qK4s1TK0vDv1D/0sPpgLO9pqug6c4NcWVKSgExYd4EjFZzFF5LkcgBLGfkMR5fKKdP7xRJBBNovsTNhjCuRmWzNRUA0JYaHawezR6j13YgaoqlVkqpIhQLXtOPNXtwNSsmWSxHv6mnkd2ifTCXhOTptTC1KkQxVgItoLAX8j9MR5mpRUnSjss++Swnx90ADAoMahNgXH1ft059pFNEpg6giqBBI0gyBcSZvhRme1ebYH96V/lt/ljAtR6ZoN3O8VsQbAKVJmTMmMbyjOSAGAXwi036YIXTuPzBd+ZJmamYrCWZ3UmDufHniOgwpu4KgkMLnlIF8dK7O5LLVcuwKGpUG+kHmCAbCBzviq1OBU6maWiCAWbSdQA0lbDrviAyah8XBlCtcRdmOJVYCC0XmYgRF45DfAmZrn2tAiSQxW2590epxY+0vDBlXClg1p0ra3Q8/GPHCDiFRV/Z3SRpqrfnuOv8uFxoq7fWLqctuZPm6dRapWorAlQwLTJA5jpefhiLgOa9jnqbwWA1CBuZWrEfEYM4jmGrsrKplZVm1C95Aew2v13GAcwCuZy0DvMAxM7kl9/QgemLoyGlHnxOdXUljLo3bAsSEpbGLtP05Y89jc2WqZtzE+0ViP7v8ATCHJ0iXqjn7S5ubaB4Ya9irVs6vIezPxVx+GL9lRuB7kRlZjRMuub44DKhdzEziiVOLPSrVgjES1x6DDwNceL4pfG3AzFWfvc/IcxjF1HTK60ZtwZNLQTiXEGbOI7XOkD5VPzxmYryb6lwvzL/8AeEIPLz+/4YKJJ2E/ymfkb4U4woUVwJRHvV9ZtQT90j4YI4Gy6G96ZBttt1/W3PAqaT0+hxvs6/dIY7vFz0gQPj9cWxKGBB+Ulm5Uw32zNAu0S0DnvAIv4n0A6YFquycijIfXSTJjqYNpt+BGbQDvISCpswJHORHWJwv4tXIgx3i/eM7kzYDkMNo2oCSYkGyYwyOcsNe7AkheUgnQAdvO/PxxDLHeZA5cuu3SPWZ8cR6txpLah3VBi+xmPP8ACRieyH7RtEz4KYHhPK97Y5EAN1IOxZauG8NOpa2uO7TYg8zG3PlJwPw1AtFDbVpHget5m1xiHOZgiAJ7ykHl0mPDF9bKn9mCNR1OtJVLIqsbwVO4awGwteeWNePo0ZCT7nodLh7mIFuZSc7UAgAEEmCTawHwPSPiMB51gKLjyj1I2HLY/HDTieXenKONLq4BB8NRIEbiTPrhHxMxTYRuRM79fwxMYVFgeDPPyq6ZADDqCgrTnZUH+n8cMUyEp7UuQoYAqJHvXLbER4nmwwnLlSo5Gx6RY+HKcNcvmfaACmvuqNY6iUBMzzbpygYw9biZMhA8GpQFS5BEAWrJMHYkSeURAgW2j54zMUAxaCANxpBv6xZsH5rhlMsxV1dtR92QYgnXG8Qp8oMm4OAzABadl7vKOpF9xEfljMMx4U1FfGNW4kDcPm3dJPPxn4dcQZWkCzKGgao5i0xytg9a3s9UxqABC/dkaiPMmfHEHZ5Jknyv6z62nGkZiqFmNwolMQJN/wBk0/4viv5YzHT+G9maPskPtHMqD3QsXva218ZiX6jN6H3E09rH7M5tmSauqmGIA94lonmIgjkJ540nDMuFEGSftEwB4ibn5eRxIcgpLM1QIiw1RoJ0xCgeLE2A8Ccb4RnELkaWYD3GqRDg2AIAP3TBHSN90AYKdJO07GbI1AbxPTXS1Vd0FWZ2NxIxqkn7sm8nVJvOkI1vjGHTZikK9YeyF1RwCNUQCp3HXnGAeKZZrmmsTun5WEeX+2N+LIGoNtJZcRWyu8X06epLWI1AiRBDKTN+e2JOH+4rEgwB3Zg7C8E4Hy9Q6gseYA8AvpYfPB/Z/K60E90AGWamrixNpJB2i17ziuQhFsyWNdZqNuz3aStl2Y07F7GSCIty6i5wuTMVHqkjUaneMyJs5BMyBO18GPopwhqU2YxCihJvtzsTa2IsrlNNcGqqhJqhgUEA/u3AI1QCdYi+MupTZqaChFTWZWq8tVWoTAJYkcuZMm0YG49w2rTpqxHc1CD0sYBm84YvlTUFR1o0qdNFJBAUsdIJ0ggkT9PHGdoPYlfY0kAW0uAJt4nffr1wBkAMVlA3MAopUUMqxO5P+xAxHn9ZqZdjAIACxygjHSuAcDoZhVdyPaR7wGnV1tsY6xhZx3s9STMIoPdmEHjKgz5csFWA+MQtbDTcrOVrsC+pJDMJK77AbHfbljWW4o9KtmDSAhxTBkHZQ0W63vjolHgeXp5dvbUyrd6NRA1G+n+9EDHM+IDRmKgkggL5/a8caGZm4NSaKincXJqnE8y2zPbaIXAtUNVfv6vaN6EnbY2PpGCslxtks6rUX4MPUW+I9cH/ALXl6vMr4NY/GY+eM5GRWGsHT7G81BsbD4TR+e0qebyrLXVdzHK33vSceqjEGDv0cQfng7ieWFPM0gsxE7yd35nBrOpsVBB+9cfA2n0wcrrsRx+8bBiLX7v+Iry+aMgmZBBE94WuN8eOC0httzPqAfzOBMpXM7+hwXwuodPdE3AmNu6Afp8sVxrVzNma6jCosCD+tvywq4ypMDmWO/rzwSarDVcfUj4Wx6rFSFIGoFjMgEjfl1N/hipNCZ2aFZPJF2UFgIvNjtB2mYtvj29NgO9DQIZgT16bTbfEFB21kwQSpiCRAIvG5uJEjGmqwSfATsb7HwwmMEtZnMAqX5nnibAtSEgnSb+ZOOk6TTRQqMHpaEY02sygU9Qhon3reMnljlfE6xNRJabb25+WLJkuNNSbUpdWm8QwPmLfrbHojNpxgEeTPQ6XqERArSXtHxEs7MCxlrTvACgFotPjitcUYsqAi+qJ6jxPPfDps4oYANYyTHK4Fumx9I6zhfxSuGq0hMgNPzUnGXEdeYbcmQyOMmTbzCcvSvsDa82iZi++49fTBfD2RXDaFMRa6gjlzBNx8Y9YOCKxdu5q1kBBb3i694Tv3ZE+WC89USrmEXLglGIVvMAMzRyFn6e5jF1uTXmevZMRkBJYc3Bcy5p1XYJpkESLwGsV8LfKcL8xUusXBncWI58+n4YeZvS1J3Ytq0bCJ1AopkRtGs8rC5M4QMxYHu6T089/jPyxixBSbI24k8mpTzIa1Y6HNpaAfP8ARm2CckVRA1OGDGJ8RG4/p+eBMwpYaYuDexHL5YmogIIGxI26+HjJGLuFG37RA5q/Mb0+MOAP3keuMx7p8DrsAwyxg7SwHyZgR64zCfp//Mv3n9/mB5TPVKbkj3WGlpGoMDNiNvX9EHPU69V5YvUsBIWBAJIEAcpOPdRe6AzKo2HL+v1wOWcEqNTwYkA8zAmOpt5434MKE2efpMz52QaRx9Zr2tYVEJ1K7UmRTzIXvbnfHl+IVg12q95RElhNt4BxHWosjIH7mippPhIM7b7dcCZRiNgbfC2LogDCc2QslxxlQun2ryTJAWSBYKZPMyT4bHDThWcAV0DVKYDkD2ckcr94kAzOBezj0HJSsIuIIm5vYzIHO+LAiBVPs1CKbmNz4k47Li7hIudgftgNXMFyudpCoKrV3YrIl6J253VQR5zhe+YWrmGYsGp+01EoCLGmFAhrzNNR8cGVs/TT7anqZsPhfCzM8Spu+papdjAYBbQCY35jUb4g3Tqm4M095m2IlhzlU1aYSkCqRBi9ouLbbzgrhXA19jULUyXjdhNo5A2BkbjFFfP1lMqXU23OnraN/jgqnxGo+hWdgCx1FWIkaZ079cdoxaaAg1Nqtp0JctTWmrNV9nU0EDvG3jpWDbw64qnHONVCUZjGhmKwIiRbx+ziNKpJHsqbSBHdAUHb3mLm58BiPiXCa1YNUdgqKCQoUmSFIN4uZnCaUvSYbYiwI+4nx980EWsVVEAk7SWRTeT4ek4qHE8wGrsVYN3Eki4m84ccH7PUaqozs7kqD3tRFwDFjEYJz3DqJYUkCKu4KhgZ23vOK6woqvMUYyTd+JVwDOJ6S8sGcT4cabdxlYcxMEepEH4zgINcjmNxz64srhuJJkI5g+baK1P9c2wWcxcKoJJYADxJgYAzp/eUj4j8cTqgYVG1AGmA4WPehha9vrjNlxhnFzXhylMZqOMh2L0lRXrhdTAaVF7id3i+1tO5Ax74lkkyqqKWWZ/dZnqBnW6qx2IE99B4eoievkkOZoZiQqQpJtAYSKWwXopNgIHLbFmXiisC1Mg7lb+OtR6ezoKfFo5Y0hQJnDXFnCMt7fLH26ooqTpVLaR74MCYb7QF7BToIBIqPFaFXLvoLAgQwjmBJEnx6eAIsQTbeB8Iq0gQ1XWTyIIv70TMwT3gRdTccwfPGOz9jU/esSZMKGXlEpyFhtgtj1CE0RvzKalSqQR4GLTvIkRzk29PHFt7OcLCxXqaSY7oJlVFgdUcoMGPdWoGG1lPDctS1k1WNrqE7o8ZEeJ6beOLFQpwrLQdR90m4UyQCPCSRG0MQQQwwFx6Z3PEpvajKlc3oAXYaVUaT7xhXHKpNjFjYixGGzcKVYKtqXeGkHeOXIzvAm5HKVwybU+IU0qN7Rg6knblqi5gAAdQABh72oztIqFJl90gSelgYIW/vNoX7qc8FjQMNjV8QgNDLFEZ1BMsFF7kmYEi0CL33PlhDxi1VABHd+Mkz9MFU+IOoUP3qYaWXrOkvB9AJ2wFXrGpXVtIBgWHnI+uMeFnXLq9bwDSNxLrw/TRrqFTuE6wzbwJUCQI1GSQJgsBMbhHw9tGYzAJ0aVcmDMQwSJFvtET0J63ZVqEMAKikLSDEjYEp7QLzubgHa3XDTI8LZ0bTRDl9BNVzpBA0vokd6NVyVkmOWPNTUxK0STLHwW2AifNcOZWpUtal6umAZvrgqDy2Ivhe+Sq1XKImt7CFGoCDAkiwF+dvhi70uy1MulWqdTKqhVSURSALjSdRMibnp0w1oD2a6UVVUcgIHy549HB/wDOegWNTJl6jHdKJT8l2FquQ1dtA5qhBfyn3R88WvhPDcrl40UtDARrYam/xXj0gYKGdHMEfPEgdW2IONq9OieP7yQe+DJNaH7S/EYzEP7Iv3RjMPQ9x7PqcfemTSplg2wMqZsZvsevI38Map50owKixiY5xHSPDyxEK1VSaemfZsV7xA90lYAHQcsRmobu8arXAN4M8/AEepxjyKByZF1JO898YrMyhpmNJ921iIMxv+vDAFesNjUn+EEkfAWwbmss9UWET9nYeG/9cGcP7OGoLuoPQCZ63t8L4rjFgS2P4Virh1W5gEWm9uv549d5nKyTFgBewMACf5Tth8nBVQEgSZiSbdPC0j54a5PJsApHdDfcAA5G887YBQ6pQMKlb4Xw8PTXUkzB7xIAjmIM9cNMvkNBBVaawLlQxO/IvJHoBt8JOH0HZRpIjUVMi8BiBF/DbBucAXQJHfkG38LNaTBsOnPE+3YJIP3lNe9CDLwdHALIxm86hN77AgbYHegtEEBZCkTYarsFnxucWDJP+6VjPMfAt+C74W8RNZgyrl5Uk94ses7yOYm2KFRQqJqNmayTax3QbEDYR03k4O1k5fSA89+423b8Ix5p5Zihd4RzclTYxtNh8/nj3w5F0sHLAyY3uCBz3vOJMrXKoy1IeB5yMtQAZ700A03vAnfDPL0KgALuZYbQJFt5vz89sVzsnxUUaNNnTUAgg27vKY59Lx54bpx6lWLMKotJIJgqB1n6+eLrjRt73kmdgIWOFy4f2rE7EFVPwMCB6YU8T4elR4dgANmKWHhP4yMNqFQuncdACPeY8jzVRc/IY1SoqkanDnUBpiBcgE3g2EnmLYi5VTVyi6m3qUbjPDCtQaSSitGrp42kkXwRw3hTEOabhi6FSR7sEjeZO4Ft8WzM8LpVKh76KeREgeQBkfPA3D8ocpmFraQYPe03kc5HIxO+OOSt6h0eIrd8zlkVtWumAoKPfSYiBzEgbr44d8H40awXulJYAloIA0gyJAizLuT72NdveN0syEWnIVNRLAQZ1FYjfZR6nAHZPJtWY00eX0kKDtEaC1/djQCF3mPTu41bQaFuX2rw5cstSs9UaTBcRbksrHOI+GNZHN0q3epOHXnpNvUcjiv9uDmadCnTqOpB5Lzjr43/AFGOf63QkpN9yJB8jzx2PKykg8Q9sN5nS+O08rUDEr7Rl39kJceZXb1OKmGUMWQlUtBdr2IN+W4B9BhZkOIVngUx+8nulR3h8NvPDrJ9k69VjUzdSZ+zux8CfdHjY/HGoZD4FzgpTdqlbOcJzodAahmFCAsSfZ6FgcwDHoMGdoq6VKmgUv3jSe+hB95t2aeUbQJm+IcvWGXz7Ckk6WemgvF+7NpMC5tfDPivFUkqant6gItpApJaxiCGi25O1uuFY7XJmibgFDh9OAGIIPM/egxBPM3FzG2F6BRmCZ7obdZWwHKbjawwyzud9oxaZMRsLgaRAiwgNte07RGAOF5f22ZKm86nN42b+uM+MC2J9GICSalwNekNRohGYzOoCQPs2IuyksbzJwsXtrmKFRqdWKkHfYkcj0uMCZ9QpYushfteHK48sDrwypmBqWmEQX1vqkgaiYG5HdPUTbHdNjXCSUJIP95TMTlUAjcS5cO7eZepZ5pnx2+OH1DN06glHVh4HHKOJcBZC+g6gi6mnlLMsSLTKn4TgGhm6lIyrMsfdNvyx6C5QeZibEwnZ2TENSl4451w/tzmEs8OPGxxYeH9uKFSA8ofH9R88VVgeDIOpHIj/v8A32+JxmB14pRP/mLjeKUPUnrPuVCjwv27mtUgljLRa8dAInx54F41QRHFNUEkEAILiRu09TPlHjhstNVsoCzvBN/MzfGCoqiwAxh7RI3m9ipMD4elTSNVETG7HaDIm1/rgzMUyV1MVBW40rfwEk/hgOpxoCpo02jcG/wjB1F6bXYE+DfltgjGANpwejCuGZxaoVXEFhKm0MI5fxeGIuJ1q1JD7KkNCCzFgAN5t8OfPANbMIcyUdtIdQyHkCoMi/gJ/wB8HZCoZYPNVDvzXnJIYTFh8zhkbwZzjyIo4VVrKwK03NOSTETdpsDvzj64e06KOql0bbmYYSEneRMTjaxTO40GCjTaAGtPwwYmk7MPjP3x+WFCgLRh1EmxPPBc3SpEOCCqkwGAJBPgdjj1nKprVDUawN4/XLAnGshCioF0lnEWgnu1TcdNrc48BjdbJ1moM8qpCsYu2rSKkD7MAmn1O+ECi7jFjUny1D2zCfcGw+8RzP8ACPng3OZc1BoRZA+0bCfP8sVynnaT0aT1nnVSpsUkhZYSQEQiVW24bDGl2vpyqkuRYFgoH3Z3MnnsAdow+teINLcxXwrIf93gLqQI/dbeAakbeF8e+JUSlJ0pUUuGUqAFgd+ZESTA3PTfE3A6rnLtbUStRSxO/wDzPO8EdOk4Y8SV3YlgixBnVeCak8gJ364ystixNCtWxlQp5muyKmpioUDu7GBadNjzwx4caoZFJMBw2lvAjYG8bi1r3xvsvSpMlP21NWiVkgGBrIvYmLAfLfDLiRpCmFp27i2XadIaT6scZ2YAHaVVTtvGuQpMW1GkkE77R5b4jz6uag/cD0nveZWPnjOGvSALCoQY7wJ0xPh9DfA1MU2q/wDObwYgz5ap+eK/0j/E7+omRcT4FJ1oumZJSNQUkySNLDc32O58sJaaVMpmaDpOzETz0yWJ6g6r7c+uLbxNwAB7Q3HuzvcXOkTzwhqOf2zKw4Pcq9YErTn3ifvfLAIBaovi4PxTtBUrw9VNQgQEkQN9mmd+uFj5dal6ZHl09DcelsWs8MSoYLJcTO3MiLWNwbYTcW7Nuh1QbbOp/UHBWq4nMPER0c3Uy9VCFDM0gCSs7GzKQQ3Q/XFl4f2wUkK5KH7tW3wqKI/xJ/exXOJ06jLpYaoMhgIYenP6+OF2ZNRrN345r7w9PxFsWRmHHEi6jyd4blK6/tVau8aU1v1Es5C7EG8kAqZBgicLEzJ3cy1QliOctckn9c8DVmNwDuAI63nHulRKsCd/HAdhU4LcZIGkQIEGAvK153tfEvZvLF3OmoqHTBLAmBIMiNySOZG2Dq2cVUJNFWlSA9wRbwwB2Xq6TWBbTKqQfaFJClpAAEMZOxjw3w6Y9JNyasCI/qJl6LFqjGrUFhOnlbUFAhfCbyN98KOKdoK26sEVuSi9tHdJIkkaEv59TiPsu+nMnLuARU1UrgGGB7jX/iUeYJxb87wilVosqUkpmokiFHda4Inez0ypA6oObS4X1K6rMH7M5BqNLU5JqVTc6oPQU9eooXF5p1VEkkTbAPEeASSaKqBqBZNOkAg8uaEGZQ7TYkEY1wOnWywZszqZGGlgGVwJtFQH3htFzHhth9X49lhT1mqoUf4vAad+XTFERWFNI5chUUBKfmez0C573Miwwiz1AUzAbUenT1w24v2pNWpNJIQWhjdvG1h88RftdJ7OgX5j4i+KXjrSpozLWS7YWIn1N0b54zFhopQCjuU28Sxv/wBWN4Gl4dWP/RN5jjAHPEBzlV/dU362/ri48O7FUUEuSfBbfPc/LD7I8PpUh3EVT1Ak/E3woQnkypf0JzrJdlM3WdWKhR/EdI+fePWwwzz3A6tJtDuQD7pWwPqb+YgcuuL3QXdjbl8P1HpiDiT0jTPt2VUPMkCPEE/aw2kCISTKTRo0wJAlhsec+bXHpGD4YSB3R1HO8mevTl+a3iOdFPWUXWFWVYjRIFzY3keUeOCuFtrYCoSwIsqCFHQmJY9N48MTLoNgYy43O5EY5PiJRlRiAu0ee1tx9MPxUA5j0xX8xnKIUoqyDuFECes9fG+I+C8bR+4GDjkVIJHnFyPHAXILqUOM1cZ9ocxK0x/7q/R/zxFUqg5crq0zIkGPt1eflgXjdUOqQbawZHkwHzIGINFNaWpzHe5nz+NzznCsdzCvErGQyWpEcKYO4XvRBINh3h7vSNr4aZXIyLK0AwTpI+yfvhRy64m4BmkKtQWLM5B5RqciOcw42w3SgQjy0nWp6W9oUYkeU4mC1bSlC95B2fRmSoqgd12QidpEap587Wx47R57MKzGlRUkRDSGMDUQQvImT128cF9lqZSpWU31nXb+ZmPyqLhxn8iHBixIi+x8D8Tfe+Cq2s5m3lB7M5rM0yTTotVpFySP7zE6ZIAM6QfMbYfVMmTTDlPZ79xiCYAgGAeYWbXuLYa5PKmkFRaWlQfsww95TyveCbjngenU1VSAIvpGq32yp3vtNh49MB8QIowrko2JvL8SVaSg0yCVFoEG2/iDiPhlanrJ9jPlJ0jrBtHjyw8yHD0bLpTcatIKnrKkqY6XBwg7TZOrT00qNUBTLFWEk7QGiDG98d2TtG7qgGe+NcQos/dUtAgMLXvPmLL8DhJmM7SOby506VFOrMmZnTp+EDA9SvUT/m0io++veT1i4HmBgenUSpmaRCkj2b7SQTKm3hHpivZTnzI95uJZKOapGZZTcx3ptJ0i38Mc8Mmz9FlRXCwOYBDehAwnSmu3sX9QB9TgtA0Wo/8AUg/HAbp1AoCMuYnczzVXLOIZyrcmIkeEwJGE3EuCblSGAvqRh9cO6iVdhTH+L8hgavTrreKYMSBqJP0+uFbDQsGowyWaIuU3/srSx1LqUkbyCI8gf1yxOaCOO48z9lxceFsXU5SnWpy5C1AJeAY+ck/H0wizWTiwcEGTBAkxvYjEgy/1ff8AxGYHlf3iTNhhSgiwUCfgMCcGzvsaoeHYCQVUkStrWNxPLDTOU39kyDvHVtpAgTMc7+R6YUZPK1BLKO9BJVhFpmxNibbYc5Ad7kVWo7H7NmGV1qGlWUggnvAsDIJgTvf3fXFqas5eUA0amIeZU6npVbFZuGptH83hfmeYaT3hobxH44JyPGK1AyCR4yb+ovHgZGHD+4QCDYnR6iotM+1IIgCNxZQCACLsTPlNzjn3aGsvtalNECoGgC5IiAbnxBx74h2irVrL3bBSwjUbz9kAC53An54Vc46YORhQrmUI2syThWV11adJfedgATtLGPgN8NuM9m69G70zH307y/mPWMQ9jqtNM3TeqwVFJJJ6hCBt4sMdYVkqLIKuh5i49ccmMONzvJ6q4nFPZHqMbx1St2WoMSSgv4T+ON4b9Kf+0Hc+UZ1KguWICruSQB8T+tsKuIdrcvT90moR9yw/xNY+k457xKrWrKzVCxAE94km17DYbcoxlIlgCOYF9zgNlavhFfWKuNb3Nx5xHt1mKvcpKKY27o1N6sR9AMJc4aj02eqSxt3iZO4NyTODslRKqxdDAvNp8ee2NtV9qrIiGGBHdE7232+E4GkndjDrA2UQjKq9ZQNI0cyfEdevlhsudFMrTRJ5DTeQBta8+OFGXZqUaqpWLClTM26MdvhJwFxDtDuqQAeSWB8zz/VsKAqxrZpYMznkBLOF1H7CwSDzkyVHzOK/neOgStMKgJuEETyuef08sJcxnGbc26Db9XxEbjClvUoBXMuHZrP/ALg6xqUkzzjbaeWDOL8OpGiGUEsDIMye9z3vy9MD9iq6fs9RXj3zaJJELyF4tgzJblQpel003Hz/AB+Bw6N4Mm6eRAcj2aTSHdmLAau6Yi82O8jSL+eLEmXhSCSwOoyTNg4+V8RUcvAIT94oBAIIDeRmJ35YJDNcBH2cCQB72nqfA4sEFbSRffeRcPpGnmEBMqVZQTv4A9f+Vv8A7mwopwty2VJfW8AidKjlM3JO57x8pO+Gq4K46gOS5tExS+MVKzZitTRdKB7nYH3jvzu2w6YuTqSCJiRG5n4i+KnQqkF9V1FRwH6gEgFulhvtvthiisQGi6yBYmU8j7NCzsXblJMScayOW3J/3J/Q+GM4jmQWC9PrgvLtAAnYX88XVAo2EizljuZDUBNWmikggzI8L/hjxneBOK65lNJApOrJEHvbNax8Rb54m4SdbvU/ur674a8TYBN42G/IYTIitsZTExXcRJwbOVAkLvqI0kTzNhzGCM3xirTYU2Gl2XUFA1EjYkRNvpj1w41izVKYXSDBVhdrDYct95HrhdmeJzxKkwUyuXcFTyJqD8sY9Rx7Xc16Rk3qozymfqMw9oDH3VjUfgPkPjg3i1dQNHs5PVgRHiOZOATxY0lqPpX3S1hFwDHpPLFWyvHcyRDVmafvAN9Rb0xO3yAypVcZEtlLNozImgLbYCQSXpX6zAO874W8Qy9N2VipJAESSNUqNU84BvNpNptgXLcbdd1VpABtBgMCfjt4YiZ6TDWzVDUvBB0kSe6pMmVAblyHLbGfIrLsY9qd5JWyqtUcowBglhpPKY22sBYyLm+AsxkTU1AqWESCLAbD6Wv/ALl1uLMVIpIqXhmEFm32O0EgzvfEFbN6mQUVhyAXYEgz9vqAOhH4YTYbiT+G6inMZJltAdfusLjy8fL4YDXh4J0o5SfsN+BNvxxeMtwkVS4NUG/cDDvbk3jcRG3Q4T8U4KQSCA0bkGY+G36tjQH2+KHR6+0WJw72ILbEAn4X54r6jeOm2H2fd0ouNRKxGk3iYFp8/wCmK2T8ZwUTzdzsr3QqqheQoagTExy9Ty9MMMnxSrRaabsh8Nj5jpjfBsiWpMw+9Am2wHPlvjMypBh1+Nj6Eb4oMjKaG4ipsu8d0f7Qa4AGlDHPrjMVr2afeb4YzFP1A9fmNpT1HOazKhCoWAQRLXN7bD88eOzJqMihaak/eJA5m3j64zGYdTZ3mFgANoxzlamtqh1kfZAgepI+gwozvaMkFUEL0Fh68zjMZiWRjNGNRFGZzTPufTl+pxCBP68MZjMRlTCMrkmqNoQam6SB9THLDih2Xbeq4XwUaj+AHzxmMxVVEkxMaZGjSovppodTQGZjqMeVl54L4jmoYqSYGw5fDGYzDvsNoqbmK8pxh6Vb2gM0wFFQHnJgEeI/PF8y2eDiR9MZjMPhJqLmAuTq5vJxLTqetpxmMxaQnta4jFX4W2qiG5lCfj7P/wCeN4zE35lFkPE6CLUZ1IHffUkGO7EabWMk22223x5q5r91rF9X6/PGYzFMTHcSeRRDuAz7NdNzOpibATceJMR+YwuzGeqNxBE1FgKTkJsob2mkN8B48+uMxmIZnNzRhUVLDw9wg0TJ38/yuI+GK7xGDxS9/wDu3K322a0+CRfrjMZiRHwSik6oXxui60ymlWDlVDbR3hI8LeHrhHVppTEswW8SwO/90NjMZiYcrx6EowDcyF80n315Qe/1/kw97P8AD0Uuaw3SfISumAJj3up9NsZjMT1lzvHVQo2gdZKPtWUElmMS0yssDClbDeendHWxXB+EH2r63GlQSYmVmSovbadgdvjmMwAAeZM/8v7xhwqlSZjcsw2BECB9rxPngnMcNQyR3T1G3qPyxrGYoqjTGZjqlO7bqgy6sCCzVApgECAGPMeAxTaIlhjWMw2PgRM3Jln4UzpSUqRDAsVYSDz+HwNsT/tlOodBXQxsFuynyO49cZjMEi1J+s5TRA+kiqcJWT3f+rGsZjMZ+40v2l9T/9k=" alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>Heaven cafe</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRX5lZluNWo7obWwIDDYeOYaFFGiXIGg882NnUb-EQp0OAwJ1wvcVbX-1mweG5WV-3j-8o&usqp=CAU" alt="img">
                <div class="venue-info">
                    <h2>Shimala</h2>
                    <p>Shimala vally restaurent</p>
                </div>
            </div>
            <div class="venue-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJ-1GNjL0DsTz4pVVJGi7XoiHWf9FnSwXD0omNSa9FRiLnCT9HEQoEk8PNVf3AgqdD3rY&usqp=CAU" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>Rosted buns</p>
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.WKSQGLTVyoRvEQe2hVsBfAHaHa&pid=Api&P=0&h=180" alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src="https://i.pinimg.com/736x/82/ee/4d/82ee4d922044e1814ea5579d7b469e61.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.J6jTDiBsckCD4aTnISIc5QHaHa&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.L9F9QDDbDs-9z35rasB6DwHaF7&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://images.greetingsisland.com/images/invitations/birthday/previews/rainbow-glitter-25611.jpeg?auto=format,compress&w=440&fit=crop&max-h=616" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://images.greetingsisland.com/images/invitations/birthday/previews/blush-gold-spots-25972.jpeg?auto=format,compress&w=440&fit=crop&max-h=616" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://images.greetingsisland.com/images/invitations/birthday/previews/magical-butterflies-photo-18112.jpeg?auto=format,compress&w=440&fit=crop&max-h=616" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://images.greetingsisland.com/images/invitations/birthday/1st-birthday/previews/berry-sweet-41140.jpeg?auto=format,compress&w=440&fit=crop&max-h=616" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://images.greetingsisland.com/images/invitations/birthday/previews/glitter-birthday-34983.jpeg?auto=format,compress&w=440&fit=crop&max-h=616" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.KcAJrskz_LlwCL02EckYSQHaKX&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.3L39b8fhbQBUOVcafRLg_gHaE8&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.ESwO4vMV1IRgWz7FyOYiUwHaEy&pid=Api&P=0&h=180" alt="">
            </div>
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>
