a<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding-----Planner</title>
    <link rel="stylesheet" href="wedding.css">

    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://cdn0.weddingwire.in/vendor/2042/3_2/960/jpg/72241d24-e14d-4cca-98a6-9af1d06b95cf-rs-768-1_15_222042-1559543154.jpeg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>Memory makers<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#vendor">Vendors</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>
             
            <a href="book.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1>Your Wedding,Your Way</h1>
                <p>Find the best wedding vendors with thousands of trusted reviews</p>
                 
        </form>
    </section>
 
    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.evv3rJQ-y3VxNlrhBnGIeAHaFj&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 1</h3>      
            </div>

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.qmYnzsNFIxuMxpc2ws-oUQHaE9&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 2</h3>
            </div>   

            <div class="box">
                <img src="https://cdn0.weddingwire.in/vendor/7284/3_2/960/jpeg/whatsapp-image-2023-06-12-at-12-07-37-pm_15_437284-168723822846261.webp" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 3</h3>           
            </div>
    
            <div class="box">
                <img src="https://media.weddingz.in/images/20230417115349/chezrosefloraldesigns-1-768x512.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 4</h3> 
            </div>

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.lwzxY7etig5IyBBsXNYgvAHaE7&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 5</h3>
                 
            </div>

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.CCV27Xt0q-XRP1ubpFlkigHaJI&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 6</h3>
            </div>   

            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.irwZ3DsyXEk4H6TsYvFUNgHaE8&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 7</h3>           
            </div>
    
            <div class="box">
                <img src="https://tse4.mm.bing.net/th?id=OIP.HU83_OD_ysiYpr5nqga5PQHaHa&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">decoration 8</h3> 
            </div>
        
        </div>
    </section>
    <!-----------------------------vendor------------------->
    <section class="vendor" id="vendor">
        <div class="title">
            <h1><span>F</span>eatured <span>V</span>endor</h1>
        </div>
        <div class="vendor-list">
            <div class="vendor-row">
                <div class="rate">4.5&nbsp;<i class="fa fa-star" aria-hidden="true"></i></div>
                <img src="image/im1.jpg" alt="no">
                <h2>Beauty tales by komal rai</h2>
                <p>Bridal Makeup</p>
                <h3>Rs.20,000 onwards</h3>
            </div>
            <div class="vendor-row">
                <div class="rate">4.2&nbsp;<i class="fa fa-star" aria-hidden="true"></i></div>
                <img src="image/im2.jpg" alt="img">
                <h2>Flinters Management</h2>
                <p>Wedding Planner</p>
                <h3>Rs.2.5-4 Lakh</h3>
            </div>
            <div class="vendor-row">
                <div class="rate">5.0&nbsp;<i class="fa fa-star" aria-hidden="true"></i></div>
                <img src="image/im3.jpg" alt="img">
                <h2>Wedding Mela</h2>
                <p>Wedding Decorators</p>
                <h3>Rs.80,000-30,00,000</h3>
            </div>
            <div class="vendor-row">
                <div class="rate">4.1&nbsp;<i class="fa fa-star" aria-hidden="true"></i></div>
                <img src="image/im4.jpg" alt="img">
                <h2>SeventhHeaven Wedding Company</h2>
                <p>Wedding Decorators-Rental Only</p>
                <h3>Rs.80,000 Onwards</h3>
            </div>
            <div class="vendor-row">
                <div class="rate">4.3&nbsp;<i class="fa fa-star" aria-hidden="true"></i></div>
                <img src="image/im5.jpg" alt="img">
                <h2>Wedding Mela</h2>
                <p>Wedding Decorators</p>
                <h3>Rs.80,000-30,00,000</h3>
            </div>
            <div class="vendor-row">
                <div class="rate">4.0&nbsp;<i class="fa fa-star" aria-hidden="true"></i></div>
                <img src="image/im6.jpg" alt="img">
                <h2>Wedding Mela</h2>
                <p>Wedding Decorators</p>
                <h3>Rs.1.8 Lakh</h3>
            </div>
        </div>
    </section>
    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src="image/venue-5.jpg" alt="img">
                <div class="venue-info">
                    <h2>Goa</h2>
                    <p>Azaya Beach Resort, Goa</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="image/venue-2.jpg" alt="img">
                <div class="venue-info">
                    <h2>Jaipur</h2>
                    <p>The Raj Palace</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="image/venue-3.jpg" alt="img">
                <div class="venue-info">
                    <h2>Udaipur</h2>
                    <p>Taj Aravalli Resort and Spa</p>
            
                </div>
            </div>
            <div class="venue-box">
                <img src="image/venue-4.jpg" alt="img">
                <div class="venue-info">
                    <h2>Thailand</h2>
                    <p>Prince Palace Hotel</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="image/venue-5.jpg" alt="img">
                <div class="venue-info">
                    <h2>Mumbai</h2>
                    <p>Grand Banquet, Chembur</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="image/venue-6.jpg" alt="img">
                <div class="venue-info">
                    <h2>Daman</h2>
                    <p>The Deltin,Daman</p>
                     
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.kBRZmWwzM06P3c65k_LTaAHaKX&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.UpGXoafppobejk1ACSKjbwHaFf&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://tse3.mm.bing.net/th?id=OIP.DCI9kjlZhVhZzMh8zUfRbQHaLx&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://image.wedmegood.com/e-invite-images/2c6a8dd8-96a2-4bfb-9ef5-85322a8e09e2-Wedding21-1.JPEG" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://image.wedmegood.com/e-invite-images/f16dc2ad-66f3-4452-97da-625bef790851-Wedding35-1.JPEG" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://image.wedmegood.com/e-invite-images/9bb75402-cef1-434c-9665-2eabce4f6f95-Screenshot_2024-03-28_at_12.26.38%E2%80%AFPM_(1).JPEG" alt="">
            </div>
            <div class="invitation-box">
                <img src="image/card-7.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="image/card-8.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="image/card-9.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="image/card-10.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="image/card-11.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="image/card-12.jpg" alt="">
            </div>
        </div>
    </section>

     
    <!--------------------------------------------book section--------------------------->
  
                     
    
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>
