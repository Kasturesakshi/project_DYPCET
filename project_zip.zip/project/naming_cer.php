<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Naming ceromony</title>
    <link rel="stylesheet" href="all_event.css">
    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://phometo.com/images/gallery/NamingCeremony/5.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

        /*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}

    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1> Shhhhhh____! Guess my name ?...</h1>
                 
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src=" https://i.pinimg.com/736x/cc/05/02/cc0502924e7011af896800b63bf59767.jpg ">
                <h3 class="title">Naming ceromony 1</h3>
                 
            </div>

            <div class="box">
                <img src=" https://cfw.rabbitloader.xyz/eyJjIjp0cnVlLCJoIjoibXltYW5kYXAuaW4iLCJ2IjozNTA3MDAwMTg5LCJpIjoiZWJmODQ3ZWUtOWQ0ZS00Nzk5LThlNGYtOGFhOTYyNDFhNzAwIn0/wp-content/uploads/2021/12/Cradle-ceremony.jpg  ">
                <h3 class="title">Naming ceromony 2</h3>
            </div>   

            <div class="box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxEXHfw1f7NCvdXwUET_NyHa3D6S7jLJBurr6x40KI9YbJ8i5Cju55XJ3BkQEfydC35yo&usqp=CAU  ">
                <h3 class="title">Naming ceromony 3</h3>           
            </div>
    
            <div class="box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOISsiq1yYDnZsbBu-QCfKeaRLHc7l5BB0RdiNU3pZrOkxZlFKArGyYEQlR4POlldFF0M&usqp=CAU" alt="NO IMAGE FOUND">
                <h3 class="title">Naming ceromony 4</h3> 
            </div>

            <div class="box">
                <img src=" https://housing.com/news/wp-content/uploads/2023/05/elegant-style.jpg " alt="NO IMAGE FOUND">
                <h3 class="title">Naming ceromony 5</h3>
                 
            </div>

            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmX-NdsAreDyr9NdHQY_McWSpbLkhGeP-CnvejG1DvL8PxIJI9z1wFI08oq8q5dD-fEjg&usqp=CAU  " alt="NO IMAGE FOUND">
                <h3 class="title">Naming ceromony 6</h3>
            </div>   

            <div class="box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxZwJ3Qg5gTbxZ8TTfep8pRu2suRHxcEPZuzU-MI6VgNKVJcgnTwU5NC2W_BnWaDsTAic&usqp=CAU" alt="NO IMAGE FOUND">
                <h3 class="title">Naming ceromony 7</h3>           
            </div>
    
            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEoQq6dt0pVMrjOzYZk5ha9_aQrgGcCzegLlmS6VEpTwR1P7J8st69Irp7o1_2qNftVoI&usqp=CAU " alt="NO IMAGE FOUND">
                <h3 class="title">Naming ceromony 8</h3> 
            </div>
        
        </div>
    </section>
     
    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src="https://images.venuebookingz.com/17742-1637391907-wm-westfort-banquet-bangalore-1.jpg" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Lonavala</h2>
                    <p>The waman</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://media.weddingz.in/images/8674f112d0f5ec5d60a684a2c5b3fe9d/top-10-banquet-halls-in-bangalore-3.jpg" alt="img">
                <div class="venue-info">
                    <h2>Panahala</h2>
                    <p>The diamond</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://5.imimg.com/data5/SELLER/Default/2023/12/368963606/AR/DB/GI/48777966/banquet-hall-interior-design-500x500.jpg" alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>Ruhi plaza</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://5.imimg.com/data5/ANDROID/Default/2021/12/WH/FR/WI/13351286/product-jpeg-500x500.jpg" alt="img">
                <div class="venue-info">
                    <h2>Pune</h2>
                    <p>The golden coin</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://media.licdn.com/dms/image/D5612AQHQHjCMgBKNaQ/article-cover_image-shrink_720_1280/0/1664365364740?e=2147483647&v=beta&t=SHgk46cet8fCDpgxj8i8iBoVUFgGg1ZhYgT5obWvEus" alt="img">
                <div class="venue-info">
                    <h2>Goa</h2>
                    <p>The sea shore</p>
                </div>
            </div>
            <div class="venue-box">
                <img src="https://meltingflowers.files.wordpress.com/2022/06/nam-b1.jpg" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>The platinum</p>
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSALBsx-v7sYp1TGARaZo7REHt2oYA5ld0BEQ&s " alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2RrJsC97jY-ZDAZpxpJz6LlouHdX7GUuaVg&s  " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8PRNcgZQBxKr1RQmL1_NJh9zf2nPafYt9Kw&s " alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiWKtgeixv06dNiZrjs9zQkC7ei-Dx7jOgE2b63GBC7QBRQok2bWNiYrjgIXYtvtFtl7Q&usqp=CAU" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQryO_7rQYUrt_EE2l88hevcAVA8CiG041DTKrd0da2GV2lCQ19DnDrM_pGDprrC7lLJU&usqp=CAU " alt="">
            </div>
            <div class="invitation-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQm5ZMs2tjuWOUw6_U-2c-gmPwf3MN6x2zIXBBUYB2oY4XJTCyW0EHFpTt3xsCK6tTZA2o&usqp=CAU  " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRTrChO5YZ9kTR7Uw1vjRnj04QxQdQHHiorA&s  " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShk4t6QIWkBGgwR4rZwPXLG_kiejeb1ntqvQ&s" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmDfUXfHvEhUdCv-5ZCM2F-ytUh1xXLuTWvg&s " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwegW1srdXims3AMiRbdAolZ-MVSe6e8s1rA&s" alt="">
            </div>
             
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>