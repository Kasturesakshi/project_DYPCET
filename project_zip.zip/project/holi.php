<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hoil</title>
    <link rel="stylesheet" href="all_event.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://techihd.com/wp-content/uploads/2021/03/Holi_Main_image.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }
        /*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}

    </style>
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1>May your life be as vibrant as the colors of Holi. Happy Holi!</h1>
                <p> As we celebrate Holi, let's splash each other with colors of joy, laughter, and love.</p>
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src=" https://housing.com/news/wp-content/uploads/2022/11/Holi-decoration-ideas-4.png ">
                <h3 class="title">managment1</h3>
                 
            </div>

            <div class="box">
                <img src="  https://assethub.co.in/wp-content/uploads/2023/03/hqdefault.jpg ">
                <h3 class="title">managment2</h3>
            </div>   

            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlqmDS-rF1s_lJ-yy34rANcsCHssOX_cC9gg&s ">
                <h3 class="title"> managment3</h3>           
            </div>
    
            <div class="box">
                <img src=" https://fly.homes/blog/wp-content/uploads/2024/03/Holi.webp " alt="NO IMAGE FOUND">
                <h3 class="title"> managment4</h3> 
            </div>

            <div class="box">
                <img src=" https://www.homelane.com/blog/wp-content/uploads/2024/03/shutterstock_2125201604-1.jpg " alt="NO IMAGE FOUND">
                <h3 class="title">managment5</h3>
                 
            </div>

            <div class="box">
                <img src=" https://i.pinimg.com/originals/2e/15/14/2e1514fbed419ffa29011e7ac73da907.jpg  " alt="NO IMAGE FOUND">
                <h3 class="title">managment6</h3>
            </div>   

            <div class="box">
                <img src=" https://sociotab.com/wp-content/uploads/2022/03/flowers-1024x576.png " alt="NO IMAGE FOUND">
                <h3 class="title"> managment7</h3>           
            </div>
    
            <div class="box">
                <img src=" https://www.dealsshutter.com/blog/wp-content/uploads/2020/03/holi-decoration-ideas.jpg " alt="NO IMAGE FOUND">
                <h3 class="title"> managment8</h3> 
            </div>
        
        </div>
    </section>
    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src=" https://www.enhanceyourpalate.com/wp-content/uploads/IMG_7402-1024x597.jpeg" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Kolhapur</h2>
                    <p>Sayaji hotel, Kolhapur</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://5.imimg.com/data5/SELLER/Default/2023/2/ET/JG/SR/2713142/holi-event-organisers-500x500.jpg" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p> The Great resort</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://www.enhanceyourpalate.com/wp-content/uploads/IMG_7497-1024x682.jpeg" alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>The moon cafe</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://housing.com/news/wp-content/uploads/2022/11/Holi-decoration-ideas.png" alt="img">
                <div class="venue-info">
                    <h2>Mahabalheshwar</h2>
                    <p> The Heaven resort </p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://housing.com/news/wp-content/uploads/2022/11/Holi-decoration-ideas-4.png" alt="img">
                <div class="venue-info">
                    <h2>Mumbai</h2>
                    <p>Grand Banquet, Chembur</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://i.pinimg.com/736x/ca/d9/18/cad918cdec598206dcf7f6c564560c5e.jpg" alt="img">
                <div class="venue-info">
                    <h2>Karad</h2>
                    <p>The Deltin,Daman</p>
                    
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src=" https://img.freepik.com/free-vector/happy-holi-celebration-invitation-background-design_1017-12345.jpg  " alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src="  https://img.freepik.com/free-vector/modern-poster-template-holi-festival_23-2147756189.jpg " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt-iMENhyhyPNVvm8DD-WeEQK7ICU_DoQrjfhUMCA93D6rbOop98iuWoCxMJtdVm1Vo0M&usqp=CAU " alt="">
            </div>
            <div class="invitation-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkblp6K-kVfMcqNk2a1Htw2xa80_HEBMg0_ziGtpIGwkgj0qrIpVlw1rlgorbLDRSNN0Y&usqp=CAU  " alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTN5M47bdnaIT7nGWBUPH95p6m5K-hAyIoueN7UYkbYncFd6zvtCbSxC-5EmK1etSN-zCQ&usqp=CAU" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDr5soZ4SKavvRRdfMWwySUeEBDhPSSsslTx4_ai16jSgZsot2HWgSAisBZ-FvB4aASMo&usqp=CAU " alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://assets.ppassets.com/p-26fxRD3KD3ZC6lJLgUQIbZ/flyer/media_asset/jpeg_small " alt="">
            </div>
            <div class="invitation-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKBkUA8gOijKGu9DqISGZwm1nxJfzhmg7LW74tmC-HNW9NKFRWdE7y4O1nNmj49JylHQg&usqp=CAU " alt="">
            </div>
            <div class="invitation-box">
                <img src="https://i.etsystatic.com/12629977/r/il/f6674d/4707030341/il_300x300.4707030341_zr3r.jpg  " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPYimk3-kbESi6nNoJvw4gxAmzxjJ3bvWo3b_V3luJh_NkEmrOHErFuSjHoXMG230sNaM&usqp=CAU" alt="">
            </div>
             
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>