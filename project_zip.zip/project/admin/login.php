<?php
session_start();

// Predefined username and password
$correct_username = 'admin';
$correct_password = 'password';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === $correct_username && $password === $correct_password) {
        // Correct username and password, redirect to admin panel
        $_SESSION["username"] = $username;
        header("Location: admin_index.php");
        exit;
    } else {
        // Incorrect username or password, display error message
        echo "Incorrect username or password";
    }
}
?>
