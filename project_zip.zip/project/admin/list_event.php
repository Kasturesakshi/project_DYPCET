<?php

// Database connection parameters
$servername = "localhost:3307"; // Change this if your MySQL server is hosted elsewhere
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "user_registration"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<style>
    /* Add your CSS styles here */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        display:inline-block;
    
    }
    table {
        width: 50%;
        border-collapse: collapse;
        display: get_declared_interfaces;
        border: 1px solid;
        border:table-layout;
    }
    th, td {
        padding: 8px;
        border-bottom: 1px solid #ddd;
        border: 1px solid;
    }
    th {
        background-color: #f2f2f2;
        height:50px;
    }
    td{
        text-align: center;
    }
    tr:hover {background-color:gray;}
    .btn {
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        -ms-touch-action: manipulation;
        touch-action: manipulation;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
    }
    .btn-info {
        color: #fff;
        background-color: #5bc0de;
        border-color: #46b8da;
    }
</style>

<?php if(isset($_GET['action']) && $_GET['action']=='order' && $_GET['id'])
?>
    <div class="container mt-5">
        <h1><?php //echo //$message; ?></h1>
        <div class="row"> 
        <a href="admin_index.php" class="badge bg-primary text-white m1-auto p-2 mr-5">Back</a>
            <table class="table text-center mt-1 table-bordered">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>mobile_number</th>
                        <th>city</th>
                        <th>event</th>
                        <th>Book_the_event</th>
                        <th>decoration</th>
                        <th>E_invite_card</th>
                        <th>Message</th>
                         
                    </tr>
                </thead>

                <?php
                    $query="SELECT * FROM booking_form";
                    $result=$conn->query($query);
                    if($result->num_rows > 0)
                    {
                        while($rows = $result->fetch_assoc())
                        {
                            $id=$rows['id'];
                            $name=$rows['name'];
                            $email=$rows['email'];
                            $mobile_number=$rows['mobile_number'];
                            $city=$rows['city'];
                            $event=$rows['event'];
                            $book_the_event=$rows['book_the_event'];
                            $decoration=$rows['decoration'];
                            $e_invite_card=$rows['e_invite_card'];
                            $message=$rows['message'];
                ?>
                            <tr>
                                <td><?php echo $id; ?></td>
                                <td><?php echo $name; ?></td>
                                <td><?php echo $email; ?></td>
                                <td><?php echo $mobile_number; ?></td>
                                <td><?php echo $city; ?></td>
                                <td><?php echo $event; ?></td>
                                <td><?php echo $book_the_event; ?></td>
                                <td><?php echo $decoration; ?></td>
                                <td><?php echo $e_invite_card; ?></td>
                                <td><?php echo $message; ?></td>
                                 
                            </tr>
                <?php
                        }
                    }
                ?>
            </table>
        </div>
    </div>
     
</body>
</html>