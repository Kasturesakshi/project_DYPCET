<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_student']))
{
    $student_id = mysqli_real_escape_string($con, $_POST['delete_student']);

    $query = "DELETE FROM booking_form WHERE id='$student_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "event Deleted Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Deleted";
        header("Location: index.php");
        exit(0);
    }
}
if(isset($_POST['update_event']))
{
    $student_id = mysqli_real_escape_string($con, $_POST['student_id']);

    
    $status = mysqli_real_escape_string($con, $_POST['status']);
     

    $query = "UPDATE booking_form SET     status='$status'  WHERE id='$student_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Event Updated Successfully";
        header("Location: index.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Event Not Updated";
        header("Location: index.php");
        exit(0);
    }

}

if(isset($_POST['save_event']))
{
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $mobile_number = mysqli_real_escape_string($con, $_POST['mobile_number']);
    $city = mysqli_real_escape_string($con, $_POST['city']);
    $event = mysqli_real_escape_string($con, $_POST['event']);
    $book_the_event = mysqli_real_escape_string($con, $_POST['book_the_event']);
    $decoration = mysqli_real_escape_string($con, $_POST['decoration']);
    $e_invite_card = mysqli_real_escape_string($con, $_POST['e_invite_card']);
    $message = mysqli_real_escape_string($con, $_POST['message']);
    $cake = mysqli_real_escape_string($con, $_POST['cake']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
     


    $query = "INSERT INTO booking_form (name,email,mobile_number,city,event,book_the_event,decoration,e_invite_card,message,cake,status ) VALUES ('$name','$email','$mobile_number','$city','$event','$book_the_event','$decoration','$e_invite_card','$message','cake','$status')";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Event Created Successfully";
        header("Location: create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Event Not Created";
        header("Location: create.php");
        exit(0);
    }
}

if(isset($_POST['save_event']))
{
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $mobile_number = mysqli_real_escape_string($con, $_POST['mobile_number']);
    $city = mysqli_real_escape_string($con, $_POST['city']);
    $event = mysqli_real_escape_string($con, $_POST['event']);
    $book_the_event = mysqli_real_escape_string($con, $_POST['book_the_event']);
    $decoration = mysqli_real_escape_string($con, $_POST['decoration']);
    $e_invite_card = mysqli_real_escape_string($con, $_POST['e_invite_card']);
    $message = mysqli_real_escape_string($con, $_POST['message']);
    $cake = mysqli_real_escape_string($con, $_POST['cake']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    

    $query = "INSERT INTO booking_form (name,email,mobile_number,city,event,book_the_event,decoration,e_invite_card,message,cake,status) VALUES ('$name','$email','$mobile_number','$city','$event','$book_the_event','$decoration','$e_invite_card','$message','cake','$status' )";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Event Created Successfully";
        header("Location: create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "event Not Created";
        header("Location: create.php");
        exit(0);
    }
}

?>

?>