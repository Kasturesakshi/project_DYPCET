<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin dashboard</title>
    <!--Bootstramp css link-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- css file-->
    <link rel="stylesheet" href="index.css">

    <!-- font amesome link-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        .admin_image{
            width:100px;
            object-fit:contain;
        }
        .footer{
            position:absolute;
            bottom:0;
        }
    </style>
</head>
<body>
    <!--navbar-->
    <div class="container-fluid p-0"> 
           <!-- first child-->
        <nav class="navbar navbar-expand-light bg-info">
            <div class="container-fluid">
                <img src="https://tse2.mm.bing.net/th?id=OIP.Qc4Sh4Pbv6EfVNvmLerPKgHaG3&pid=Api&P=0&h=180" alt="logo">

                <nav class="navbar navbar-expand-light bg-info">
                    <ul class="nav-bar nav">
                        <li class="nav-item">
                            <a href="" class="nav-link">Welcome guest</a>
                        </li>
                    </ul>

                </nav>
            </div>

        </nav>

        <!--second child-->
        <div class="bg-light">
            <h3 class="text-center p-2">Manage Details</h3>
        </div>

         <!--third child-->
        <div class="row">
            <div class="col-md-12 bg-secondary p-1 d-flex align-item-center">
                <div class="px-5">
                   <!-- <a href="#"><img src=" " alt="admin_image"></a>-->
                    <p class="text-light text-center">admin name</p>
                </div>
                <div class="button text-center"> 
                
                    <button><a href="all_event.php" class="nav-link text-light bg-info my-1">All event</a></button>
        
                    <button><a href="list_event.php" class="nav-link text-light bg-info my-1">list event</a></button>
                    <button><a href="" class="nav-link text-light bg-info my-1">log out</a></button>
                </div>  
            </div>    
        </div>

        <!--fourth child-->
         


        <!--last child-->
        <div class="bg-info p-1 text-center footer">
            <p>All event organiser by memorymakers,fun and enojy</p>
        </div>

    </div>


    <!-- bootstramp js link-->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    </body>
 
</body>
</html>