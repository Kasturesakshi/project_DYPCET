<?php
session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="book_all.css">

    <title>Event Create</title>
</head>
<body>
  
    <div class="container mt-5">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Event Add 
                            <a href="index.php" class="btn btn-danger float-end">BACK</a>
                        </h4>
                    </div>

                    <div class="card-body">
                        <form action="code.php" method="POST">

                        <div class="elem-group">
                            <label for="name">Your Name</label>
                            <input type="text" id="name" name="name" placeholder="John Doe" pattern=[A-Z\sa-z]{3,20} required>
                        </div>
                            
                        <div class="elem-group">
                            <label for="email">Your E-mail</label>
                            <input type="email" id="email" name="email" placeholder="john.doe@email.com" required>
                        </div>
                    
                        <div class="elem-group">
                            <label for="mobile_number">Your mobile number</label>
                            <input type="tel" id="mobile_number" name="mobile_number" placeholder="498-348-3872" pattern=(\d{3})-?\s?(\d{3})-?\s?(\d{4}) required>
                        </div>
                            <hr>
        
                        <div class="elem-group">
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" placeholder="sangli" pattern=[A-Z\sa-z]{3,20} required>
                        </div>

                        <div class="elem-group">
                            <label for="event">Select event</label>
                            <select id="event" name="event" required>
                                <option value="">Choose a event from the List</option>
                                <option value="Birthabday party">Birthabday party</option>
                                <option value="Wedding">Wedding</option>
                                <option value="Engement">Engement</option>
                                <option value="Bride To Be">Bride To Be</option>
                                <option value="Naming Ceromony">Naming Ceromony</option>
                            
                            </select>
                        </div>

                        <div class="elem-group">
                        <label for="book the event">book the event</label>
                        <input type="date" id="book_the_event" name="book_the_event" required>
                        </div>

                        <div class="elem-group">
                                <label for="decoration">Select decoration</label>
                                <select id="decoration" name="decoration" required>
                                    <option value="">Choose a decoration from the List</option>
                                    <option value="decoration 1">decoration 1</option>
                                    <option value="decoration 2">decoration 2</option>
                                    <option value="decoration 3">decoration 3</option>
                                    <option value="decoration 4">decoration 4</option>
                                    <option value="decoration 5">decoration 5</option>
                                    <option value="decoration 6">decoration 6</option>
                                    <option value="decoration 7">decoration 7</option>
                                    <option value="decoration 8">decoration 8</option>
                                </select>
                        </div>

                        <div class="elem-group">
                            <label for="e_invite card">Select e-invite card</label>
                            <select id="e_invite_card" name="e_invite_card" required>
                                <option value="">Choose a e-invite card</option>
                                <option value="e-invite card 1">e-invite card 1</option>
                                <option value="e-invite card 2">e-invite card 2</option>
                                <option value="e-invite card 3">e-invite card 3</option>
                                <option value="e-invite card 4">e-invite card 4</option>
                                <option value="e-invite card 5">e-invite card 5</option>
                                <option value="e-invite card 6">e-invite card 6</option>
                                <option value="e-invite card 7">e-invite card 7</option> 
                                <option value="e-invite card 8">e-invite card 8</option>
                                <option value="e-invite card 9">e-invite card 9</option>
                                
                            </select>
                        </div>
                        

        
                        <div class="elem-group">
                        <label for="message">Anything Else?</label>
                        <textarea id="message" name="message" placeholder="Tell us anything else that might be important." required></textarea>
                        </div>

                        <div class="elem-group">
                                <label for="cake">Select cake</label>
                                <select id="cake" name="cake" required>
                                    <option value="">Choose a cake from the List</option>
                                    <option value="decoration 1">decoration 1</option>
                                    <option value="decoration 2">decoration 2</option>
                                    <option value="decoration 3">decoration 3</option>
                                    <option value="decoration 4">decoration 4</option>
                                    <option value="decoration 5">decoration 5</option>
                                    <option value="decoration 6">decoration 6</option>
                                    <option value="decoration 7">decoration 7</option>
                                    <option value="decoration 8">decoration 8</option>
                                </select>
                        </div>

                        <div class="elem-group">
                        <label for="status">status</label>
                        <input type="text" id="status" name="status" placeholder="status" pattern=[A-Z\sa-z]{3,20} required>
                    </div>

                    
                        
                         <div class="mb-3">
                                <button type="submit" name="save_event" class="btn btn-primary">Save event</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>