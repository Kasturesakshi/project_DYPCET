<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bride to be</title>
    <link rel="stylesheet" href="all_event.css">
    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://blog.brilliance.com/wp-content/uploads/2019/03/Wedding-Party.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

        /*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}

          /*-------------------cake--------------*/
/*gallery section   like ch option nahi yet*/
.cake .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.cake .box-container .box {
    height: 40rem; /* Increase the height to 30rem */
    width: 100%;
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    cursor: pointer;
    overflow: hidden;
}
.cake .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.cake .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.cake .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.cake .box-container .box:hover .title{
    top:0;
}
.cake .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.cake .box-container .box:hover .icons{
    bottom: 0;
}
.cake .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.cake .box-container .box .icons a:hover{
    color: var(--main-color);
}

@import url('https://fonts.googleapis.com/css2?family=PT+Sans:ital@0;1&display=swap');
:root {
    --clr1: rgb(21, 12, 104);
    --clr2: rgb(236, 68, 90);
    --clr3: #fff;
    --clr4: #000;
    --clr5: lightgray;
    --clr6: yellow;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
    text-transform: capitalize;
    font-family: 'PT Sans', sans-serif;
    box-sizing: border-box;
}

html {
    font-size: 56%;
    overflow-x: hidden;
    scroll-behavior: smooth;
}

html::-webkit-scrollbar {
    width: 1rem;
}

html::-webkit-scrollbar-thumb {
    background: var(--clr1);
}

section {
    padding: 7rem 9%;
    margin-top: 7rem;
}

section h3 {
    font-size: 3rem;
    color: var(--clr2);
    text-transform: none;
    text-align: center;
    letter-spacing: .2rem;
}

section p {
    color: var(--clr3);
    font-size: 1.5rem;
    text-transform: capitalize;
    line-height: 2.5rem;
    justify-content: flex-start;
}

section h4 {
    margin: 0 0 1rem 30rem;
    width: 40%;
    font-size: 4rem;
    color: var(--clr3);
    text-transform: uppercase;
    text-align: center;
    align-items: center;
    letter-spacing: .2rem;
    background: var(--clr1);
}

.btn {
    margin-top: 2rem;
    padding: 1.3rem 4rem;
    font-size: 1.5rem;
    text-transform: capitalize;
    letter-spacing: .1rem;
    font-weight: 600;
    color: var(--clr3);
    background-color: var(--clr2);
    border: none;
    box-shadow: 0rem 2rem 2rem rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease 0s;
    cursor: pointer;
    outline: none;
}

.btn:hover {
    transform: translateY(-1rem);
    transition: all .5s ease;
}

.title {
    text-align: center;
    font-family: sans-serif;
    font-size: 2.5rem;
    letter-spacing: .2rem;
}

.title span {
    color: var(--clr2);
    font-size: 4rem;
}

.title p {
    font-size: 1.8rem;
    font-weight: 600;
    color: var(--clr4);
}
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#cake">Cake</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book_cake.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1>This is the day love has made___BRIDE TO BE</h1>
                <p>Find the best bride vendors with thousands of trusted reviews</p>
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlwMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAIHAf/EAD0QAAIBAwMBBgMECQQBBQAAAAECAwAEEQUSITEGEyJBUWEUMnGBkaGxBxUjQlKS0eHwJDNywaIXRILC8f/EABgBAAMBAQAAAAAAAAAAAAAAAAECAwAE/8QAIREAAgICAgMAAwAAAAAAAAAAAAECERIhAzEyQWETQlH/2gAMAwEAAhEDEQA/ALqyjpitMAeQqYrXm2osdEWKIsQPi4d4yu8ZrQL7Uw0qzSfMkmdqHAX1PrSq2zD3eMVExDcetDzM8dVjtNq2qxxS2ukRFL4d2UZx4WBYZA8umRVJaNGLldF1UKqBVGAPIVoRubigYNRWaJWYd3IQC8TMNyE+RoiyuUnkkVWBZMbgPLPT8qXt6B0FbTjmtGGOnFSk4FQyOPWmaMiFeCSTivJXXHPNQ3U3drupbc6hHGrPJIiIvJZjgCkqmMLe0XaePQbxYpoJJmnhLQLGBwy9QxJ6crj7ak03tTBql6baGJwAm4OT1x7eXX1qvafeaJ271C7keJmjgBt4ZS2Ny8Eso8uePsqzW+nWWlxKlmgUJgE9azu6KRcFB2rZDqGmXk1xJLEjCM9MPjJ9qSSLIhKuzhhwRuPFXrvUMQI86qnaQqL1HXqyc/fxQlH2IpboVkv/ABv/ADGtCz/xv/MakByK0YVMcjLP/G/8xryvWFZWMXAitSKkNaGuhkUa4x50RY3oty6OcKeQaGYkCqlrGsxTyPbWokutvOYVLDPTyPPPFLeLsJatV7Y6Xp7uk8++RPmSMbiPuo3tAPjtJWSyue6dcSLIDwVx5+1cxstLuyqQyWxX4iMvu7suVXoSc/Z4R7+dXKzhMMEVjbBu5SMLIhPMfhyp9RnnjyNbLK0wwk4u0K5tCuIYl1i4e4ln7tWKPO4CY8ggIC9c4pr2U1VRqsvfC5WS6RAokPhAUHGOPPJ+vFbLcNPfhNQZO5DBo/U+oOeg/wDymOoXttsyAuSOtLGDW2V/JFxacdsfmcY60PLcD1qs22syljHgOF8/Ogtc7Tpp8QLYDuQFx4j9ce1PZEeateJ3fduwwByK5PBdNYTKs89xfM9wFLSTPIEVmA2bS2ODnmmepdpHu4ni06OaW4ccsIydvvgdaC0/W0SHZNA3xC8MyDG4/wDVJLZWDjFO1suEWl6Xpdz38S3NqeHKxPw46EsCMflSu47VzTXlzHZIGEYHdK/PeZxnHIz1r3SdMk7R6ddPK4Vw/gAJAzjjOPm6+fHtXnZmC3tmQXNs80VyVx+yIELoevI4xkexoRg1sTRao7u8k0gzi2xPHw0bMMHA5Ixnj2PNVWS9muZmmlfc7dfT7KtH6ugTVkvIWaHCMGiU4ViSSSffmqlMy9/Js+Xe2PpmqNOhb2FxTE9RUwbdQUPWi0qTRRM9Ir2vcVlAJaya0Jr181Exq7IoivFMltKi/MyEDnzoLTrWDTZd8a8nhj049KMZqFlbGaBh1FJAviGCTjnHl1/7pdp0KWPxLs+6SeZmZmHOMnA/GqzqWo31pdAWxVotuSrgnn76An1/VJFZIo4Y2IxvALEfTJrSnEaKZN231OSK/s4bBv26N3jKBng8AEe9L27TzBDHJYYmXqC+B92M1Z9V0NdMsY9Tgyb+7hSHvM5KsRlnHvtGPtpX2o02R20rALXZswZ2I5bnwk++M1OUvoyRV2mvJrprr4mSKRuP2blcD04rV45ZX3zSvKfV2JP503GnXYIVV59GHWpJNL1BL1rI27G5VthVUDc/ZU7v2PXw21u0m0rStO0+0zHPdqZbiSM4ZjxtXPXq3/j70Bq1m0+uXIRsFSEkZQMNIqgOf5gauvbCE2l9ZTwjfdC2AgQLlY2ycyMfbIwPX6ULY6A9roZvJIZrq4kfu4o4x8oIPjPn1H+Z4efdIWNVbFvZnU20S4kW5bdaygbio+Q/xe/9qtbazYyxb4p4mXrkOOtUzUnVGW1VhK8Ib4iaMDxOTwg8jtHH1JoAWPegvFvCnjxqB+GKEeRx0FwvaLPqGvxvuhtX3yEcsOi/b60pj6gmhIrdrfG4gjoMDGKMiHSqKWSJtU6DolHpRSLxQ8XQUZEMigMjAmayplWsrBseSGh3NSyPUDNVWRiROTQ027HFFGonUEUowlvGROZI3c4ySoFBx3FuT+ztZf8Algc/jTG/LDKxqXbGcD0paNRRboRPC6ZGMYwD6GuSbeTOiNYly7VX/wAHZaMyWK3RKblR3KgHavJx169PeobSW2ura6166tzbXFqe8ulDFwy7fmXOcEAcDpxXusanpF1p2l2s99bw3BQGNpCAuQAChY/KeQRnrivIbmx/Vk+mWl9Yy3V4ywyBbhCI1PHryTkjAz1qu8utE9Y37Ir82dpcQajMsvw01t8bKhUEovGF46kkgY9TRlymbu/1LT1tb1ZWjiWNZgAVdQpOV+U/3pbrs8N7qJ0lPipILQiNY0txtBUfvNnLAHJ6YpnpUEFj2Z1d7bu0JR2DAYCtswD99BUpVRm7ViyTVbfUNIurh7WadtLcCNg6qJ1dsZHHABA98Y5zSBpZZzNc3hm3zAd4sUhVQo4C4HkB607tNPhuNLbTtEvrW4k3iS6VDyVT5VXyYZOcg+leNpyW+lfHTyMqCTu0RISSzfTy9KWbk3pDxxXbEcToRsa12w48KKcVLBIsMYSOA7R6vnFF6i0FvNHagE3ITfNxxHn5V+uOfuodCm4hpN3oO7Iqe0UtAt9J3nd/syn25qS3jyAa0v2BaMBSOTyRiirZfCKvDUSE9yJ41xRUXSolWp4xxTWAkFZXorKYUYSvzUJYE1o8mTWm+nbFRLmtXwFJY4HnWm6g5obmSXe14VjHRI0A/E5P+e1JYSvatrMETj4WeeN2QMshXyPTqOlKotSm1SRYI0eW8XGzugW3c9T5jjPP/VG9pNOUvD/q5GlAOe8IZmX0A6AZx5UN2c73s/b/AKwtkNzNcxkPhjlFDHkcceXvQUFJjwjKTSIrW3mur6Q3Mdr8u6QzMFC4+vU+1O+y9/pseo28whgVYJlLMuP2fPU+nrUlhHYahq6Jdaa8TECSQtlVcYxgKfIkjke9Z2v7OiyuPi7RIYreZgzQglVyB4vF5Z449jzzSOMf6X5ILjLLf6vp2kXV3HqM0mbx3aH4Vd7KpbcH8Oce3uKO0m9n1/RNY/0fwis5MCM253/e59MnjArj+h38ENrcXUdtCsZywCnnjy9/rVpj1+c2Vxp1kF23O0s6sQ6bTkMta8dMj3tFx7L26i+hlVEQRglmBHhGCOfSq5e6tqd5qF1d2V9NbWLuUhSIrtMascNz0JyTnjr9KCubzWr21ks7vVJZLaT507tUL+zFQCfvpNrTG3tSLcd3tHmSQR6YqSaSxix2ndtBlvq+n28kka9/IxHePMoLZHmzH69Sfat17RW7W6S/DzgSStHF0PeYxk5zjzHWjuySafpGqFre8ilW6hER7yQvvTjfx9R+NDadcaPD2h1OHv430+dy244CoccoOgAz6elUfCjQzZk8wldCG4x09KZ23yiq61xajU50sHBsxIQrM3OB9fz9KsNowaNSCCCOopqqNCXbDF6VMhqEVuDigjMnBrKjU5rKexCR2qMtWNID51GWHrTyFRvvxWsk3FRMxqJmyOaRBFWt25uSGRBuwcuAM+1VXR774W+nlkaSGO1c92W5DYPIxjjp9xq8DZvbcSOPXFJ7y3tSZEj2vuJJxg4z60ueMiiWrQ1ue18skEF8gtJjMrKyxnDqwJx+PWthrUes2t3BqhEKJGBIFfl28hnov06mqfdiawX/AEVwIxgjaW4weucfnSi4+O7y3JKIZTw+QQ3lzVKjLY+UP2Q7vrLSLewuJ2vpraUr+ytyNwkT8xk55+tBaBqLHuoo3CBclVIDEeuPXzoCfVjd6ra/GBpXiYCSIAbTg4AH0FdTtry906aOTS4YEsoQRsldCdp82GRg5448sda00mhYwV2mJoHuHXcLh3yOiAUPd2s0q7nDnY24A7eSPsprfarBqE8dzLZiK4aPEyxnK58unXjzof4hFTCxED/liuN2pFdNCPXG0i3sLKPR5Z0vI1PxLxkxttwScnHPi4wM8VXbJ42uI42y8JJLdPPnHv8AWm93Y75mbu5Dk8HdyPwre3tNjA/DEg85/wAFda5UkTt9G+lojSO3cLGOgHXPXk1abMKkaqihVA4AGAKRgIjqFhMfHOec03tZPCKVu1YnsZK1bg5odWqdOlBGZIDisrUnisphQLvT5mvYWaeeOGMrvdgo3NgD6mgO+oqwZxcRSrjwODzRkzRjboJjiuJO/CrzAMuPtxWiK0lpNcEqFjcIBnJbgZ+mM+dTwak41m4kXCK6Y3AeEnHpQdlcyJZX8WFRn+RccNwetSc0XXB9Btcjk09baQoJUuE3A8jHTj8aSrcn94BR5jPSnusmS/0i0iz4rePLDPCnHIojs32Tnk08Xt1Gkgmj3wqRkhSM59j+VJakNjjoqtytpKuXmjUDBJYfnmlmo2ds7RlLpSFOQFHHSulW/Z1kZSbfPcDgMAfLrj8eaG1Xsw/6okcRwwbBv71lx65GfeimkxZcdrs53pmhwXep2oSRjmdCwRCSefyrs2o6Hb21u00Wo3qxxruMbykAgevhJP0rnnY9ZxrcBiEwyGA7ltrdPWugXA1cs8T3V4YG8J3wqSBz5/2qjlfYkYUyk3lwrXk1zbSO0bkHZg5GevXmhDdyCPO0R8/w/wBq27RWP6ve27k3B73cxaTGT0x+dWbQOybNpC3z91PI4DptXcFBHAPv68VOUU3ZVyTetFWN2+CWIx/xNYmosMeI4/4cCrWezY75o3s8Ivi9umOoobVezsjWjTWdptZV3vjwjGPupWknQcXV2Iu7uL1XuoYJGhhXEj4AA/v7UdHFLDFFJLGyJKN0ZI4Yeoo6UMOysNjbnExYl02kDOfm9DxxTDVjA8ujWduQ9mrqrkDmPcQDn8aqpLEg4uxdtdAgdHUuAVyPmHqKmJaNikisrA8hhgimFwwvO1UERZDEpA3qfDjBxz9lL9bnY6rcb8AhsHHSjoFHveCsoAzGsrZGxFSS+9NNNk3xuNvykHLdKi7N6BPqgFxcExWYPzEcyH0H9as8uheNmhliSPACqByBS8ibjoPHSexVINyEELjHQYFBRwLFIAiSEuQBtA4qzr2dGws12SMZwkeT9nNQW+jyx4lcHeSNoJwF3fKcjzHn/gqEeGbey+cRRf2NysM0aozNhl8Kkjj86RWDatpkeyz1f4dQP9pJHA/lxirtJ8UljNbbHmkt2wrQHIYMeOd3TOc/4K1OhxzRwvPbBZWb9tNzyoGSffNWXHiJOViVtT199Bc/rOVp++8LhiPBj6evtVdmS7vpVN/fJK/ODMzvj7xXUUsE+F7lWiVccqV5H40tfs1p9vG83gJRSxGDg/jVGkyaKnpGmwi/gDSK0gnImkRgixJtznkA8+vlV6vJLi8Gy1u444FUBZBcgHPv5Ut1Ls9p8MeoXMQMci2pcL3mF3AH+nSgx2Ne42ypqioHQbQsGCvHH73vSuI7laoVdqdCN1Buk1S2aWIeE7+8yTjr6Djy/GkENjqGlANbXscDYxuglkUke5AFXyx7O6Xe2NpNPFI0ksIMmZWGGHXp7g/3piukW08e3uYyFOMEjy4xQxaBZWvi+0kfZMT/AKwm783GVk3tnu8DzI6daSi51O9t3/WWoSzYdVCtMdpyeAeMV1SbdLady0VvtC45byqvN2XsUkSNFR0mB5TpG45B9CP7VSWPYib6ILR9sS7eDgDrxUju0h5at47YrDFLscKrd3LHn8cnmvDYy+ODJ+IADxuSNsgxyCP3TnP4etceL9HRaI2VyPm4pTqu2NkGAD7U5srb4i2WVrgQsSRslXByOvn/ANVvPoi3YPf3cKoBwyDJzVIKV7Ek40VXfWVLqenXGmy7ZCrxt/typ8rf0PtWVQQsEnbLS7BYY2tpSrDaqxJ4VA9uMVn/AKiaTHkJZ3P12L/WuVlgPStHfirJ/CNHU3/SXpp/9teD6Bf61Gf0nacox8Peke4X+tcqL+9F6NZ/H6hHG3+2vjkJ/hHl9vFNdKwVZ1Bv0h2Ufw4a0ulafJjQkDOBn1oC4/SxYwSPFPp9zuQ4wT1/Gua9pdQa71N5oCVSJwIdvljz+/mjNatYtX0eDVbaMLMq7JkHkR1H+eRFK5/B1Ev8n6V9NMir+rpQzkAMyjz/APlR2sdt7e106Zrq3RoSNjCFhu8XHHiriaKZrUhh44+R7ihREvUR4P0o2A6TP240m4Z++OsSJIAJFafAYDPGN3ufrmnsf6XNNjjCLY3ACjA8AOP/ACrjyL6rXpQD9wVrMdFbt3pTyAKdXtoldnVIJtqhmyTxnpyfOrLpXa/TLLTbJ44rlhcSbVeVyz7myfESfY1xJxgHC5+tTafbRvIZHVQqjLNitaMdjl/S1psar3llcYYZxsGcfzVvJ+kC0nsPjzbXkMCeanZn/wAq5No9hJr2tpHtOwtvlOPlQeVO+3N7EssOkWXENuA023zb90fmftFazV7LzJ+kOzhws1vfAuMjJzn3+evB+kSwdsmO8P3j/wC9UCwA1LQnhx/qLQgp7rj/AAfZS5HFCLsL0dSHbvTGILW9249HOR92alXtxpbLj4CT7l/rXL0cUTFJ71mA6Wva7TryBozpkxhDYKsikE/fWVzxHArKBiV5ef8Abj/lFQyTEdEj/lFeVlMZkZm4/wBuP+WmNpKYtHu541VZGIQsBjjj+prKytydI0SrajIXhHhUc/ujFNOxcjPNdWrHMLxbyvvkD8jXlZS8vQ3H5CqcCHVpEj4XvNuPY0LcrsnkVema8rKyNLsiBIPWpMnHU1lZRFNCSPOi5f2enoqcBz4q9rKwUXXsHBHBoNxdoP2zuwZj6LwBVFeR7mV55nLSSMWY56k1lZSx7YX0OOzcrw3ahGI3HB+6j71jDeSxxgBVPHFeVlZeZn4niTvn93+UUWs7gfu/y1lZVRGTrO2Oi/dWVlZSsJ//2Q==">
                <h3 class="title">Bride 1</h3>
                 
            </div>

            <div class="box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAFBgMEAAECB//EAEEQAAIBAwMCBAQEAwMKBwAAAAECAwAEEQUSITFBBhNRYRQiMoEjcZGhQrHBctHwBxUkM1JikrLh8SU1U1RjZJP/xAAZAQADAQEBAAAAAAAAAAAAAAABAgMEAAX/xAAjEQACAgICAgMAAwAAAAAAAAAAAQIRITEDEhNRIjJBQmHw/9oADAMBAAIRAxEAPwAz8FFezRC4acS7TvcYCDB44655z9qLf5ssBZBZIElUKVLMBv565PH6UjXt5LM0cxdlEbAqGzhwvfH9TV6w11ru7jsbd1kkI3YYsNgxyct8oxx2/LNRjo3KKQT1C5u7m0uLYwu0M67PIZh+IvI4HrwKK28MOn6aiRI8KvHtKkbcd/T96qolxZyLNd31sxkQxwJChUK3G7knk4yPtWtU1YpYBZg88p3D/RkLD19OuPbpRG/LCVhKDFGNwO0Yzkn+dFIzx1FAdJniuIleN95JAfaOFP581dvbgQ3lqWJ2Iruyg/UcYUfrRfJUbIzywjPOsRVcFpG+lF6n/p71FPJcwwtM6xEIMsi5zj8/+ld2sJjBklwZ5OXPp/uj2FVNXm3hbGIjfLzIeyIOpNdKVRtiInZxIiuvRgCKHXce4Gr8MkM0QFuxKoABwRx2qCePOetMsodYYt3MGCSKX76+aPU4bOOMNkgSsf4c5wPz4zTrNb8EnpSvp1j8XetcsPqLSn7/ACr+26oyeUvZaMwXqUBKZAJx1HcVb8PabHYQiV3V2J4z3onc2eM8ULnSS3QiJivsKovRRNMFeNjaJas6s7Sy8ZIAA9gKreGoILiC2fUYwsgJVcsMtjB/qKiu7Xz7sF2JY8Asc4NENN0iK1iF1en4mToqg/T/AIzTINNvAw3wsFtfJa7KxdW28YFIF8baa8kh0W1kuxuyzY/bNWLXRRrniL4SEuIB87qXztX0/WvX9B8PWWmW6xxRquAM8cmuSsnyyUdnkcV5f2yCOfw6jOO/lHn+dbr2uSCItwgrKPUl5xH1W4sotdtfNBe3ZPNMZUDaeg+1Qafo8N1rV7f6ZIro7+UI3fcjZUbgSfcnPOauapZwvNaz3EQeJDtfd0AJHOO/fiiLXrrHcMltHDJEw8uQ9JMEYGe+R+mOlSqmGCTVoF63pd8+nlke3nitmzMiTFiGAIA5/Pt/SpbOe60GOBTAkYmiDBRINmOv1dCecH8q5v8AVmWKe2ktZYfjMo05AAVz29c8nBx17VetFSe6hs4GyhjIa38vK4C+vYD+7HWuLJt4lo1YtLDMZWkUmeTcy5ORnJ455FGUj8/XIS4z5MO4fnnj+dDrawls8R3DowU5T5t+eRyG+/SmC1hRZTOB+I6BSc9hXKHZEJ4JbyaSGAtDEZXPAAGfuap/CQpp0xluFMtwPmmJ+o56D27Yq5NOwkEFuA0xGST0jHqf6CqdtEtvrMkbYdni8zewGQc8/rXTzIkZb3A89muFMEk5AiVgcMFGMA/rwcVwjx3d7IqR5+H+USZ7nqB+lRXkjTas4XrCqxx/235z9lyftXOn2s0Vo1oEkjkZ286Zh0GeNp7kjH5ZpFN6WkOD9QnklivJYpSlvH+CqhRh2PXJqBt2n2cMC4F1cfMxIzsXHYeuOB96ti2uIo7CxuIQkZuCWJI/EI/pg1YVlGrXFzIjmPAjiZULcr9QHvn+tSSbdvf+YSksLx28Md25aeTONw+Y9Tzj0FD72168UxrA7yGedNjFdqR/7C9efc8foKhuLbcOlaksDJiDPpk13dpbQLmSRsA+nvT3oPgLS7VFlvzNdykfTJIfL/4en61FptukGoiRlH0kU0i6XbTxO5ZyeiOPRdKtWL2lhaQSEbd0MKocfmOtQTP5LbPUcVJNfKDVUr8dNAobaFJZz3x7femv0TjFv7HDzfNwa1R6OGFF2qqgD2rK6heyPMtYsbeayeIRhXZhtYfTzwc/rQHSxdaXq5sLiRrm3jxKJgSRGegXbz6dqYb2SCePa0y44P1VS8q8iBuo44ZbYr87ucup5575Ht15OOuKg9j8UloI3moLDp0wmkEzlDsUty/GQp/bBqlY66rxSzQ293Eq/IQFO5d2AOfWpZtGnurZJro28ez5zFEAW78ZOQTjt15PNRw3sM+kSwWUkIlebMg27The/uPautmhP0wjpK3J2QyC42bvMzOwLNn8uMU4Q/Kg9hS9pIJVGkO5woBbbjP2piiHyinjohyO5FCxv7eCy8+Vw887FzGvLM2SAoHtgCrOm28wklvLsbZ5v4M58tewFTN8LbFpZBDCx6uwCn7moxqdo3ELvOf/AIY2f9wMUqSTyxLK1tYzJrVzPIo8g5aNsjliAP25opio7eZ5dxa3liAxjfjn9Dx96mp4RUVgDKV/aG4ETI+yWJ96NjODjHNdQQLbwJEhJCjqepPc1aIrkij1V2ErOlQSRZFXStcMtGjgPc28juBD9fWuHuJofluYymB9YOQf6iiyFY3PbNRS7J2Kvgj0oOJRTraAkl6jnEZeVvYEfzq7ozzQXMxucBmC4Geg9KtxwQRHIVRQrW7zyAJYsb16e/tSfXJaM1NdUhl+LHrWUpJrOUHmI6tjkDmso+QTwlOc8GlXXNevdOvILW3ZBHOu4kruYENg/timKSViD+DJ9yP76RvF8n/jFj8hB2nrz/EKGLMabWhrmu72UIsEoME3KSRDkjvV3StOBty0TL9ZLjbyR25of4b1VdWW4uI7NLeSKT4c7TkNgLk47Z9KZ4SsjgxxeW38WOje9J1dmlTtWENPi2oMjmrt1by3MAjhuXtm3ZLKPqHp1B/Q1xbphRxVtOKtWKJsD39lDDDaQeREt3cXKx+bksxAOSctyOB0pjHTgYHagdw/neI4BgstlbPKf7THA/YVS8Ni6uN9wt6wM8SyTAjdtLEkBewIXHY9elRi6nSRw0llXliFHTJOOtQXV35LJHFGZp5M7IlOM+5PYe9CvFFylvDYeYcRm8jLAdwvzfzAohp8LorXN0v+lz4aQHqnog9gP3z61Ts3LqgV+mriO9S3lne9VXRCwVIxsBAzg55/cVJp9ybzT7e5KbTKgYj0qhrdw93INHs2/GmGZ3HSKP1PuaJDyLK3RWeOKJAEUuwUDH50Iv5P0gneK5bpXR55HeuWqoAXqMpiO/nApcvfEcFvOiRMZZ3zthVTlsde3FM97GJFYetIGqQxWniWFWwrS2spQt7Muf8AHtUp3VlYtBW68TwJEGkjuUZhlQIic/kehpP1PxVO18jTQNFaA9GPzexI7flR/T21G1uI0trmUQSKSY7fDk/c9PtS9rPg7VhFI7Wr4eQuXbcWK/7PpWZclvJTtWkGYvEGnSRqwljII9ayvO4NPjQOl7vilViNpXtWVS4g8n9Hq8hGDSL4z/8ANNO/suP3WnNxN/6sf/5n++knxkHGpadvYHh8YGO61dbMTGL/ACYReZZak2Ol83/KKfraEKc4pJ/yUDFhqo/+8f8AlFegRjijRSLwTIMCpgeKiFSLTBKmm28qX+o3c64M8oWPkf6tBgfqSTV63higXZBGka5zhFAGa0D1qQccdxQjFI4Da3GLnWtFt2GVEjyt77QMUYuzcm2lFk0YnI+QyZ2g1vaGYMQCwBwcciql1cSyTiys22Sld0s3GIV6Aj/ePOPuaWlG37O2VNKkt9NElpsml1NjvnULueQn+LPQL2GcfrVAw3PiLU5jcxrHZ27GHHmbgGH1Eerds9qtyww2niLS4LRdr+XL5pzkspA5Y9TyOpq3Bp1xatcR2t0sUM8xlJ8vc6k9Qpzjt1I4qPVul+IYuQT+dPOkagQwkIG9W/iA9hwPzz6VK1aghjt4EihUKij5QDmtmtC0ApXsiQxNJJ9K0s3fhy+8Rg3lsyIqq0SkY5B6j3o34jjaTT2CdmBNLFnc6vo4PwExS3ZeYwfMLevUYBrNzyp0PHVo3o+onQ5Y1K+a0I2cjLMQMf0o5rPia/1C0gisUFj8QCfNuCAMD0/xzS5a6TrsVjJd3EcQskclyWJJQ9OeMkE+uK51/XHi0Syt4dLtJWzgbFLvIQAQRjpz6E/pWb5aC0nkpS+DvEeqkXLhH42Bs9hWUY0/XNRW2C2OtRRQqSAgKEKe4GTmt0bOplZ+lKviTTLzU9Uso9Pt3uJLdWeVIxkqpK4P7GvT7PQorQb0be57vnP25pS1Sa30PxLdO+pTWL3CZlePqUbgc84IKkdq9CmShxdnkG+Fpbrw9/ok4ji/zjc+cZ3G9YU+nkA8nI6U76brEE85t2fcS+2OXyygk49DyK830NrPUtfgvr8Tm288xh4HJb5RwQOuSQDmmu1XTk1GSeSW9tVjBMCNF5jscg8j7/tRssoKqQ8LXRmeHb5aKxc4wxIx+lDtEvjqFn5rABlYqcd/eiDfXH+dFkJKiU3N0dRt4I4VMTIWkl7L6Dnr3/Lj1qe4eUShTs2Htt5/WsGOZckFQD16gVFfzJDG8zsqiNScE/VS0JG2zse9B4XvrS5vtlhJPNPOWSXcoiK4AXJzngDpii8TB0Vlwc88HIroDPajKN0U0D9M05rWWW6upVnvp/8AWyAYUAdFUdgKI5rR4rVFJRVIJvNaPSsrRrjinffNGw9uhpDu5xFrz2EcIVTb+a0oYgjkgDH260/zrkGkfXtH1dPEo1C3shNZNaCGTDjcDuY8A9etS5I2houiw+o3y6PdWnx8vwojxtCrnH5tzST4Xunj8RyvYWV5cMGCWzo/KL0b5ugyD29xRe+1uxt2KzJKHVgGiIxj2wau+H9WhYx3ujTlTAxRYjwFJ5xj05+/2rKk47KzhWhN1XwH4jkvpZJLB1ZyWxtZu/qBWU/a/wCLdWW/wNQ+H+QfhxpgD9a1R8zRDxsdludy9RSV/lFsbS7W1nlZlZQ6kp1ZcZx+oo1Dck4XqT0XrmqWv6TqWpPERAyxxHcpDqHz64zWztaNEOOpZETXoR4fvluPDCTQ2UzqFS7TktgZYd8cUXsQbq1t9Qn1WWTUZpPxY4oyEjTOCvpknJoxH4dlvo9upTSPs+hTxtNXLLS7qJVgnk3xK+4HaM5oDNKOmHNJjSKARx9B1z1PvV7azMhUZ2nk+lUrI/hAZwR3ogoBOWKHPU9zVFoxcjZbWMmNxtO3GKVtVimurW4tkuYvOMXlxh3wd3PylR0784zimNPLAOSue3zVHLHFL82UEg6OMEj9c0JIHFNwdlHw5ay2Glw2dwxZohjOcjrng9+p/ai8Q3EjOO9U7Vy6sqbWKErhe2Ksq7cfIuf4hQTwUnLs7OnALYU8mumgcNjPGK1kSMD0GefYj/tUjXC5x39jQckBEDKy9a0VOOhqwXVTljlh0FRSvv6qRz60U7CQqQH966n2vGeDnv71WdWa42owLk4C/wBfarnwjbOXJNFZC6FHV/ClhrWoRXN7GW8jkYON3sfUVWu/DHkSq+mqsTnjapwpHoR6U1CCSK42E/K54b7VPcW5VN6NuYDp60rgmUU3F4Ev/MWvuSxewIJ43bsgelZTkttduobaBkdCeRWUniiDvIWvDtvb2oeVAvmucbsc7fSmRJlK0iwvPoFz8DqZIBOVlIxjPY/30ZGohY87ht9c10ORNFpx7uy7rl1HaIk2cZbB96ntbS+nhDvEkORxvOT9wKRPFV+93DH5MhCI+cqSNx6U/wCn38/lL8+8Y43jNMnZLm+CR3BpYgjHmTsx74XFZJ5aNjMvPAJYDn9KIxXZON0a1MWikGHhUjvnmnMr5GwYlrIwzk4raxLu2/iZ9jmiSw2n/tYf+AV20scSErEoUegxRAm7BklsVXFq+J+uGOMgnnkV1bxySQSheZIWZZI88juD9xg/ehtzf+RqG0XH1NhY24Az39x/jtVe8exspN93NOjzHBEcZOGOSTkDpjt04qN5NC45PCCccyLbrcwE/Dy7vrBBB6dDzjg/9q43SyqxgZFcqdjOfl460MlN7Yzq9iRJa3CETO2DgEdQeOTwOP6UMjnvLl54bKJy8JQDzW8tAD9WTn+Hqf8ArSpFIRw+w1QzGK68poDI5jH4mCVBycjNVl16O5ZobVozJvZCPqVWGeCQfb+XrmrAjvf83tH5LMsYBB8wKXHfHFV75bOB2kigtbRHDMZlh2tnHcjr0H59vbs2LFfIkkv3jVFtbdWbd+KCw+XPc0SS63R5ZGQ+hI/oTSvZ2M9zHHPOZkikUSBjMck8YYYx+Y4+5rl9TFm/w8k+9kO3cFxnFNGTbyHxqbwHNSaaWPbaYM2coG6Z967js75oVMskSOACQnzZx1HPah2iah8TcylhgKAEJ4z1zTDHOMdaoqeQcknDAPbU2iOx1IYcEEGsq+0iE5OM/lWU1E+69HjPim+vjaBtTn82dup3ZyPb2pfsdUARVl3qPfNT6HbX3iPW0h1MtBbpgzzS9ETPIz69h+dGfFzaHhR4ehZI0JR2fksfv0FYY/DBpjOtAqK/XUJTFE28RkbsdBXq+mE+SmfSvIPCMa+ZeMMfUpwPyNew6aMxKfYVoRDmk5xTYXi7VaSq0Q6VaSqmUkA4oT4iO21XJbaXGcNgHHY+x5FF16UI8RtJ5MKKqtCz/ihhkY7ZoPRXh+6Bl3Aly8LqsY8pWd3ByQnsvv6/1qO4sWvZoDEyNG5UI0hKhRzgkdz2HeoNSl+Djt7mwgQQsfInhI4Jboc9RjH6GhUt1ql8qwpH5CMpIIUjnHGPQdeRUTbG3+0HG0q9j1CGW6uiEUnEeTknpg84xz19h0opcW9t8KVSMAbtxAUgE+p9aTtB03Vb2e4S7virMpDTNmRjnrnLAY96Ybi5u9LhjtgjXijgzbBn6eOC3PIrqwJPjp0nbLB1a1W7aYyN8QuQY/mwP2wRUF9brqSrKkhUbQYmVV3Jg+hB45NQWktrNL56TsHR8OvTacdCD/PvQia71i51y5tre1a106HZl5EZct1Yrgcg+nHOfyo1ewU+xbtL2/iuBbOyO6uwkkYk+/FIMesPH47UX87NHLGUBJ+VGbkfqRj716hpdlHom69lZZEmXcXkPKknPAx6EZ/OvP8A/K5a2t/d2U9gudQwY5IUILeWOQzAdOSceuT6UY4OnKVYQ4fFC2xKvQD5sCiVrqscsIaOQMPUGvG7LUdatIfhrydVXbiPzs5J9M/30RsYmeBHSaVJ2wZWjcqc98Y9KcrGKmsnqkmogN1NbpZsvDnhq5tklvNbn88j5xJLyD6c1lGmDpAC+OYUsNdkitcpGsuNoPB/OhniyQiztWCqDIm5yBjJrKyvPjsX+JQ8FHL339pf5GvZNKH4Ef8AZrVZW4zy+iDUY6VOtZWU5BknaoJlWRdjqGU9jyK3WUGcgHqVpb3EqWs0StCW37fQ461WuYWtWCxXExCN8u9g20emSOlZWUhZNlS2uZp7u5tXkYIVQgrwVJ7j3obr7SQ30OmiV3t4oRKN5yxZs8luv6YrKyuNCb6hbTdJs7a6iZY95kOCZDuxz2z3461Jq1/Lb6b5kKxozoScLxndjP7VlZXMVtueSlBdz6hDCly+VeMlgAOdvGPv3oHuxrV2wVAyyYB2joMj+QrKylhsstlDxHi7JiuljlHwzyBjGqkEDI+kD96V9DvJy2wudsNvJswSMY+YA46jPrWVlVYU8jtpF38TaeZLb2+4t2SsrKygWP/Z ">
                <h3 class="title">Bride 2</h3>
            </div>   

            <div class="box">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAFBgAEAgMHAf/EAD0QAAIBAwMCAwUGBQIFBQAAAAECAwAEEQUSITFBBhNRFCJhcYEykaGxweEVI0LR8AdSYnJzwtIkQ5Ki8f/EABkBAAMBAQEAAAAAAAAAAAAAAAIDBAEABf/EACMRAAICAwEAAwEAAwEAAAAAAAABAhEDEiExBEFREzIzYSL/2gAMAwEAAhEDEQA/AHvrXmMVkBUxUZYY4rw1nisG6VhqMCTW7ToxNdgNyFG7HrVdq3WJkglWfblOeO5FZH0MuXybQcUo+IpWWxmj3YV8D8aPa/qTpYXEkER81Y2KA4POOK4lDNq2qXjQ2lxdXM1xwUJLAj1PYY9ac/Sv4+N1s/oK61FDHHtQ5fHNUrBlRTu9KKSeE/EQg3S2sbsP6VnUsaXLmWS0uGgmjeOZDho3UqQfjRWWxyRapM6l4YYjTbdj1wTn4ZNNaXpjtJGDAPtIXPr2rl+k61qVnpm+S2jukjX3Qh2nA7d698OeKLzX9akWdVhhWImKFTnnIySe5rrojni2lQ56B4S0W3sore4tkvioAL3A3A/Jegqp4u8D2Vlp02qaHF7O0AMksCZKso6lR2IHYcdaL6ZOYSNx4o1dX0Uel3Uk5/lrExYE9Rg8UUWmheTaEtonNfBbS6nqUJRT5Nt/Mkb09Px/I10YLigPg2406Gxj0u0sjYkKHZWbcZeOW3d6bUtI3jypIbtzQTxyk7EZ23KyiRxWpxW9lIJBGCOK1SCkeE5oNSvTXldZ1GVSoaxJo2EjwmtbmvSaqX95b2UBmu5ljjHcnqfQDqaFhxVmcjcdaOXSKEUJjaAMfKkNfFmkSSeX57pnozxkLRuTW/ZrBHZTPFj3Gi98lfXjqPlWwerpjv5yT8CcqoVO7pWnTdHtLFJri3toklnPvsqAEjsCRSjd+OtPjXMSyzHPACY/PFMXg/xImt6a6yBEuY2O6NTn3CfdIz144PxH3saNywnGF/RcKb8gHknnFKv+peh29zpY1SOPbcWpXLEe80ZOCD8icj6+tOCBY5OhxmhXjSOa+0Ge0swvnTlV97oFzkn17VikkuisL1yxZzvSrzGnmAMMdQvqelK9vcyabqRurNgGikYrnoRnofhimy08KXMMcvn3YSTGEEQ3DPxzis9D8JQwX8M2qSrPCjgmNVIDfP4fD4UmXycb5Z7F41bTHKwuJLiKEvbSxzyAEwgZIJpF8ReM5tQItLSOS3tFb+YJCA7kdMgdAPSulXkzWqM8ABnfAjYdGGe/PPX8fnXJ/HTwy6lE8dsIr6SPfdbPssxJxx2OME/P60UMlsnwy3l1B7w5q8l1qNkEcs0R+e1QDn6V0Z9fg0+ykurxwkcY5JPU+g9SfSuY+FLNdN05L5mUXbvzHj+jrg11HRBbNEJJQsjsOrDOBVcbE59QJY+NILmRWvLKa1jkOBKSGUfP0HxGaZJFpX8feHRL7FJo0AElzN5MkUYwgyCd5HQYwc+tNCpsiRMltqgZPU4FIyxSZHkUaTiaCOalZMOalJF2YNWpzWbHmtLmmNhJHmGdgqAlj0ApK8bpK9yySN7sQAC+hxmugaSAXmZsAqnfsO/5Uj+OpbG4LSW19bPMow8YlGWA9Pj8K7H6UYHUxIgCbxvGRnkA9a9tNbl097m1RyYmQmJTyEf96Ge2oGwJF6+tYTWlzJC+oLE3kJjLkcEHjI+/rTpJfZ6LlaLNxC/u7icmiFpNPp4intpHjkjbO5Dj6fEUMlu2mVGPQDiiNhHcajmG2jZto3H0HzrKGunHp03RNdbUvciCzsByy4ODx6VYu1kdlUrKzH3mJB/z1rm/hO6uIL6OzWJmnMy8bTuU5GQfhjrXX1MikLHnbjjHSpslr7PNz4lilwANE6DIyPmf2rVNA0kZBPPr0ppy7LhgT8M1re3jl+1Gcj0NL1/RSy0IlzZ3yKFjd8dtrnj8a55eJKNSn6mVZWB55zmu5zWcC9QwNcl1TSbpNUu9tjIu6ZmDsc8ZPNHjSi7PQ+JmUm7MtGa9uj7OkRzsLncdo2/vxT5Y63ZwWUM17NFYu2F2SzL1x0HPNc0sI3n1NbdzKYVy0qxE5YD1I6DOBn1Io54ntbaCO2CafJFG5DrG+SynoPXI5P31Qp2yf5UtPEdVsZjdRK6yF1I6joKtMOOlcj/091q9j8XRQsxaG8DRyxA+6m1GIPz4x9a7CWV149KN47IP8+lJutSo32jipUrMNDGtJDSMFQZJrORq3aU6GeRT9rZx+tF6xkUI/i68mV5LVXKxr7r4P2j8aUI4xLLhj17mmfxyskF5KrKQGcup9QaUEuNjZqmKpcPSgoqIUsbptIvlKkPbOQJUKbhj/cM9x+PSm2GL28EzEkMMMo6EUlWMbahexxtnaT75x0XvTxpUqJyhyg45peTXb/pq4nRla+F4Cnk2tlCEZs4MS4zV+0tvITyo7ZYwD9kKAM0YsdQjChTgVJlLSu4kkw5JwMY5+lZOWqJZ5ZLjNDxxx2rNJEpdYzhu+aHRyC3YSeWVIj+zubMvqxPYAUXki82Bo2mdNwx0X+1aY47aaGTbcSOJFMbvxyOmORx9K8/JGcsmyf0I2/SssySXqmUzQwxxguDO+S7jIHXsKx9oTLT/AM5FUYUPM2Tn1JNbJ7LTYpzJK8xnmQxlhyzrjnoPStXsNtJ76yyyKSHyW4JHQ9K6UJt0n4ZwIWgE0CSsZ13AHBlbihmo2JugwXr8aLW8O0BRLKAWyTwck9TkitDuEMhIJ5wPiaorlMyLp2jnV3ZXHh/VfM9pihivlKndJtGRzz9fjTBps1lf3ET3bpccbA+dwC/T1P5Ul+ORqfiLVntY7NhHZMFARTyCMls4+gpj8A6Be2VpH7QFVS5KpjkDH69aY40k16N/q5tqRW8DaZe6dq+q3eoRkSmUhXdMbyxJLDtzx0GO3an2G7nmbZEmT3PYfOmaxsYI7IQXKJKMZYOuefSqjafaxRTi0DIYm95CSQfvp7UkrJ1mik4pFIDaAPQdfWvKhOa8qYwoTP1xQDWteGlFTFl7j7SgHAUepow2+WQRxjLtwBQ2+8Ji5uJJpbuQSMcgRqPd49T1ooJX0qxxV0zDRrkeMLC5l1OzjWOB/L3o5958Z47jAI79xQtfAcc858qabys9wPzo9oNi3h6xurKSVpIppvORiuCMqFI/+ufrV+1v9p29KoT6UpNIUI/C38I1ItJcTSkcxAHYoXtkDqeO/wB1HLSyZidiMWPpW26vZLzUZU9iuo4oQFWaSBgknrg/OiFpOIQM0LjcrZ21R4Zfwe4j8mczFNpO9Bg8YODyPWt4gbGWuJD8AE/8a2/xFCojV18x8hAe5xXkT3L8b41+cZ/8qRlSUuEk7b6RU904lcEDg7EP6UKhv3s7W2htpix2FpBsUhT/ALRx1yaOCOQ9ZgCP9qY/M1hNbszLmViB72dq8H7qROEn4wE0UtSMky2sxuJIpAxG9lUeXkYJ4odbXU8c0UKSf+kRftEAZHPvZx64++j/ALMJtyvJI4HUFEI9f9tZezxZAc79vTcBx9wrP5y32s5yVUao1fr5zj5KP7VV1BDG8CLncWZvuH70Tc7jnLDHoaoarqVrpV3Zvev5aSbk3kZA6dfh0z86oiugX02eGdjWUF5Ju3yRnIAxjk/2op7Lb+1i5UbQB9gDgntSb4Zv3vNKDIrqInZAx53AnOfhjJH0NH4WkMCqjBn+1gtgn1/SnpoXK7GF23RswySFOMfKhVrLK17cGT3ld9vyG2tHt81tZSybfMYKcKOtV4dds21aGCKfzd8aEvCQyA46fh+NMbQEYvpnkjg9e9StlzsNxIYzlSxIOKlSNdDT4DdKlX2w7sZKHbVs3ShjnFA54praUB+COQw70I1zVJIgI43AlIyT6CixvtHowinxjncSQXMW2QjpwaC6LZwWbP0OHO0E8AZpJt7O8uQZZ1fyJOC7NggZ+1z/APhq9pN7chsxyJJaBQUG7J29Mg9/Uj9qe7s1SjF62dPtnQjtS54pgeylS5tpSIpvdaPAwrDnI+Y/KsrDUGCjg1V8WXUri3hkjZFALgn+o9P8+dDldY2wNWpA/SJ5X1e3YtvfLY38j7JpvDXK8t5Kj/lP96RdEkI1e3IGeW4zj+k03m5mC4SKEH/imI/Jahxg5l0Io8zDIkiB+MZ/vWfmXAPEsWf+iT/3ULM1yQMiBfUhif7Vi085wRPEB/0z+pptidQpJ5rDLXLrx/TGo/MGquXD49plfHrsB/BaqSXF1Gm7zkIPpH+9VVvZHYBpyOegjH9jXXZmocRCcFppfv8A7Un/AOpchmurSIE4SB3/APkR/wCIpnWC5hK+dcXC98NsH/bQTxfaC7uQxby29kcBmI2jGTj9+1EkdBpTs0aBF5WlW8Q52xrnPfjNH4LWTeEUYK988dCf0qnY2TxWUoUBxGVTcO4A/ejenxu13MSjdFBGP+H96bFCpyLMNokto0M5JycMN3HxpG0rS/YdYl99iLZ2VQe4U8Z+lP8AAkiq5Kke/wB/lS3c27Q+IbwFlIkXzMd14/w/Wiyrh3x5daPZby4Dlfc446V5Wlo8mpU9HBDUo1ktWz1XkVzXxIRa62k0ykxEKycZBI6j/PWuhXdzmJkB5bilDW7+z1O1bTIIfPmD743HGCOu0/Icnpj1qiX+zhc5KCtgW51s3FvcW1vcYknURqrBiGY8Ek49P0FTR5724kXT0ISUsqSSJITwPtccccVRisHXUQjW+9gN6Ae4owepbPQccnFGbOa5tL2SHZFGqsMJjLO7cjB+OT8PSmP8JNsaaoe9I02ONI2eVpHTuw6mqPjmKZIbeZl3QLuG8dQTjgj6Vho2uO16LSSPP/Gvb5j/ADrVzxjqEEfhm+M/IMYCjuWyMY+tBJRnBpFOzckyhaaPZWurLEt5I1wo3bCoAOQR1+XP0poj0CcjeVcA8+82M/nVPR7W0aW11e6ik81ol3HtnHHy4PPbmms3yPGHB934d6VDDFRt+kk8s7pC7eadJbIpMCMu7BPmElfw/wAzQ6S3lKKrJAF9FJOfwFMmqZNpKO5Kkn6igU92QmfKHT/ef7UM4KMuG45NoG3fnMNrPwOMKuP1rPTfLtY2uIwouAwBaQkYQ9dpx9r/AD1oNrOqzrLAYYyFjnHmqMHzExngkVW8G2erT39zd3+IbG4LGOGWXdk7hjHoMZGayK/Bzj/56zVoHgrxDb627aVeXMdrchvap5CAVYcqTnO4kk9B0zzzXTdS8K6dqhDXUcm4RtGrRyMuFYDPGSO1BY/PtIgiWRcZ6xyrx055x3zVmK/kT3XtLnHTqCPzp8e+ony5JSdrhau9Fi0rS7gw3D4xkh8A9u4xQu01e2jSe4fUlRGnMJgKjdvGcgFSc5xkdPWjIkae2kie3FrbMhDzSSAbfp0/GkfxDoWo2+otNoetJZTTBfOLR+asw/pODkDHwFFJUBjd+hq01eFbdYnut7TSARRJneq9t3pz9a0XtzGkcd213bjUjBufYd6qn+4rnOOR39PhQKbS/GA1CO707xJCsjInnSTWysS+OWVSpC8AcDHSr38K8UR3dxENWtnsJJI8ieNGIjYEzDmM9T0HbNBxr0dul4hgMunQhY7nULdplGHKTIgz/wArHI+XavaTtR03xnbGGGybSbpVRg8tzDGXJ3tgZ284XaM9zmpXUv0zaH4yeKrqW20O5kiYhjtTd6AkA/hkfWk+xv5mAWMESshQtGBkqcZyD92eOM06awY5dJuYp4neOQBCV42tkEHPYgigVnpdrc2E0lm0cVopEWHLq07Ku9mJXB2gY78k4+I6DSVspyTilTVghGl9sa6S+kBXCLHGitjHwz0GKuyJFqdzHeX810Z44xGiw+4CikkEkZPO4nOaN634Vs/4fZS2QazaZxvQ7izgLkk7j2Jxn07dKXtEITV7iyllOIyzKFcEMwYLnPpySKNPbpHt3wa7e6t4LUNZRCSVhlo1OXJx3J60Da9vNd0++mlhcXtrMosoE5Cv3LZPvYGeowOOucUP828l1a6g0GC4ljZ1CsoG1WHUk5wOeeeKedG0PTdORb/UUN3q4GJJvOO0Z7AcZPxOT8uKxLnB6z1yRV/00stYmv7vUNS1W5eB3kimsp8nzfiQeF5PQfLpxT/YzB45I4I2h9lcxlCpw2OhHqMd/n3BrljXSWeuyReRNGty5PmhyqSv0GRu6+8eo9fWum2M2NPt7lV3s8KBycLnjr8etbFks5OTstXkiGB1OQzo20H1HIpdnsrufzWjtX8tVLB3wA3y/wA7V7O99e30cgEe3zOAze6oDgkZB/2qR8zV/Tbi48llmBj2O3UjnnGBg+h/TtQTWzsKLcBbg0a4u4DI3lQvKcQvM2E7YyRyCeRgjNFTbtYqlrOsTxB/LRreTeyjPu7lIB+7P61pvBJdWs7MipDLKGYurMv2SP6SMZ9T+le3kdvFcT3PtSgB4d6swG1uMdex4+vFBBpOhsrfplpeo6c52JrsBJ58u4G1x8MZzTDbyWeAzX8GPUPXH9ct9SRppZrWZo48s52+6oB6+lL9ndywtvijiYBv/cAbJ+Ro1On4Y8KkuM7zrU+gahp9xpt7dC6SUYeG2cs55z0XkdKXI7CFI1isDJb2dunloFfcyjPHJzn96I+DNTub7R1zpsUJI5LIIww+WOa9vrZtPlmlNymxwf8A06IN3IwCPUDijyLZCYPV6lG20mcyqItUvAwOSjbTn6Y/Kr0ljezXLyw6q6xmZSUMCMAoyCufj6/CqC3NrPqEFxI8sZh3DCgEdcHIPpx8vpW6zuootWuommgWGdshCfdz3wB9nJG7PPJqa0qTKEr6YT6dr7CPZq8O4Kd7NaD3juY568cED6VKxh1O9gMsUuoQKFkYRh2YnZnjkA5+dSs2Qf8ANhCe3hFmLSRE2ciZSM5JBJOPXPT0FLYhhttrWk5jWQjKPIyxsOhwFwd3GOuPrRrXdQ/hrKEkIeZWc+97ygDr8yM89sGlubTJnaNhMwhZFaONlHuAgGqMlJCEpPrLnieIS6cuy4m3hRESmV5IAVVz/wAoy2fWkFdOkt71R7HDIftK4BOB9a6MtlC1vvvL1d4XZ5jsNp5yeOnOOnPSqt14j0eSMWmj2f8AEZ2G3ewMaKRx6fL76Bx2+6Oja8Blvrt1Y238ldjjDJFwq8YyCB1yMjoa9s9ZutVeYbYAQTJ/L9wqfluPpjOaI29oRcIb19PWcplUw4dzwOAfQj9hRjRLAW0zS3ttHGp91WHuLuz0+yScg9fpWp3ywqS60CbKJrpjJJETECGYJyoPH5U43mnW72MJa7a2dQCqgAjjoAO/yofcaewk8/TZnRIXEgKHzM8fZB6kdD+HIPAbVbm/UmWR3LEnJcYz+mPgOeO1DKWi8Aq36FY5Ak0NsLrdGzBxuAXB3EE/M5A+lV9OItdWn0+/R5JWjMm4M7q0fwP+enOKC3utJqNtaw3ayQ+TcLJuiwpI5BXPofoePjR6O8a4v4ZtNkUF4289mfITA90457nt6fepT2fo/SkVIIZE0W5jF1FdRrMZFt2i2kopDBevLDGfQ9KsXFraasoaaO3VMATW7rzIQ2B1/wA6Vo1BbO0ivZCJBqGXmjEcx2s5xkKM4549OufXIqC6uLvUIWi3KRGUkXeME57jqe2K20nRj8DFzqEYmay4lSXPmRy/0468n5/2oppNjpEoiaCBYyoIWNhwAP1oVbxN7abxAssaDEizpnGB9pWx368fCjNhp8p1FJRDILZ0BBY4aNvQj8elPxp/Yl+B2JFjUAYUHsO9Cb/RRdzyTx3ssMrDaMgEcfrRV124Xd17moXTbzzg4welPoQm07Fi6g1KwtXkjh81V4bY2T15O5jnpzXtjo1vqVst4Jry2aYEYYrgHPYc5FMpZxkAlTjg/wBqWHudT0Qss0XtNsWJbhhtPqCAcUDjH7D3k0aJfBs8khPt8LkcEzWiFvr7pqVvi8WadIC7pdqxPKlhxwBjg/vXlD/HF+G7z/RgNnaFy5tYCxzktECTW6JI+cRRg+oUZqVKx+nMRv8AUK0inv47ifdKtrGAkDH+WchmJIHJzgDr0FEtI0iz8qGZEaIiPBWJtisOOoFe1KT8h1AbDwq+I7yXSd0dgEiCwiXIQElsEc5+Q+6pfapdzy2VrI6mB3TfHsGG/WpUqdtrwakmi1K38PnY2g8vchcgdyD+9Yabdy6lPd2t1hoU5C4+HqalSjtuIKXWCJtPt5bB52Q7lYKeeGB65peubiXSM3Fi3luijA7dqlSl5uTVB43wZbSBdU0y2e5Zg7RrIWTAO49f8+Ar1LeGHUbaFIxtkyj7uSQM96lSq4Jeil7Rbtb+4Guz2W4G2LQ/yyuftR889T07+tNsFvHaQx21uCsKjhSS2OPU1KlPiJyGxGO9t3vArjBrJ0UICBjDBR8ASalSjFHsDsy7c4GPQVrABTBUYY4IxxXtSuMKxsrUHiCP7qlSpXUaf//Z ">
                <h3 class="title">Bride 3</h3>           
            </div>
    
            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSJhbB_CfTXB-iQ3qCLYKyKRuFlmqtrNiQh7hfJirZtEpCrFbOVKUhzEWEow&s" alt="NO IMAGE FOUND">
                <h3 class="title">Bride4</h3> 
            </div>

            <div class="box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9hphvloZirZd1bGC9ACJxBTnC6dMLQCl88VK6VdSMU4WP7IYVCFkv4w86QhHvTHy0cMU&usqp=CAU " alt="NO IMAGE FOUND" alt="NO IMAGE FOUND">
                <h3 class="title">Bride 5</h3>
                 
            </div>

            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqXN-A3-h1kTY19e2cydOUsHZX19JNv4rcWgUgIns4mqViKWhuK1mN67OhQes6oPj1AYs&usqp=CAU " alt="NO IMAGE FOUND">
                <h3 class="title">Bride 6</h3>
            </div>   

            <div class="box">
                <img src="https://tse1.mm.bing.net/th?id=OIP.tCFXN8s-Z1v3KTiQdy5XBwHaLH&pid=Api&P=0&h=180" alt="NO IMAGE FOUND">
                <h3 class="title">Bride 7</h3>           
            </div>
    
            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOcrC6UuoFSUJJUQaL54V4g4j-WW67BeMXWYZroJsfMmxot4FFmmYLFUqi-L-mcNOLRLI&usqp=CAU">
                <h3 class="title">Bride 8</h3> 
            </div>
        
        </div>
    </section>

    <!------------------------cake-------------------->
    <section class="cake" id="cake">
        <div class="title">
            <h1><span>C</span>ake</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://i.pinimg.com/originals/3d/be/ac/3dbeac58db31facf1fbc49856e05c661.jpg">
                <h3 class="title">cake  1</h3>
                 
            </div>

            <div class="box">
                <img src="https://i2.wp.com/bakisto.pk/wp-content/uploads/2019/11/17.jpg?fit=3808%2C3920&ssl=1">
                <h3 class="title">cake  2</h3>
            </div>   

            <div class="box">
                <img src="https://wishnwed-blog-media.s3.ap-southeast-1.amazonaws.com/wordpress/uploads/2022/02/274001605_446928650117336_596745652998066457_n-768x960.jpg">
                <h3 class="title">cake  3</h3>           
            </div>
    
            <div class="box">
                <img src="https://i.pinimg.com/originals/69/72/e7/6972e7d077775f2d27dbfe02955cfdb6.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  4</h3> 
            </div>

            <div class="box">
                <img src="https://pic.cakesdecor.com/m/8f734ee569534ae9a10cd9288cf1151a.jpg">
                <h3 class="title">cake  5</h3>
                 
            </div>

            <div class="box">
                <img src="https://i.etsystatic.com/12896824/r/il/a41e95/1737304905/il_fullxfull.1737304905_1ufe.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  6</h3>
            </div>   

            <div class="box">
                <img src="https://i.pinimg.com/originals/e8/a1/dd/e8a1dd898d28eb3797a51641e8c684db.jpg" alt="NO IMAGE FOUND">
                <h3 class="title">cake  7</h3>           
            </div>
    
            <div class="box">
                <img src="https://i0.wp.com/bakisto.pk/wp-content/uploads/2020/01/IMG_6516-scaled.jpg?fit=2366%2C2560&ssl=1" alt="NO IMAGE FOUND">
                <h3 class="title">cake 8</h3> 
            </div>
        
        </div>
    </section>
    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src="https://www.thelist.com/img/gallery/how-much-does-it-cost-to-rent-the-perfect-wedding-venue/l-intro-1662922292.jpg" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Mumbai</h2>
                    <p>Hanging garden</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src="https://cdn.wedding-spot.com/images/venues/512/Carlton-Oaks-Golf-Course-Wedding-Santee-CA-03.1396585932.jpg" alt="img">
                <div class="venue-info">
                    <h2>Malavan</h2>
                    <p>Rock garden</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://cdn0.weddingwire.com/vendor/598840/3_2/640/jpg/wedding-knollwood-country-club-monica-linda-6_51_48895-1560971754.jpeg" alt="img">
                <div class="venue-info">
                    <h2>Goa</h2>
                    <p>Harmoal beach</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://cdn0.hitched.co.uk/vendor/6713/3_2/640/jpg/photo-2023-07-26-14-59-48_4_276713-169479673391002.jpeg" alt="img">
                <div class="venue-info">
                    <h2>Goa</h2>
                    <p>Flora and fauna restaurant</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSK2uF-QC0_SRhrkPtkfucZIZem2Sxi-Xvwmla0NQGtVc3MoNrixyemAqAeJvlWGBDnH7U&usqp=CAU" alt="img">
                <div class="venue-info">
                    <h2>Mahableshwar</h2>
                    <p>Sun shine park</p>
                </div>
            </div>
            <div class="venue-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRM6mM17l6frcXaXBsxpRqqGDDlgrVRw6cJYxC-9i3wKOKHoqQONZGE0U-UZwSnC4LDa3Y&usqp=CAU" alt="img">
                <div class="venue-info">
                    <h2>Pune</h2>
                    <p>Rui restaurant</p>
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhIVFhUVGBgVFRgYFRcXFRgXFxgXGBgXFxUYHSggGBolHRUXITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGi0lHSUtLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tL//AABEIANIA8AMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAECBAYDBwj/xAA9EAABAwIDBAgEBAUFAAMAAAABAAIRAyEEEjEFQVFhBhMiUnGBkdEyobHBkqLh8BQjQmLxFTRygrIkM0P/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQMEAgX/xAAmEQACAgICAgICAgMAAAAAAAAAAQIRAyESMQQiMkFRYRNxBUJS/9oADAMBAAIRAxEAPwD15IFNKcIAeE8JgnlACSSlJACTJJ5QAmhIhOCm3oGNCWVSTgIAg1sJyy9vPwU08IA5uCi4LtCYhAFVxC5OxDRvVTbFc0zJuDpw/wArMbQ2/Czyy1o24fEeRWauptADd6lQbtTkFhq+2yQrmwseX0y873H7D7Kf80jQ/DikbAbS/t+an/qLN8jy9lmv9SAMEp344Rr/AJTWWRN+KjTU8dTccoeJ3DT0lWgsRjcI43BIKPbA2p1jcj//ALG6/wBw7w+6pjy3pmbNg4q0GSFyqBdMyi8WVjMYvp2x72BgoCowkS46NnsjQhzLkHMNwK8t25sz+GtXs4GGta60azO8W4TzXsPS2vUpUnVKby0NHaIp5zx3m1hGhkuC8l2nsjF4x7XVqRbUcGgd+p2YDiwfDYakgAfLiTploJtUT6BbXpufVwr7U8QGtLicwa8GGS1xh0yRruEmNBexMfQwuPqUq7GVcI9zqT87MwGo62mXXbDhrM5fKK7NjvbRqOpH4azqLnAxBaGGQTBkmSI3ApP2Gar8Q2kC40QwQT2iIe55vrGU+iLVnXHR9OgJ0osokqhnJJ1CVIIAcAKrtao9lGo6mWhwYS0uktDoMZgNytKttOlnpPbIGYZZOgm0nkgAJsXbtJ9bI/FVHWMZqTKbCR/cO1u3xuRWs59ZrzhX5ew/qiRIc8WDjIPZmR/1KHu6PMbQBMy21M/C51So5rWufwEloDdQNTJgWan/AMbrXNc+q6mxjabS8yXOLsrSGwIlwuRxU1f2JWwZsfGYqq1rzUJDhEdWxoBDjN5ObSxsOSJvr1DAa+XamwtyPP2T7Ic402sDQ0NaGggRYCPJSMUGz2Q22vGJJJJgBLf5N6io+tK0VnVMQ1wJdI3gtE+sLObb6VV6eK6plVophrXE5A5wLtxEXi2nHyRR+0BWBZmqjeSDNMtGp4hs20j1QvpjsZx6iq1vZDcuYEZw4kmDJu2D5QZ1XNv6OfIilC6pkmbbxsNzVhLiLdWy4Pd7OiM7L2vVqav4bgPsq+wtpUm4YMrZC8FxYC3MGmJFxMXvYzdWKdJrP5jL03CZEWPDx1B8ENv6YvE4OLTVv6DOJxeUEXLg3Nbc3jG/QrPbY6SuZAY68jMBlORv90/1E7vHz60sc6o6q4shrqZYwHhlIAPiZ8ENoYJlOn/Mh5DR1YaIguBs93i2PRDm/o1Y8EYv2QQO0qpLDUl1F5NnNp3ADJjLzcb8lV27sqk1jnii57+sDWNa8jWddbWRHZez8wpySQwOgHmRAHLUK7tfG0qPV4fMRVf2haRF/iOgk2A1JSq1bJ5Zxh6x0+tf2Adn7Jw7G5sVQYHOMtZmqVIbvDmklp8Tx8kXwOy6Ac57GCHCwLQGyJ7QYLDdu3IS2uKpvYl199mga8Pib80eJLY8B9/1TVClFpduzN9Je00tJsbf44LI9Fq8YsUahJyjOCf6tI/fJazpIySQ0Fx5aeuiw+2pw5pV99MgOPImD84Up1yNkH6Uen16c3QrF4cghzTDhcEaq5s7HNqsa4HULtVZIXLX2iHWmXdibTFZl7Pb8Q+45IkSsRUqOoVBVbu1HEbwtfhMS2o1r2mWkStGOfJfsw5sXF2uidRio1cE0uz5RmjLmi8TMTwlEJumhVInmeB6KOGJxA7baXWMrXEZ3hznW3ZYc4a6ZZCrUdi1aW0qj4/l12moYBLcwIdf/sSNRYr080pMcj6fuVzOGBEx58lzR3yCIcnASAUl2TIqSZKwQBJM8TH/ACb/AOgkCoYiqGNzO0aQ5x1sCDpqUAdNrVA3qQ4gB1ZovvIDnNHq0LDYvZuIoVjiQZquqFzrSDm1ZxygQI3ZWncFZ6RUamJe1780S4MpwBkaYDieLtPC6IYHEV2NYajTXABFsoqEWtwc4ZQIJGpuoOVukaY4WlykrX97DNJnVMzQQ1xn/jO48p3rPbfw5e5vWDNSIEOb2i05g47xewC1uAr06tMOpnMwz5cWkbiNI3KB2XTmWjLxjQ+K7cbQ8WZRdvsyuA2e/K1rbtBJuwtc7hmJ5cFk+nm1H/xfVODgyi1rGy1zQ4ujO5oIGYSYm47Nl7BTpNboFV2rsihiWhlek14Gk6ibEtcLt8kcDjNleTR4yMbFJ2VxaSImTJkaTrEuGmkKm6m/C1AaVQkUnZgRJYZABIaTFw6DylX+ppHE1MrMrGvc1gkkNDSRqSe0Q3Xidy1+x9iU8VRfltUY6JPwuBGjt4+ep1tHCMqbT0P0U2+MRW6irRYBUBcwtBEOAlzXAk87205ha6psZhECW8YWW6NdFauHxTKj2gtGaCCCWy0i51IvH7vu12lrZaOWf5Mz0hx/8HTDKI/mOBhxEhoG8jTU23arzSqx+KxLKYc51So9suOutzygCbHcvW9udHqOKHbBDogPaYcOHI+ap9HOiFHCO6wFz6kRmduG/KN08brlxbf6OJXJ2wVtnBOwzuwPjLshOmhcB+UCVaweLz5gZlnZk77X+cjyWoxGHa8ZXtBHP7c1lcZUp0MS3DtdJc11QgntNPZyjwIzGTwSmq6NkcylGpdlTGsvp7n2WR6U4YPpvaN4O8cCVsNosJ3E/T0F3fRZjHUyQdw529G+6yS7N0DK9DekD6R6ktc9sSIElo4EcF6jgC+o0Oc3KOevovL9hP8A4bEOt/UfTcvUdnVnPaHETKotsWRUjltCgCChGzNr/wANUyOJNNxvxaeIWlxrZF1k9oYQTKVuMrRKlKNM3mHqhwBBkG4IXVqwOytrOw7oPaYdW/ccFtsDiRUbnabO046BaoTUkYcuJwZYyXny+f6fNIsty/dlObHwP0XHuzp94kT6BdkS7Ci9dAuRXQDlNCQKcIAeEzxp4t/9BRz9ogePrMfQqTjp4t+oQMrYnC5TnIMXItMSZvzUNjVjWcH9W9gbPxQJkDVo0ufyo6kAuOJX+VuNMSSSS6JCSTPmDGsW8VQDsQBowmHX0aTbLvmImUAecbS6J4vr6wo0i5rqr3NMgNh0kXJE2Mb+C9A6MbIOFo5HODnuOZ5GkwBA3wAPqu5diIdZmaexOkZv6oM/ClTOIk5gzLuj4tRzi4nhBG8G3KjQkggkqE4jgzUzzEsiL6xn9BpopYV1fs9Y1mrs2Umwjs5eN9fFdDLqSSSQxLG7b6P1HY1mIa6WuILhvGUZdN4y2/7FbJJJqxptO0ZXEUrfos3tGlr9/wBwtljqUOcOf1v91mNoMuVkyRo9DDKzz3bVLJUDx5+S2vRjbzHNbTmXndw8eCzvSPBksJG77rQdBMJTp0QWsaHH4jEuJ5uN0ol5tOJpMS+3FZzH1NVocY+QsxtKyc+yMCg8SVo+hlcw5p3aLOArQdFmwHHiQPT/ACusXyOPI+Jqq0nsibwT7fJKo2xPg70ywPy/NRpuU3OkxuGvj/j6rUeey2TYqJScE0LoQpvHmnC5udukfUpNeDYc54eqAOlNoExqdTvKd27xb/6CafFM46W3t+oQMJpEpJnCRHGy5AoUA97Osky+C0AxlYSLD+4t38Sh9ANdnfTPbc+KYabhrTllw4GHEzxG+EWw7oYGaPa2I4wIBHEKrWwjRSa1oAqhoDCPjDgLEkbp1myVFYyWwmXDj+xquLsU0Bpv2yA0Re4m4OlgTfghuK2Wc8tbIIEy7vPmoACbSI8iVB2z3kyWdq+d0iXZngui8/CIE6AnRPYlGP5CG08UWM7HxOIa3fc3JjfABPoodYS7K50BjW5o1c926143wNZCrYbZ7g8HIGiXuERYkgAwN+UADgZKu1m5Xh+oOvJ0QHX5W/ygHS0inWfmfUaWl7iB1QNoEQYzRlIcZJ1ghddl13uJDnAtYAyeLm2c6eZB+XFPjGEuaRGfMC0To0B0k+Mx5hVBsktNmy2GB9xmeBJOp7xBM2gQls6XFrYblKVnzsl+VjSMwGUWIs2XOcwSbknJflyhdhs2pmEgHR2bc12Zz3ADX4jrvAAsi2cuEf8AoNBydDcBs7q6jiJDQA1pJkloGnK5J8hzRJM5dfQI2n8Z8B+/ks5j2LQ7Vf8AzP8AqPus3tSvYrLl7NuBaQGxdIEEKz0PqwHUjqw2PFp0P28lXzZiuWCd1ddj9ATkdwh2nzj1KknTNElaaNPibLNbUWixjrLM7QdddSJRKm5aXo+IZ5n7LNLT7GEU2+f1K7w/In5D9Q42poOP0H7HzXUHTl99foFRD9Dz+StNfeP2VqMQQe6NYTFOfv8Av6LmXW8Lem8ro5JEqM2A5xbgE3BRYZOh4X9vfkgZ3aOSaPqPqE6Tt3i36hABNJJJcgRewHUA+IlJlMDQAeAhSSQMSi90bifBSSQIHf6mZI6mpZ2XTXW49PmFH/VTIHU1O1NyDAgkQbW09CONiaSYFDBYubCi5mpjLGkDw36zeDFrq+EkkDEkkkkAkkkkCAW0rvd4/QALN7TpStNtD43Dn9gg2OYsuRbN2GVJGfotgpVqUg/LxUqlio1XqLNN7CFfFgtQGs6SuznnRciEWc1RzLVpNn2Y3wWbJWkwfwt8B9FbD2Zs/QQDtP3uVmi+08/lH+EPYZVui64trZajIGn2+fsoFTOvooro5IhRpvknhNuHiPOUzrzz/duakEDOkp3bvFv1CiCpE/UfUJDCap4mrWD4YwFsC5IF57X9V7aCNTqriqYl1YO/ltaWwNbX7U3nSMu7egQ+Dq1cv81gDpPwxEWg3cea7dYe678vuueGqVMs1GdqTYEREmN/CF0znuH1b7pALrD3T+X3S6w9135fdLrD3T+X3Sznun1b7oAfOe6fl7pusPdd+X3S6w9x3q33S6w9x3q33QAusPdd+X3S6w9135fdLrD3HerfdLrD3HerfdAC6w9x35fdLrD3Hfl90usPcd6t90usPcd6t90ALrT3Hfl91Jjp3EeMfYps57p/L7qTTO4jxj7IGBdrNioeYB+32QnFb0e21T+F3iPuPoUDxbbKGRbNOJ6RmceYKrirZWMYLlUXWWZmxdHQvXJ7rJ4UEgGlaXDHst8B9Fm2LRYJ0sb4D6BXw9mbyOkWqQVqmVVaV2Y5ajGaEHl+4XNymTZRK6OSEJeiTimhAybSnnfzEeEqDSpk2HiPqkMLKpieuzHq8uXLAB3Ov2ieAtZW1FzjuE+cIEVcOaskvFo0EazuPCOPPkrBee6fUe6fM7u/NNmd3fn+iAFnPdPqPdLrD3D6j3SzO7vzSzO7vz/RIYs57p9R7pZz3T6j3SzO7vzSzO7vzTAWc90+o90s57p9R7pZnd35p8zu780hDZz3T6j3Sznun1HunzO7vzSzO7vzQMbOe6fUe6k0zqIUczu781NpO8QgAd0grtZRzO0zATwnQrN4zEWRrpn/ALV3JzP/AEFi8LXkZPRRymjAccU66qEq7WoGVx6lZmbE9HFwXFytVGKtUC5GRYUe2e/sA+Xpb7LOl6LbErSC3hf1/wAKuF+xDOvUMtXZhXBi7MK1mI0R4JiVM6Lk4rs4IFybMk4qMpMY7HWk+Km429PqFAO4qNZ2hPER6hcuVHcYuQfVLFU65fNN7Q2BYjeM0yYJgy30PFXVBxduA8yR9l0cHLDNqNbD3B5k3+G02EAcF0zO7o/F+iUu4N9T7JS/g38R9kAPmd3R+I+yUu4D8X6Jpdwb+I+yUu4N/EfZIBZnd0fiPslmd3R+I+yUu4N/EfZKXcG+p9kALM7uj8R9kszu6PxH2Sl3Bv4j7J5dwb6n2QA2Z3dH4j7JZnd0fiPsnl3BvqfZKXcG+p9kANmd3R+L9FNhO8R5z9lCXcG+p9lNs748rpgBemX+1d/yZ/6C89aYuvQOmn+1d/yZ9V5+wKUy+N6C+GxAqDTtDX3SqUUPwFXJUaTEHsnz/WEdqU1nmjTGQJfQVGvSR1zUNxjN6kyqYDrNhdcDiOrcHbtD4KddqqkWhOLphNWjY03LqwoVsStmp31b2fLd7Im1bou0edJUzU7lzyqVR8D0t4qJeqEjjVP74zvUZTVOesqbB6LiTo7irEBxQja+Oy5Yi72CeEuF4VraWMAEBZPGYkuqMGvbZrp8bfks0526N+LF62aml0uY3EdVVJAGcNdOZr5IIEATmEFojW+9dqO2evxDqTK2QtEBsWddwkEEz8Qtb4TwWV2t0UxIr0KhZmoms1r2NPbY01B2i+LgkzIAtrCJ9G9iOpY57qrwcnaa7LAe6oC2A4m+UA6DUnTfVSlqzC3F3SNW/BVj/wDtHhNrEeeovvjcrWFcctnh9z2p5m1huEDyWU2ttyoHVqTj2Q/zyg/D4aeUqz0c2rTptcKlRrW9kgkgDhrpPwpRzqUuJ08TjHkzT9rg31PslLuA9SpU6gcA5pBBuCDII4gjVSViZz7XL1Psl2v7fU+y6JIAh2uXqU0u4N9T7Loo5xOWRMTG+OKYiMu4N9T7Kvi8cKUdY5rcxgEkxPjFvNW3EDVZjpnhTXpgUntztmzjDbxv3Gy5k2loaTfRowXbsvqfZKpVLWlzhpoBv4BAOi+1Dm/g3NOeiwZnbjpoI+G9jyCntStVplwqjPRLg5rxAc2LljgNwiQ7hIOl1y1Y4q5JA7pFtKpUova+kWAPbBNiYJ3eWvMLKt/f78Ed21tJtRmUR8ViN4FkD+y4bs0TjxdURe2y0mFrZ6bXbyPmLH5rOlEtjPs5vAyPP9/NcSOosuVGqniadkQIXCs2yzsumZ+sxVHsRPFsuqFVq5KF3YT4c5vET6W+6OMKzGCq5ajTu0PgbLSNK2YnaMOaNSNM8knzn6wPv5KZKjVE8rz9fdRrPgAcVdujMlboideaau7K1TptQzbVeBAKhORrxwV0Z7bNZ0ktM8vZZCttosxFFjmOBdWpAkjsgdY2bo9i8SZuh9dofkBAJFRhB8HtWZNWelXqb3bnSptN9VjgYbEHUOJExbSx+SHUHVnZZYQyc8l0wLkN45v6Z9Sd+g/gKNVrXOptNg0iGucI0aXb4JPqrAw7KTC0NsRFzIiPkFpqzIpwgqUdmUoYR1Z05g0uLYz2mWjU6hwJI5oGKpxRNKiyWf1O0BIOsjQWBWkrUXPcC0zDgBus2Sfm4eit4bZ9LD08lMQ2czuJvJvv4eClwinyOMsXNqN6LPR7ZpwrCesIBHwycviGkxPNGNl7YbVcaZIzgT4gfQrPbX2qHtikZ+3jwhB+jmJ/+TnbJFJrnOI32yxykkBX5caSOF4y4N/Z6aoPrNBguAJ0BIk+S8x23t3EVO2RDDDbAljb3DheZ4kDghWG2jDzAzOPwOdGfgAO60AGAPuh5CsP8fJq3I9hfiWiZcLCT5XWHrbec6u6sw5WMkEm40v6fUhPsDaIrTSzlwc0iZlw0BBJ3iefjeAMwz3YbGNpERRBJpvLJFQlriGOcbB82ERcaLtZNMyZcEoTo0u0Me8vJDgG/wBxygQPhG/NyCE4LHl729USXSA9jnSDMmwP9MNJkzqOKsjBmtJdTqNvLXNcAeElhN9SJiYOqI4PBNoAHK0d4iBbfzOmpJKnt7NtxguNbO78OWtLqTuqktzWBIa10kCdN9tLobitv5cS6k+A1kOE6HMJkTyJ+aJ4mq51PsNkR68fFCn7FGJpUjiczS94psyuLSaMF0PP92Uu4jMBrK6e9Iyz9VydN9A3beApg9fRgU6gzFoADQ4nKC2NGnI4+KEFazpK0Gg54ENNRlOmN2SkHiw4Zi+OULKuK5kqJwdoaVY2bUy1BzsqxKYPgg8LrllYs04auVVtl1Y6YKVRqgyyYGxdNDKwR3EsQmvTUyoOWjwNbOxrt8X8RZZ+o1EdiVdW/wDYfQ/ZWwvdEc8bVm/eQIJMDdznRVqr5eOEGPVdW4ck54JOgJfI8hFtFyxDf5gi8D6/4WvJ8TJi+R0L4CzO28Te8rR1dEB2kzks0zZiqzK4muDPPeqFXFNYWucYAcwk8AHCbb9EV2ps5rmuDey7dwJ5rH7QLnEUzaDLhzFo+qkuzcmqPWqHTrBEmazS3iKdT6ZVZZ0qwuI/k0KzXPNoyVJtc2LeC8ow2F0a0STYACSZ0C9F6J9HW4RjqjwOuqAZv7WjRg+5324BWU2ZMmKEN/YQZS6pvE7/ABP2QvHY+LF1/r4KxtfFnTQaz9jyWPx2JLnSdBoOClJ2y2ON7Z0xj7kgkTYwYkIx0W2vg6LADiaOZ5a54ztlsTDT4SJ5krDbbxD3NLKdp+I8uAWYw1R1KpLrjfbTmu8egyb0e2bRbhnS6jiGNtEh4LY4Eb2kagrK1MCTLmvYYbDS0NJdY6QY5F3132+j1Vr2jgiLdmZAQw7y4DkbmF3dvYfyTxxpbLGwsjS3M8NAaW3IGre0SRq4kA8vpoMJtCiSC+o2dLneP6hHFZFrV2au1oxZMrm7YTZtkBxyZsl4kEOHIq4zadNwJqOncGnTxjfwQMOT3RQ3m/Rf2vtxzqb2MdBLCGlrZ4CJns2m94RLE47D1msjq2udTAPWQQyYmRoXtAgczyWdhRLF0Qn7s649nVuLG1GVKRDchDhLSJ7OUkloueWm9UnELs5q5uauWEVxVHEu/f6JinM7vqoEJHaNJsx802nkFbcEM2C/sRwlEyVBlkU67UMxDEXqhUMS1TZWIErBNg62V7TwN/OxXXEtuqm9OLphJWj1TcBuAgKo10uJ5/RWqrlTorblfSMOFds6vVDFNCuPcqGMqWUJPRogtgHG1miZI8DH3QbEYOhiHANaOtOmT4vMCxCLt2ScQ/LEtHxE2b58fBarA4Gnh2BrGhscABPoppNmt5IwVdsC9GejQw/8yqQ6ru4MHLi7n6cSTxmIgLrWxCAbXxoAIXUnS0RinJ2wdtTFa3WYxtdzjkpiXH5c1fq1M5XShRDfhGuvE+JShC9nc8nHQCfgqrBDmzzbce/qquzMGHuLXjfvstgwLjitnF5D2mH6X0I3Tw8VXj+CcM+/YrbP2VVw7XZO2wEEDe0H7fRXDXrOIAa5u6dI80qOFrEjMWgDeCSfKyIOCUYX2d5fJUdR2M0G2+BrvPM811aoBdQq0YGxwFIJKQTAQCWRTCmGoEVixRLFbyqLmIHZRdTXJzFfdTXF9NKhpljYNp8UYJQjZIuUWIUJLZdHOoFSrhXHlVqwUmViBsWxDagRnFNQqsxI7PTKunkq9PROktuTs8/D0yNZC8Vp5pklCfRqxhTZ4imI4fdLEH7fVJJH+on8mD8Seysntg3KSSnI0Ywdht/irjEkleHRny/JlhissCdJURBnVqg4J0kzkSkEkkCHap/v5J0kAS3LqxOkmA4UamnmkkgB6gsFwKSSQyWzviKLlMkoS7Lo5lV6qSSjItEG4lCq6SSR2f/Z " alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhMTExMWFRUWGRcVGRgXFRoZFxgWGBcYGxgYGCAaHSggGRsmGxgVITEhJSkrLi4uGB8zODMuOCgtLisBCgoKDg0OGxAQGy8mICYtLS8tNS8vLS0tLS0tLS0rLS0tLS0tLS01LS0tLS0tLS0tLS8tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAgQBAwUGBwj/xABAEAABAwMCBAQDBgMGBQUAAAABAAIRAxIhBDEFQVFhBhMicRSBkSMyQlJioQexwTNyktHw8SRDU4LCNGNzouH/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAiEQEBAAICAwACAwEAAAAAAAAAAQIRAyESMUEEEyJRYUL/2gAMAwEAAhEDEQA/APuKIiAiIgIsBZQEREBFwvFPiUaAMqVKNWpScYc+kA7yzyvBIhp/N1xzE8jVfxN0LWgtNSoTHpFMtI7EvgfQlS2RNx7RF4Gh/FPTk+ujVaOotd8zkL03B/FGk1MClWaXH8DpY/5B0E/KUmUpLKp+HvFjdTWq6d7PKq0yYaXXXtG5BgZHTpnrHe1lfy6b6kTY1zo62gmP2XynxjQdQ1z6rXWOa4PBjJDvVI9iXD5L6FwLizNfpiRgkGm8A7EiDHYjI/8AxZxy+M4ZfK8/S/iC4uDTpYJ/96cwT/0163g/EBXpNqAWzIImYIJG+F5rwjwc03VatQfaXGkMYAaYcR2cefQd16NpbRY8tZgXPLWxJMSYkgSYWOPz95V6M/H1jFrz23Fk+oAOI/SSQD9QVxPFfiCrpGNfT0xrNyXvNQU2UwPzGHOk/wB2OpHPZwkeb/xTmxUqNAHOylJLGD3m4nmT0AA6gK6TLc25WPnOu/i42mJ+FBzGK/aT/wAr3+ipcO/jV51Xyxo2tAE3u1JiARccUTgAz8usA+H8f8CcziWopU2ENc4VKYHSo2429BfeI5W9AoaPhvw7YbBccvPcHYfpHzkknkIxLduHllPb7L4e8dt1er+GbRtFjn3l+fTGLbB16r2K+W/wc4G+6trXggOBp05/EJBe4fplrWg84cvqD3Lq6cdtm6Fy1PrQsO6kwFROvYcU2Oq92j0/V0A+4kI2uiupNrKj8U8b6d0fpc1x+mFKhqKdQw0lrxu1wh30O/uMIOi16kqLXkGCrVN6DYixKIMoiICIiDAWVgLKAi5Gv8SaaiSHVAXCfS31GRyxgfMrzep8euLop0gGg5JMu+ggD6lcc/yOPD3XTHizy9R7pzQQQRIOCDsQvC+Iv4Y6auS+g46d5zDRdSn+7Pp/7YHZbNP43M5DHdstI/c/yXpeGcapVoANrj+E7n26/wA1Mefj5Otpnw5T3HxHxD4M1uiMuYa1P89MFwj9QHqbHcR3XBZrmg4dkEH2I/1zX6L4px6hQw90u/KMke/ReY4j4ko1WEjQ+e0ktk0w9pdAwTaRORhMpjPrlOHK9x5HgVZ3FX06NV4uYw3VAM+SIif1Bzsdn9l9D8P+G6WieX06lQ3NtcHFtro2MBoyM8+ZVDgPFvt/h3aRmklpe1rWhsnE7AA4nlyXpXvwVcde2v169p+cC5bYXG4a8lzzyED55n+i6j3wCtyt2M0QA0RgAADsOQC2AKgK4BgnAMD+pVqm6dgVZUseY8U+DRqKw1FJwZUcAypcXQWDYtibTsCBE/LPL4f/AA7PmfbvY6lMuDbi5/YyMDvJO697WqQMrN6dMeEt2q8U4tR0jGhwgfdYxgEwOgwAAuNwvxDV1VR4FMU6bNyTLnEzAHIdef7rzfj3Uf8AEkfla3nzIyP5Y7rreHNI46MQRdVJLnEwIc63frYMd1xnJcs9fG9ajsVa5qtD3ZpyAxuftHSBc6MkScD5nbFtusqW+mg4coJaM/5d1ivqqLGimXhpADRnILvS0joc/utFCqw1WNhznG43FwgWgXECOtvQSfdd9ssv1FV276TWgz6CXOIEnlPJpW3T6cVWet97gQQ8C0gloILYOMEH5qkzjNBtO+wbPiIJsaHObM5Esh0frW88VqEOIpGJhhALri19RrhyiQxsHb1gqi7p7yCypFw2dj1gfigbHYHl9YG2g/kuPTo6l1Wk5wgmLjOAB5jnM9O4nyhmJt3PPrOPqkc/9v6ILdywtcogsoiICIiDAQicIFxOPeLdHozbXqgPObGgvfHIkNBtB7wpbJ7WS308p4r8PO05vpC+idmn1GmSdgSCQ3oQe3SfOVDSAz9m/vcWx3ESPcT7L6ZwbxJo+INeyk++B6mOa5rgDzhwEjuNsLzHiXwzWpkuZdUo9Bl7McwG5bPT59V838jgs/lh3Hr4uX/nL2q+CtEyrUc+oLhTAc3Mtc6cGN8RsQOXRe5aaNwBLLuWRM9Y3lVNHoaemp02sGMF7tyZET7T/IKxxvRjUaeqyAXFjreofBtI6EGF6+Hj/Xx+u3Hkz88/8bNZwmlUbD6bT7gSD1Co8O1NGnVfpqdLyiB5ht+677ocexEs33DgvD6PxfV4dDKpNalLTDifMYx33rXHLrfV6XDlAI5dbwzx/wCI1WorXD4Z3oa5xDQC0i2J5Fu5JGf2Y82OWrPa5cWWO9+ntqtFri0uaCWG5pO7TEYPLBIWnV0sGNjv2PVWmhKjZGMFdrHLbl8JZ6X9byfbAx/NbdZqwwNJ5kAAbkk4AWSLHE5E7jl7hUeMcPNYBzdxsciN+Y5ZXDkyyxwvjO3TCS5dtmhrUnvkG8xcByaCTB9zB3XZYZXn+GUX7vbb6roOTtGIMD5yce0dqhupw55ZY7sTOSXUWrQd1oc8A25c7eBvHfkPmtwcjWxMYnJIAmevuvQ5vG8V8JU3PfqNSarhcXlrCC0AnGBDiAMc56BXtKaTgxtIjyqbAQ0+m6bmkNAECLOky4iRK9DcGWth77jBP3owZJ5BuOXVcfifhilVAbLmtBLg1pES4QRkHGB7ZWZjq9I4tTTCk+6tqKQcCHH1XOJtYMicGWmMY5b4w/iumdUYKZc6oSQ2Bg3giPWQIl0/Lly6XB+Aads06lNrqjPzSQ5p2cATEGOnL3XZ+DFO3yWNYJ9QaA2RB6CN4+UrehzdO+raBS0zWiGgOeST6Ww0ubDYwAJlaW0eI1d6tKiNiG+oj9j3G4W+qGio2nUqkvtJtgkPa4BpmdpLXmOV316umoWDLieZmAJjJHSTlNyrZZ7eb1vh1xsFbU1apc9rbZgQT6iAS7YZx0Xd0ujbSDabJtaMSZOSSc+5KxQd5tTzf+WyQzu44c72iW/MqzTEmVUbIRbLUQbUREBERBgL4h494C/Tamo97Xuo1DeKuXEE7tc7qI58gF9vCELnycczmm+PPwu35+8Pi2u0adzwTAk82H72wGJAx2X2RmqrUaclrbABLnvLSOWGhpLiTGMLXxLi9AVMUhUqMwHQLRnad8HsqGt4sK7fLrtsbIIcwza4cyDuMlcsMPC+15OaZfHdq0S5vKehXJ4jwDU1QY11SiDENp02BojfMF+f7yt/E1aTQarC4NH9oz1BzRzIGRjKVNRVqOJY4MpAA3W3VH3AGRPpa0A8wSTO0Z73uMY5f08P4j8JQ2mxzn1qlWo4XHb7pe9xjnDXHAyV5rh/DqpJbR07ngEiA9wcADBDjsNhyEr7CdO53UwCb3wAAdwIA6bqvwrhQp32lx8xxe4mASSANgBDejcx81x/RJdx0y5LljquX4Mr60Ne3UBrGU2ttDwQ+DMeubTEHl0yF6PTcQbUNrPURvbBA93A2/uvL63gFXWhxq1TSoXGykzdzGkgOeeZdF0GQJGF42p4Gr0qj30a0vblpItEDIGBPKJkjsr55T1Olx48dd5dvp1XUueXgtAa11rSHTcIEu2EZkfJdDSs9OV4n+HPEqlejWZWM1qNZzH4A/CyMAkRuMYwSML3dEYW8e+2LNdKmrqiiC95AYIknESYydhvuVl2rDd2u+iuuWmswEEuE/zVvSRGhVkSea2eYYMCew59s4WunT7qbhAmcBTya8XNr+JKVJ1tRlYOmABTvkxMAsJExmJmFp4b4oGqe5lKlUECQ57YBgiRvH7q1W0ArVWPkENLHRsb2XFrpGdyBGxC0+JRZT1ESC6m57SCR6hAcDG7TLTB/Upu2OeUsrczV0dS4sDvtGSQ9nLraeY2kHB+S3l1dmCxtUdWkNd8w7H0K89pNSyjpmahtKGVYuLKhYGuJth2C4MuwCCd9ld4ZxDUeZ5T6Bpthxuuc/bP3iSCtzJHQqPc4tJ0ri5uQXOp+k+9ym7Svqf2zgG/kYTB/vO3PsOiuMDo3WfKWla4mABDRsPbb5LfTYpNYpoMQiyiAiIgIiIPE+K/GFXT6gUaTWENDXOLpJM5gQcCOeV6/QaoVadOoAQHta8A7i4TC+ffxL4ORUbqACWvFr+jS0C042BE/Nvdej8P6p4oaWk14cXsGSA6wNYJBIIkziOU574lu6xjb5WNHEOC+VJElvXGPfGFxamm3BLs9yPl6YXa8Y6SoxrazHvNuHy4mJ2IH3RnGAFo8I8TqVXupPcHYuDoAeBIBGImeu4WLry0l1vTfwLQgUXurM9FIlwuJc42tB/Efujp1B6QfmLeI1RV+Ja+15e55cDu4ySO4zscL7dxEtDLTIu9ADYkziBOIhfL/FvhOoLW6d76lWcMLZEGcuIgU2DaZz0lXLK4/HT9fl9fSzqRUpsP52Nfj9QkLdRbv3XiPCXF6oFLTaim5lZjQwCPs3MZgljnQ57p3gQAW+59oa5HKVuZbass9s1aRgBsAbew7KtqdOGsJiYBJ6lVanEX+fTYTAcSIAnEHf8AZdeo3GE9np4PS6enwto1FRxA1FRvxLjkNqPabX4GGtcA2BgB5PJe309ZrmhzSHNIkEEEEHYgjcLzninhnxRpUSYph4fVPUNEtpjuSQSeQ9wo8FHkurYsoMspsYB6WtaJLwOWXRjkzsFiddN3vt6WvWDRP+iei13lwBjkY91Sr1i52dgY+fMqxXeQwAdmjtzJ/Y/ss3LbpOPUn90bDRL3RykuPPoFCo9lMXC4fKf5LlanUubTD/KDzcW/2loiN4zPc4V3R1g+nhpaIy08jMEe3+ax5fHovFZPK+t6+NrDEOBwcghdSvpA+A71D1Ag82uaQRj3VDgtIethy0EOAPKd4XYXbjnTy/kX+WnK13BWO0j9LTFrSwtaJJg7jJzuuT4H1b36epTqfeou8qTvAH3T7ZH0Xq1rqNADsb5Pdb13twZp7BTUaewUlQREQEREBERAREQeV1+vZU13wlYuayAWgPhlRxaPQ8AAkZOCSDge/WptDKtrAGtaA20AAAGIAA22JXkfGXh+u/W0qtOSyo6myWg/ZlsS50DAgSD1x0XvHaZpddGcT3jaVLElrw/8Q9VqWVG2Pc2kWfhMAuBN13XBbheD4ZxioK9KoGXPNRhAGJ9QhojYmTt1X3HX6JlZhY8SN+4PULgaLwXpdPe9oe57pDXOfDmziGEAWHMXD1CcFS47YuFtdttZj3vtIcWG0mNnRls7EicxtKVCG8suP1MR/ILgcQ4s9jXUKTqNN7RAbTIfYIy97nAMpNB3uBJ6SVb8Pvq1W+a+XASxtzbXug5qESGtB5MAwNySVN7rvrTm+NKUmiWtl1N4q4n0hglziRtLQ5kc7+yr8D8UOqamrpKjRLatVtJzCZsYSfWDsALfVOSQI6+kqv8AMqWta5zWEhwAhpdiAXHFo5gZONxIXxDxBezilZjX1KdZ2oBvY8tsD3Q0gx6gA8kSMz3Ka1duXJnZp9s4fw62o+o5wdMQI2jn7rqr55qPEmpoxD2PMtw6n+GcyWuHKV6jTayu6k15om0ifSYqAdbHbj2dJ6JjlL1F8trdVwFzjH+2J/10VZ2kNVkwReZIPJvX3jMd10NC2lUa17DeOuRBGCIOWkGQQcg7q6Ataa25nwwDSOpn/X7rTqGlzS2YdIg9COZ7EErrOp4hQ+HBGd9lzuDrjy6cCpw4PFoJ2hwhp9xJMgewzC62moYbgAxB77b94CsigVOlTjKY8ems+a5TSGm04ZPcreiLpJpwttu6KFbYqahW2KqM09gpKNPYKSAiIgIiICIiAiIgwFlYCyg1airaO5w0dXQYH7LzXE6NWrV8oFxcbfMqDNPTgiQ2mOdUiTeRLQ4GQCF6orXQoNYIaI5k8yepPM4GSpZtZdOLS8KUBYI+zY4ObT/A4gQHVZzVdOZdtAjnNzT07xaCRTBdc4SDUeSS+Pysunbc4EAerdxKoYaxpIdUdYCN2iCXu7ENBg9S1WqVMNAa0AAAAAbADYBJJC20YwAAAAAYAAgAdl8e/jFR8vW0NRu0sFP05cK1N5c1pA5uFRsD9P0+pcX1TxbSpR5tWQCchjBF9UjnbIgc3OaNpUtPwegxlNvltd5bvMa54DnebmasnPmGT6t8plNzTGWPlNPPeC/DjxTZX1jZrn1Bh2pD8IP5nxknkTA2k+wWl2qaDAMkcm+oj3jb5qJD37+gdj6z8xhvyn3CSSelk0q6ClGo1Dm/ccKc9DWF9597PJBP6exXSUabA0AAQByUlVERczU69/luq0w2xuRdM1Y5Mg4B2DjM9IgkOmiIgIiIChW2KmoVtigzT2Cko09gpICIiAiIgIiICIiDAWVgLKAiIgoVf/U0+1KrHzfSn/x+quVroNsXcrpj5wq+uoOJZUZl7CcbXNd95k8phpHdreUqtxDWNfTLGuLX1Ip2n0vbeYLoOcNudOxtQVOD6arVu1DqwBqwGllMD7JpNhF5dAdJf/3dlcfwe4y6tWd2c5pb/htt/ZdGm0AACABgAcgOSkg5lZtSg0Oa+9gIBY5rQQ0kCWFgABEzBBmIxuumuXqqxqguaJp05eOlV7ctA/QCAZG5AjEzh9asW03lhhzmF1NuHsbBOTPqN1oLRyJ3jIWuI1nNaAww97gxp6Tu7vDQ4xzha9Fp2tqOtmAA1xLiS5++Z3IEZ/VHJUOJV69R4ZSpFppllQOeMHeQDNv3ZESTLhIAEqy+rWbayjRwBcTUIyZy3DpDjk3QckYMkgLHFCSG0xg1XWE9GQXP9pa0tB5FwUI814A/sqZ5bOqNOGj9LCJP6gB+EhU9S91StQuDqLXMqNyRc5x8t1jS0m0w1+d4DojDl1ab2iKbAPTAhuzABiemIgf0Qb0REBERAUK2xU1CtsUGaewUlGnsFJAREQEREBERAREQYCysBZQEREBc7XBrq9BjgCLarxP522NAz+mo/wCnZdFa61BrxD2tcN4cARPzQaDqqbfSwXO/JTAJnvGG+7iAomi6oYqEBv8A02mZ/wDkP4h+nA3m5W2MDRAAAHICAtNKiRUc7FrtxM+oACdsYEESRgHGZDc1wxEdvZZDhMSJ6KnpNI5ppkkG1jmnsSWbYGPSd+yxR0jgae0Mc505l1wcM43N0kzuPoFy8byP9t0LxMSJ6c1Qfw2X3AgC6Yj8Jy9v/c8NJ9lYdRd5t4iLQDnOCe3fqEGytTY8Frg1wxLSAfaQVOmwNADQABsAICp09I4VnVMQSccwCymJ23lhEdCDyhXkBERAREQFCtsVNQrbFBmnsFJRp7BSQEREBERAREQEREGAsrAWUBERARQrVQwXOMDH1JgARuSSBHdQp6gEluQ4CYIyR1HI/wBMdUG0lYvHUfVV6mqpmj5pzTs8zY/di6Y32zCwWU7ywt9RbdmciYOecE/KR1QWbx1CzcOqqNfTdYYMVJtkHOLpPybOVNoph9gi6A6Ow9IPy2QWLh1CXDqFXrNp0xe4BoaBnkAJA+QBP1KwKdIOFOBJF1vZsCf3CCxeOo+qyCqzGUi4sAFzQCRGwN0f+WO/dKGppgim2RBLRgxLRJAPtn69EFpFXdrGgOdmGutOOcgY67hbmOkTBHvugkiIgKFbYqahW2KDNPYKSjT2CkgIiICIiAiIgIiIMBZWAsoCIiCvrdPe2AYIc146SxwcAexiPmoN07jUFR0AtY5jQCT98sLiSQPyNjHXri2iDlt0NT4U0DZPk+UCCSJstk+nA2VnX6Q1LYNpBgnqxwh7e2Mju1qtogr1qJLqREQwkn2sIEY7qsdE+4VJF4eSRPp8si23afuhro2uCvVX2tJxgE5MDHU8lyNFxGo8FxtaebZkNMC4SWgkAzmM3dlLdLJt09ZRvbbgi5pM7WhwJG2cCIVTSaB7HscXB1rXsJMzYS2wdzDBPck84VStxxwe5rWElrg2C1wulv4SARAcWycwOWQu6kuzTnU9E8PZUkXS+8Ti142bjJBbTieTT1SnoXCr5kj7zsEki1wGRj0vEfMGOkdFFUUKujcWVG4lz7hk7S3cxg4Oyt0GkCCAN9nF37nJWxEBERAUK2xU1CtsUGaewUlGnsFJAREQEREBERAREQYCysBZQERV9dQL2FoMd/b5EHMYIQWEXOdoXG6SDLmOzOC1wkDoCwNHyPUrFbhpILQQMkgxyNRrziIwGxHPsg6SLl0uHvH4o2yHEkjy2sIJPsXT1juttDROaQSQ4hsZJy5uGuON7SQT/kEF8hVq+hpvkObIcHNIzBDxDgR3/qepWivonl9zXCJa60kwS0Y/rPs3osUuHkFsuugukk5c0+qD3FTI6DHMoLTdFTEQxvpFoxs3GB0Hpb9At6ouoVLxmWlxJByLYOPeY5Hb66Rw10NyBApAxzLHhzuXMBB1EXP1Oie/zPUPW0tAMw0gEMcOm7p+XRbKmldeHNIAAiI2MO2xiSW/4e6C4i59TS1TdFSJMjJwPVB+Us9OxszuU1PDy4vcHQTbaZ2i0yeuWjEx9UHQRaNFRLGwTJucZ/vOJ/qt6AoVtipqFbYoM09gpKNPYKSAiIgIiICIiAiIgwFlYCygjUBIwYMjlOxEj5jHzWgUak/2nys7nv0IHyVlEFZlCoN6k/d/COW/1RlB9sGpJxm0DlG3vlWUQUxWsda6pJhpi33B+RIP0UBqDIHmA5A+4etMEe+T/iHRXi0JaEHPfqZ2qxz+4TguLh/9WOCk5xx9tvBHo5XEfzc0fJXS0dB9FFrgYP0QU31cEebBBdJs9/5Wu+hTzoiapwWg+iJzH7nCtioCYjmR2mJK2WjogpVKwwfNtBBIluME5z7tx2TT1C4iKtxyfuwCA4j9jA+XdXbR0QBBXbRqY+0nI/CMgTI+eFJ9J5IIfAkGLZxiR/PPdb0QV3sqZhw5xLexj+i3UwYyZMn6Tj9oUkQFCtsVNQrbFBmnsFJRp7BSQEREBERAREQEREGAsrW6qAsfEDv9EG1Fq+IHf6J8QO/0QbUWr4gd/onxA7/RBKo+0Tk7bCTkwtTtWAdnRAdNpjPLrPZT+IHf6J8QO/0QQrVwJBDvk0nlOFB1g5O9J6HnyHUY2HILd8QO/wBE+IHf6INFzB+fc7Bw5+y2+c0AYMZ5Hrzn3UviB3+ifEDv9EEH6to5OOAYDTOZ/wAit1N8iYI91D4gd/onxA7/AEQbUWr4gd/onxA7/RBtRaviB3+ifEDv9EG1QrbFR+IHf6KL6wIIyg209gpKNPZSQEREBERAREQEREGmqtaIgIiICIiAiIgIiICIiAiIgIiICIiAgREFlqyiICIiAiIg/9k= " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRB8v7x-G7kyLOu1iuWjmcSEjgMIQz41JcDEA&s " alt="">
            </div>
            <div class="invitation-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHSj0DzpHag7ksg_ezClVWlt07nYQIYNbQWA&s " alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1IK9OHLBivvgeRW-sUYvXf9Ssup3xZ8fwAw&s" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTe9kV-Wobb6QQMsT-2kiesyqhlxtWT8MzIqgzbsC2fIBMtCt8_NQEmV4LLtKVyRQOtNcg&usqp=CAU" alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9NaREzTy1zShJI9sb7XVk8PSBskDll1VUiiAZUxg1w3p_uquXHwFU_B_3zWpjp9BWuTw&usqp=CAU" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsNzmdQQLyEJM0L_WPKJCxw0A8PSPPIOR9TfvSw1QK-gn8WhTuy0oCzhPi2wFjPXyZQHs&usqp=CAU" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMJf7VbbIudLje_JzI2Rz5ugstKAendFHtwg&s " alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQArBrCS-D0y3R4ygs81JWtW8qhyQmbIRzQSA&s" alt="">
            </div>
             
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>