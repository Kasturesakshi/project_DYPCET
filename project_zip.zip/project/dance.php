<!DOCTYPE html<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dance</title>
    <link rel="stylesheet" href="all_event.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .home {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url("https://wallpaperaccess.com/full/1315627.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }
        /*-------------------decoration--------------*/
/*gallery section   like ch option nahi yet*/
.Decoration .box-container{
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(27rem,1fr));
    gap:1.5rem;
}
.Decoration .box-container .box{
    position: relative;
    border: 1rem solid #333;
    border-radius: .5rem;
    height: 30rem;
    cursor: pointer;
    overflow: hidden;
}
.Decoration .box-container .box img{
    height: 100%;
    width: 100%;
    object-fit: cover;
}

.Decoration .box-container .box:hover img{
    transform: scale(1.1);
    filter: grayscale();
}
.Decoration .box-container .box .title{
    position: absolute;
    top:-10rem;left:0;right:0;
    color: #fff;   
    background:#333;
    text-align: center;
    padding-bottom: 1rem;
    font-size: 2rem;
}
.Decoration .box-container .box:hover .title{
    top:0;
}
.Decoration .box-container .box .icons{
    position: absolute;
    bottom:0;left:0;right:0; 
    background:#333;
    padding-top: 1rem;
    text-align: center;
}
.Decoration .box-container .box:hover .icons{
    bottom: 0;
}
.Decoration .box-container .box .icons a{
    font-size: 2rem;
    margin: 5rem 1rem;
    color: #fff;
}
.Decoration .box-container .box .icons a:hover{
    color: var(--main-color);
}

    </style>
</head>

<body>
    <header class="head">
        <a href="#" class="logo"><i class="fas fa-heart"></i>MEMORY MAKERS<i class="fas fa-heart"></i></a>
        <nav class="navbar ">
            <a href="#" class="active">Home</a>
            <a href="#decoration">Decoration</a>
            <a href="#venue">Venue</a>
            <a href="#invite">E-invites</a>   
            <a href="book.php">Book</a>
        </nav>
        <div id="menu-bar"><i class="fas fa-bars"></i></div>
    </header>
    <!---------------------------Home--------------------->
    <section class="home" id="home">
        <form action="#">
            <div class="search-box">
                <h1> Dancers can fly without wings</h1>
                <p>Lets book the stage for all categorial dance </p>
            </div>
        </form>
    </section>

    <!------------------------Decoration-------------------->
    <section class="Decoration" id="Decoratio">
        <div class="title">
            <h1><span>D</span>ecoration</h1>
        </div>

        <div class="box-container">

            <div class="box">
                <img src="https://springofrhythm.com/wp-content/uploads/2021/09/kathak.jpg  ">
                <h3 class="title">For the kathak traditional dance</h3>
                 
            </div>

            <div class="box">
                <img src="  https://s3.ap-south-1.amazonaws.com/nsojbanglore/stories/blog_images/000/000/794/original/4168899077_6e6fe53577_o.jpg?1627567062 ">
                <h3 class="title">for the bharatnatyam</h3>
            </div>   

            <div class="box">
                <img src="https://www.indianeventhub.com/wp-content/uploads/2021/01/Home-Stage-Idea-Dance-Printed-Pillar.jpg  ">
                <h3 class="title">semi classical</h3>           
            </div>
    
            <div class="box">
                <img src=" https://t3.ftcdn.net/jpg/06/39/30/86/360_F_639308643_lRJqrmZq2iaOm1jDOSW72zqdUcyNpuzk.jpg " alt="NO IMAGE FOUND">
                <h3 class="title"> dance show</h3> 
            </div>

            <div class="box">
                <img src= "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJha9KCFeQf39vhCpLFGTWZSHEfhGiMzY9_85YsMTPRg&s " alt="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJha9KCFeQf39vhCpLFGTWZSHEfhGiMzY9_85YsMTPRg&s">
                <h3 class="title">disco dance</h3>
                 
            </div>

            <div class="box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3TTGvjkeLHcWDPglZ-_Dys-pzof5W54gZrmyoZ2Ecag&s  " alt="NO IMAGE FOUND">
                <h3 class="title">Bharatnatyam</h3>
            </div>   

            <div class="box">
                <img src=" https://feeds.abplive.com/onecms/images/uploaded-images/2024/02/08/d706d1a5aa33f190945df831db97ce57170741664629693_original.jpeg " alt="NO IMAGE FOUND">
                <h3 class="title">Maharashrian lavni</h3>           
            </div>
    
            <div class="box">
                <img src=" https://im.rediff.com/movies/2020/may/13madhuri5.jpg?w=670&h=900 " alt="NO IMAGE FOUND">
                <h3 class="title">kokani dance</h3> 
            </div>
        
        </div>
    </section>
    <!----------------------------venue Section-------------->
    <section class="venue" id="venue">
        <div class="title">
            <h1><span>V</span>enues</h1>
        </div>
        <div class="venue-list">
            <div class="venue-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIWFRUXGBgYFRgVGBgXGBgXFxYXFxcaGBobHSggGBolHRUXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0fHSUtLS0tLS0tLS0tLS0tLS4tLS0tLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAMFBgcCAQj/xABIEAABAgQCBgcEBwUHAwUAAAABAgMABBEhEjEFBkFRYXETIjKBkaGxUsHR8AcUQmJysuEjJIKS8TNDU2OiwtIVFnMXk6Sz0//EABkBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/EACURAAICAgICAgIDAQAAAAAAAAABAhESIQMxQVEiYQQTI3GBMv/aAAwDAQACEQMRAD8AxhqfUM6K55+MGMzqDtwnjl4wKWEnhDSpU7DA0YnEKNNhG+PHWUq7SfnnEEha0GxIg1jS5yWmvEWPwjUE9f0XtSe4/GAHGVINwRuPwMTjMyhfZVfcbGHS3vEawEVL6WWnPrcT2vHb3xLS08hzbfcbH9YEd0WhWXVPDLwiPf0etF6VG9PzURjFgUxuhIcIBChVO43H6d0AaudO84GmwFmhPWOGlPvHeaAV2kRKvtqSotuIU2sfZWKGm8bFDiKiAECd0cFXaN/YUfynbA6H1IOFQIpmDmIkks7o9mXAoAOJxDYclJ5H3GMYBW/XKPW9IjsuXG/aOe/nAc2xhIwKxJJ5EcxEa68TGAWN1j7SSFJO6Algg2iNlJ1TeRttBy/QwembSrhGowHMsbR3xefo6156CkrNKqwbIWaktEnI/wCXX+U3EVSvUWfunz6vviKQmA0pKmFSado+gdbdWm5xoJNAtPWZcF9xAJGYIA5im4UwTSEg4y4ptxJStJoR7xvBzBjQfo814DGGVm1fsDZtZNSyTsP+X+XlWCPpHm5R4lKVgzTeIDoxiqlNSQs9kmxsCTtG3FOGUXj4KSqSvyZ5Kgggk0312w6kp/EfKBU3MEoTFGIh3GTy4Q42mPEIiSltHLP2aDjb9YRsqkDtogltuJaV0Qkdok8BYfGJWXlkpySB6+MTbKpEHLaPWr7NBxtEkxokfaV3D4xJhOzbHqrEA1vCNjpDCJRAySO+8cTmUEkxDaVcJUACaQjHRon0aS1Jd0nNS78qUHoT3wZrDo/GhSSSE8CQcuF4b1PaLTQpTJINcjv76esSU/OIUDS4qpJzF02V51FeBgNqhVeRm+nppSihmwQ0lIAAI2UFb7hFx1SmCmVaub1CRStCFK4beMUbSLocdUoUAURT8IsD5V74vuqiP3Ru4zURapFyP0hPJZeiY6Y7QuvOkKGwzW9T5fCFDWwaPltEwRx5w+maTtBHnDQRDZTHoWea4USTZCsiD6xwuTSeEAhvjSHkTCxtxc7+t4wrTEuQVsvHrcy63tNNxuIdRpD2kkcvgYJbfQrIjlkYIBM6VSaYgUneLiDGngq6SFcs4Dek0nZ4QC5KKSapPuMAJbtXtOKk3S4htteIALDicwPZIuk3zvyi9S2smjp5HRPJDKj9h+7dfuOjsm+ZwndGMo0g4myutzz8YJTOIIzoTsN4VxsZSo0zTWoC0daXWSDcIcNbfcc28lV/EIp822ttWB5tSFblChI3jYRxFRxgTQ2tU3J2ZdPR7Wl9do/wns800MXaS19kZtIanWgyo3qQXGia0BrTE2a7b03wPkvs3xf0UCZb2i8RDzQArxA9fhGo6Y1AStHSyjoUlQ6pCsaT+FYrXkaneoRnmmNGPMdR1BG0GmYFRyIvmLQ0ZJgcWiJj0CFWETDijqHiAU1qDmO8H3Rz0h2W5RylJJoBU8INY0U4cxhHH4RjAiYfaB2d1IlGNEpHaJV5CJBllKeyAOWcK2ZIj2pFS+tSh+1W3ePf+tpCW0Yn7RJ5WEdJmgDUXPzv2Q4t40qmw8aH4bom2VSD5dlKeykD53wYlQFK90Rkq4VChgti4Ke8c/1ibLIMQ9uEO4zv8IFZTBIEIx0CMWmkHeCPIxNTXbb5+hiGds80fvAeJpE1Mjro4BUKONiIttvHMhP3gPC8FTSCVJAWQCCTQ0yp8YZ0DQPdIrspNSd2I0r5k90AJprS+iYxC5pYb1HqoHf1R3xCayO9EyGgaqPUrwzcV3371RNtvocwrbUFNNBTiiPuJ6opmb3/AIYoum9Jh1youmlEk231NOJ9IV7MiIfuTSNN1UtKNUFbHd7Rz3xmKz1rb40/VhQEs1tsfzmDQU7JttaqCqR5Qo8SrhXvEeQQaPlFsR4RDobNgLwgnZxjss5qGiDHuDbvh9xGd7cMu6PAqoNfmkCwpHCBwrWD9XptDD4ccbLgAIolQFMVq3BBtUU21gdhFbUGUeITfzrT5rGs2KLymZ0VMCmIy6z7SS15jE13kCOJrUpak42HUOo2HZ/OgqSfKKOpNTb0vHTEw42cTa1IV7SFFJ8UwEK4IN0roN5sEraUkb6Yk/zJqnziDUigi2SevU232yh4W/tE9am3rpoo95MPP6waPmAenlVNrzqihBPFScJ8QqHTZKUUilhREeqXXOO3SipwggVOGudK2rxpHqGK/aFPPwhxAzQunZiVViYdU3XMC6VfiSbK7xBOndY5idWkuYaprgDaAKVArQjrXptMcyMmzXrkq4Gw+PnE2NJMtJohPchMLrsNkGxohxdMacH3jY96dvlBjWg209olf+keV/OPV6fCjlh/F82hiaUV3xqTyNvARgEmyhCbJAHL3x05WlUjEd23uG3kIG1V0S9MP9ClaUmhViJzpsCbFRvkOJvSJPS2jnZZRS+gpFaJcF0K3XGR4Gh4QL3Q1ashjMqru4QUhQUK5GGZsg3OexQ9++GEukfEZfpAZkSK2cVx2vJXwPrEvqhogTMwGVKCAUqKhUAqp9lNc1bcskk7IhpZ8KtkfWCwsghQJSpJBSoGhBGVxkeMIysSQ0/oNyTewquk3SoZLT7iN0ctHJQi4aO1jl5+WUxOqSh1CSrGaJCsI7aSaBKxtTkRWlqgUcKDThRjStNeqtJqlV6VB3HyiV+ytEiVXrv9dsdhyBFHPy5xwkq3eMBsdIcnF9k7lA+cTWkVgYTz90V2ZQSkxKTL3SBNNgqe8CEHoFmpi9dyT5kfCCdHj93UkZqqo/hQKDz9YAm2iBlBmjFr6NdAKEYDXMCil2/k27xAfRl2XXVVATIuKJIHRqGVf7RLo/4xS1o5Ze8xpOrDeHRjpp2m3CNxCWyPWsZw57vTKClpCOW2NHfGmaqO/urW+iq22Yj42EZqBXwr/WNP1OH7qjaOtTh1jau7b3mGaMmG9PSwJPG1+MKCPqfGmfGFGxGyPl4J3Xhst3rF1ltQ5hZ/Zqad4Nrqdv2c9h8DCmdRZxGbC+dI6Dmspym+FO6GsEWOa0C8nNldtySfQQA5KEZgg8YF0Mtka2LwSqu0f0h5MsTlHXQUhWx6YJgHdTbDCm4lEy9fmsJxjdnAyDRCrRDbDQKqEmlDwiWel7HlAsowOkSBXsmtaZ1VlwpTzi0JWQ5YsYmZMJFQongRAwTE3Ny5ArbMZio74CeaqSQKVvQZC16cILkLCFqwZCyMiYsmgNHMzDZxzbbTtaJSsEAjio0FeRPKK+WTDrTdjbbCuWh1xonNLaoTLYqWukTsU11weVBipxpFcUkpJwkimY48RB8hpR9gnoXVt7SEk4Ts6ycld4jzTGl3plQW6QVAYahKU240F4KbElx+gJM4ftDLaIt2hdf3209G9SaapQpdPXpuCyCSOCgocopuZANOewc4mnNVHFDFLuNzCRn0ahiHNJuO+C68iLJB+sekJA4VyqHkFXbbUE4U55dY3rsFqHZlESlxJFQRTbu79o74i3QtBKVAgixChQg98EaG0iqXdS6hKFKTWgWnEm4pln3i8HHRr2EPpIqQfmuyC5PSKqYVgqG/b374kZ2ck5htSwy5Kv50aTjZWeVsHurtiHblV/JiTLIkF0N4ltXdE/WXAyFJSSCoFR2gZJ3k7twJ2RDtS5AvSC2KAg4wCKEEG4IyIoagxJlYkkttxhRadFFJsRt4Hjz2x0l/hHU/pgvkKedxqAoDhANOYTffffHKXWxSqVGoqK7RvzyhCiPemJ2COws7LcqCCZdVexLqVyBPoDBaWps9iVIHEEetIASBmgrbWJ7RDH7qVZddfgGTbzg3QmjnFqcMw2jqhOEEA3USMgTe1O+DC0EyyqCl3TS2YUlBpTZ1oDAi2y6MGjU7jLrxcCpBv5xmTgt6ekbEiX/cVJtZlQvkOoYyB4Hw3w9MnY1u3RpWqayJZFq2VS9q4iSOdx5xmwz8o0XVl7CwgVvStLbe75tGYYk2Vq4eI+EKGQ8o7SOFP0j2GDRW/o8KQ6RbtGncG/8A9FRpaplHtp/mEZXqW1hfBtZSPMtRpkisBFCK9Zez76oP409Mn+THaO3sC0GyTY7jsjGtP6QeQWwl0gFIxHChf2EXooXuT4xriGGSTVtFq5pG2tNm6Ma1sTTo6eyPeP8AbFJu6olx1sNR9WWlJU5LqJSknpGkJorCMQqEJ212wy7oqTKVKKZVWEE/s3FIyFf8Q+kVcq2R00mJ0ytou2reosrOsF1ONkhRThxdJsScyOO6HJv6JyEkpmBQAm6amgFchSJv6MMf1ZwBZADhNgk1qlG8cIt5xglJUFAoUbgD2R7zFcVVknOSlpmHTmpJS30n1lvAdqkrTnTOxp2h4wJI6gTdUvIQl1spICmlYgbqG0DlF700isgbZA+RRT8sTn0czKjIoAAokuJuopyVj3H24jwvItzfEyXSuq0yEmsu5XcElX5axX3tFuo7bTiae0hQ9RH0NrU4ChhdLhwjOuaVIN+ZjLlaQdamH0pKlAGuEulAHXQbVNBYmNKXzaDBfCygKZBsI6al7ZbY1DQc908wy29LgoUuiqqQ9UYVGlklVbbDsix6x6rSKUtqRLpGJ0IVZaLEGtqgg5Rn/wA2ZP5VRgrktcwOqXrW0ahobVaWmul6im8Li0jAtRslakiuPFujqf8Ao5b+y8sbLhKvSkFNmbXRkT7VPKGQspIKSQRkQSCDXfGiTv0fr2PpNxmgjLko+kQzmo8wAes0rPJSh+ZAEXjLWzn5FvRVna1qSSSbk3PfEroeQW6qiVBKRhxGlSAquQyOR2w/NatTVKBnEdmFSFE9wVWJnVXRzranA42pPVb7SSnLHXMX2Rr0ZpJ6GTqs5W0yCnggg94PxgxnVGub7h5UHrWLCyzEkxLxNtlEQh1TllBJwqSoABVFEhVBTFvBPhEnJ6tSycmQfxEq9TEq1LwewxCUPYCxoZkZMtj+BPwiYalsrCwAFhkMhDrTMGNNwMQ5DSGI9dYoIOQmOJodWC46Fy2UafYUp1AQQFY04a2BIOR4fCH5VkmXKVXP7UW3mZlR/uMeFNZyXH+cD4BR90GSTfUaHtBSv/kyh90RZYusyaSTx/yl/kMY44knzjYdK2kHa/4SvNJp5xkK0++LPpEfLGsiKRo2g2QWGyKXTnllbLujOyDGj6us4WGwRWqQam4INxTdb3wo0CQEuPa8D+sKOg2n2aR5BGKrq6KPHkg+GD4RoqLWA23rle5ii6FZwvVItROfCkXdU8E17BvfrgUsOGUT/E82D8vxR0lsg7KRjmuiezyp/reHujYP+pJ2qbTkTRYUduynCMn11uoYaG4GYH95MHaeXjHRKo0c/Gm7Kh0cdto3R6QR7PcpJ9DBbMvW2JI5qFPKFyRTFmlfRag/V3bf3n+1MXCY+0SKENn58op/0ePoal1hToFXPs0I7Kd49Isy51tWKjmKqSK1Rma8t8UTWJJxeRUdIsfuS07g55Vgz6LFj6osf5qx4oQYamXwWlIIpixC5TmbXvaB9QZttlhzEv8AvK+zTqCo61I5/wAfXZ0fkb6J/Wpr92FNjgPg6P1jJdZ2qTUxy/4n3RqelNMS5ZUnpm6k1AU4gHPnGZ6wuoW+tSVghSfs0V6GDJfyWCL/AI6PPo+TTSEv+I/kUI1jWduqWv8AztnusPfGUaqTjTMw26sqAQa1ItlS9Kn1i56c18lFISAslQUFUwrOVKXwjOkGT+DQEnmmR2oA/t//ADO//YqLNNNxVNQZoFb+E1SVqIrYmpJrTvi3PqgwWheR7IaaZiMmGRE68IjJhMNQlkbo+W/bI5n8pgieUhwAoCgAtaDipWqCAcibQ9o1H7ZHM/lMNtM0bNwf2zxspKvt70kivCHS0C9gTDN4kGUWhltMFtCBQbH224NZRA7IgpFo1BsJbTBCBDDaofQqNQbCUwzOdkw4giB9IPgJJJgS6Cuyqy7dZpJGaQ4ocw2qnrB7DZAlB7TboPc4yf8AbAeiXKzSgaght6tRyHvibSxVUkPuv/maEcrR02TGsR/cnAP8MeFUj0rGTqRQm0arraqkq9+FI/1pEZcriPL53xayKWhlRvagvGj6GRRlsVPYTTLaAc6RnRJzHONE0BNKW0kYaBKUAUvUXTXjdJgMaHkkulSLEwoaSN1hw/rCgWMY6nXZxBJSyzfgsmnD9pwh3/1InTXCEDiCocPaiC/7am6j9mn/ANweqawTK6mTRzCB3qPuisOOJCfIyRGvM4uuJYB4VPqYDmNLuOii1CgUKUAH+ITlndR8YMl9QJgntgckn4xIs6iBAIemAmtMgSRTdQU274EuMMOVUQLZG/L1p+ph0rAizy2rej0dp2YWeBCB6wWiWkU2TKtni6pbh8FKp4QmLKZoqTOlFtpol1SU50CiBxsDSBpicUs9ZalW9onfxzjWNAaDZcBKWmkD/LbQnzAr5xPs6vNJyQn+WvraKx4n2SlzR6MRlkKUAENrWdyUqUTYbheDUauzZqRKuUN+sEo81kRpukn3GipIUCBlQJFPAQfq2jGkqVcnabmMuPYHyaMhZ1Vmx1ixSxqSU7eIJhpvV2ZGYSP4v0jeZmXThNs4oGk9FvKWejQoi98hkd5EGXH6BDk9kBozUtLlA7NoCjYJbQpfiqw9YkNI/Rk2Bj+sOWFBZI3ncd8S+hdHql1hx9baAPaWB+nnEtO60SqhhCsf/jSpzzSKDxjLjVbBLkd6KJoPRAZWoIdXneuA/wC2J16bWPtA8x8KRyZpgKKkyzhJ2uuBA7ggqPiIbd0s4OyllsfdRjV/Mo0/0wFGvIXKzkTT6uygK5IWfRUcPNzAutpCBvccS35KvAc3pZw9p5xX8RQP5UYR5QCt3aAAd9L+MHQKJiRmUocSpa0EitA1jcrYimLAE+cCTM8hpOFNXAXHVFQATQqVWlCb03wDKE4wTHZat/Eo+Jg5GxO29MJrdtz/AEf8oNZ0u3tCx/CT+WsR7UvwgppkQuQ2BJy+l2faV3oc/wCMFp0kz/iJ7zT1iNaYHCDGZYHZAzDgHNz7RycR/Mn4wU2+nYQeRjyX1dUoA4LHfQesdjVcEkFCbZ1p+sG36NS9nfSWiO0jOAA2gpzVdoWJbT309wiG03oFpCKpmATuS4f+ULJsaKV9ka4+BgfQlsk1ZcDg6uO5BCgoYSUjyNjFz0M2ouSwW2Ultp01qCCVLbyIzsDGb6InQ0txlwFbbowkEknGk1QpNTZVbDiRF11P0mpKlNvqT0gCUoUpSUhTd1JO+pqM65G8TjTZSSaRLa5K/dnRxRx/vEn3RnD/AMkXvGia0tKMusnCQVI7KsX2huEZ7NUNbnPMcAKVEDaezKmtDOCo+a7PjGg6KlA2hISkqqE3qSL7RuzjPE04i2w5nMeYjStFpKGm0hdQlIFTS8ZhggtTfFQ4CvwhQ7hWcjHkYOijaOkipQEX7Rui0gCILR8ulBqqnqfKJ1OmkJsEqPgI7YJ0cE2rJESaRsiq63SQKThF/wBYkJvWQoFT0bY3rVT1IiuT2ussT1nkuHc0kr80gjzhxP6KhM4kml+UGaOkXlkUaVTeUkDxNokF66AV6GVWTvWUtA+FT5Qx/wBfn3TRIbbB9lJWr+ZRwnwhMUNkzQNCOoZQARfcB8iH5zWBtAqqiRvcUlA84pUlq3OP/wBrMrpwVg8mwkecTMn9Hcuk4lkqVtNAK95qfOGABaT1nk1GpWVnc0lax4gU844ltZ1kYZaVdI+8oI/LjPjEtN6EYaphbHff1iZ0OBhsAOUYBWuh0k5fC20N5BUrxUr/AGxD6SYeSaPTTijuQrALfgCY0x82MZvrOrr15wH0MuwLQUqy46OoK7Sbq8TcxbtJtoba6iQk7wBFR1Zdwrr6xNawT1U0BiV6KY7Kw68ouGphKNdsNrQSa5+cdgD+sTbKJArraqw4GTtHiIJLYPzX58Y7bTuHmR+nnAsahiWbvl6wV0PPzMOtoVu98FtJ5iNYUgZqX41gxpnhDyE3zESErL4iAE1MC2GkABnhBDLR2fCLTK6EQB1wa7gbCOJlDLZoEBRGdSaDcOcNg+2LmrpENjcOa1HvJ98NKYJ2xYmW0puSykm9CMVOGcJ3SDaQf2orSwQkD1BjY+wZekVtUgo5AnuJiK0rotaU1KSN1QR6xbG9ONJABLh2mlAKm53HOIXWHTbbiQEhQIr2iTWvPKFklQ8XK+jOJ1uiuV4nZmdJlW5tAGNkgKFPsqURXuXiHJVDaIjSBrUwfqI+lRcYcuhwFKgfZX1VeeHziF7LtaCpzWf6ygJ6FpFaEqSkpcIBrZYN9kRhYpfGoAbCokXttvHr2jOhUZddy2aVyJ3KG6ooe+G0uLHVIxCva22BpUb+Izhsm2LiktCbTVSaeGzONMbBCqYxkLm3x3xnej2iXUgUrUEbrRoAfpgIHWoknKlaCh4f0g2ZI9M2kWLqQRYio+MKAnpFC1FSganOm/uVCgbGKb/3DPumjaG0D7qVOKHebeUGsaC0i/23naH7waHggCLzoqTSPsiLEymkegeUZxJ/RnfE4oV33UrxVEsNSWGxW6udvSLuYCnco1BM60rLob7CQnlC0CMSxaHtYFXNIa0A5RXVjANG0ejqiC1GAZB4FI3w6+9QQTELp50boN0MvqCIWffqrfEhJvACMjEhPzFEmM7025iUYs+lZuxFYp8+2TmaQk2UgrZ5IVTs8I6m3idleBhlhKk7ajv846KznWwzrELL0DNoqK0Ke8CCWWa7a8DDraArKx4w6E4cxUQrY6Q30VDl8+sdkDOoMdIWk5A55V+aQaiWqLeYrAsNAraa5U5VIPnDoRTMKHO8FiQB2U5ZQSxo9Ww17o1moCQDvBg6Tm3G6lBp3A+txBo0K6RUJHMmkPI0E790cz8INMW4+wNek3TmtXjTyhhZJuc+/wCMHNSNVlKloAGZrbleDEy0sntOYt9K08qwKbDaRBhJPLnCDR+aiLEhUuOwypfEAn1MeSTi6qWhgUVTDcJAAtlBx+wZ/RAjRriskE93vgDS2jFtgY00rlcReqTB2to5AqPuEVvW4KThC3Co0JyApfcOUaUKRoTbdGc6RbpWIaQmeieSutgq/wCE2V5ExP6TFcjFZnEEHKOdnUtmka2y+NpmaSNnRu03iuE+o/liAkmCvskChFb8fm8WPUg/WpVbBBOJFK54VpsDzqlK/wCKKzVbK7iikqII4g0Ig/Yq8okJfQz7biCWypOJJ6hqRe9aXAi3vzIwkLRSopWl93vgXQc6l0JSTQ/YIz21SeVD4EbImQSLKNfGHVCNtEc3MooK0yGwQokvqiPlIhQa+xc16FIGnz4RMtLisSszEsxOWjuRwEqpcR0+8KGOXJnjEVPTPGCArunVAmBNDqUFC3fkI60oupgeTmMNK/0hWMi9Sc3aFNT1s4rjc7xjh+artoYOQKYY9MCtRDiZ4UzpEG4SL/JjoOg8DCZDqAXNvVtUd8R60X92/vjh5RHEcqxw2vFke4xOTstBUOdDQ1BztStPAZR0kbxHSRaO0JqKpPcRYxMocpaFbGvKDG2q5GGMNO0KcU/CH20YsjX58awHYU0dNM7DU8Rn3wXLsV7KvHMQ03VPHn8RE5omT6TrZJGZPuO2MtmetnujZFaj6mLEwyEighsPtIFMQ7r+kMu6XbGVTyi0UokZOUguZmAhNT3cYhX1KWaEVUrIeyIjZ/TBK8VvuggkDdlADWmnUKJJua3w35QkpWxoxouLWiGhmmp2kkw6Uso2IT4AxTpjSTirFwngTSI96ZO20HNeEb9bfbLhpfTTeApQvrG23LbfbAjutCG0hKGlECgBJA9KxUHHlb684GXMUzHhCub7GXGqplpmNbl06uEchfziv6R06t3tqJ4GlPKAHn68fnfEU8rn41/WEbb7KRjFdIcmlA/oYhNIIg0g8IHmQaRJlUWX6L9KFp8oJsqnnRJ764O4GJv6StF4HUvpHVcpX8afiKHuMZxo2b6J1C8gDf8ACbK8iY3Cdl/rsiU2K8NU8HEVy5kEd8PBZJx/0nN4yUv8Zl2htJFt0JJsSMOVlfrbvA4xpmjJxLqAclAAED1veh+IzEY7NClbXAPjuiyan6zIK0pKsKqUIUR186gfeyI3qr7ULF0PyRvZouEbz890KJJiWbUkKBKgRUGuYMKOj9bOX9qKQy/BrUzSK4ZmhjtU7asdBy0WBU5EZPzedM4jlTdq12wJMT1aAd5MBsZRE4/U584YDtDSsdPGorHLLNttd8TyKqIYys8ocdGIXtArD1eqfOH0Clj4wLDiJh05Hzjp3fu4+sdqIF1UHGBvrgJom/GB2HofbfFN/fs4R6SCQQPGEAFDK8cKaUnIVgDBLYGQtw2Q82AOHDZArTgNrCHaEHeNlriFodMJKhle/OnjsjhUuCcQNLZVp3x6kj+sOdEadU33Z2gIzQ0tSqUKjw3+O2E04sABJJHE0PhvjtLhFlIFN4+bR30YN0mhhhf6HG3+Yjv62QLivKB60sfOEEbj4wKRraHFvpNyAfIwO8sEdQipyCrVjhxV+tY8oGUlKq8Dtz5g7I1UG0x1eMCivO47obTMJ/plDiHSBTMfOzLwjyjZHZw8owRtQScj4QK+gi4NYKdl9oIPrSBnQQLGFoNgLiScxSBHhz9YKddINwRAbkwa5VjBsaMMvAwQtYgZ8bQYSQ6IuaNDGpfR9rSEy6UqqpVcI3VQADU/hwHmoxlM8vfEhqlPUUtFdzieaLKHekk/wQttbQWlJUyw/SHIYZhakCiXk400yxEjGB33/iEUcuXCt+fBWYPfn4xq2mm/rUiSLuM/tE7ykDrjwvzSIyqYolX3VbuAHobw62rAnWi56O19cbbSggVSKGgIrxzzOZ4mFFGLtLHMQo1s2MTQFuEixhtp8i2eyFCjrOGjucfoMQFdkCrJIqbct8KFAD5CZV3fDxXQWFTsFY9hQjKI9W3W4F47ZexJKSTWmzZxhQoATtDOwmo9IZclyns0Hwj2FAT2FrQVLmCheFCgsERl2TBvUg+XhDjGNJw589nKPIUKOFNEkdbPheE03hVW5rnfKn9YUKAEKCtv9YYcYGabGFCgpgaGVzVDhUK2r3R2hCVdgkHb85GFCgtULF3o9psVeBzKpriTasKFACximGufjWG1UzFoUKGFPOlP9IbLkKFCsZAc8MdwaUiMfQRnChRkZgil5wOuYEKFCyQ8WRs2uBJCe6J1DlOyq/FOSh3gmFChYq2OmapqpPFDpQcq07tkUjWzRnQTDrI7NcTfBK+skd3Z7oUKF4vKNMr6Zk7knmKmFChRYnZ//9k=" alt="NO DATA FOUND">
                <div class="venue-info">
                    <h2>Kolhapur</h2>
                    <p>Victory hall, Sayaji</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUVGBcXFxYVFxcXGBUVFRUXFxUXGBUYHSggGBolHRgVIjEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0lHx0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EAEUQAAEDAQQGBwUFBgUEAwAAAAEAAhEDBCExQQUSUWFxkQYiMoGhsdETQnLB8BQjUmLhFkOCkrLxBxVjosIzRFTSU4OT/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQIDBAAF/8QAKhEAAgICAgIBAwQCAwAAAAAAAAECEQMhEjFBURMEFCIykcHwYaEFQoH/2gAMAwEAAhEDEQA/AKFZmBowF8zvvU5M/RQzKm9TNesju7N0aqjV7cBI78Oak1w4DIjxW2lcuo7MUrfsPGujUZFaa0svbeNmzh6Ltr8nKQtjeNqFh7JKLwRIRVF0GUucw4txzGR9DvU1CvO45jMKco+UPGXhjaAcxBjjchrbZ2vLbgdXyv8A0XDXb1MwqbbWylJkzflC6P1iuWhSAKbY1Gifq9ZTfBE4dk44ZT9ZrotXMbcPkusFA9dmrO0Xdxvafl3KGx3S3ZeOB+jyTCq2QJy6jt4PZPPzKXEargf4T8vHzVE7VC9MPaFK1qipqdqhIqjYaiG3gbRtUYC3CQJt4ABwk7FDlG1SOCjcijiOo/6vSwvlxOQuG6MT9bEVbHwLsTcOJUNnoAkNyGPAeq0Q0rJS2xnoaz4vdmN+HNSvdrHW29nGQNuOJ9FK49XUyxdwyb3qPEyoyk27CkcObJXBYp9VcuCW2O0B2izBwhwkKCy2YMYGgRGPHNHPUDyqJuqFpXZlJ0Y5rh8DEiBPioK9YC8lBuBd2rh+Hbx9FWKEkzmvXLnS24Tj6bVHrasxmZzmVLE4c8lw6BheVZf4JP2yNxwJiR8tqjNUuuAu74HqphZ5vdy9V2WAJuVC1ZC1t8xJ7/C+5d03x/b9VqoQoXVEU2wNJC/2cYGPLkuhWIxEb8kOx5l3E+albUC0NeyCfoKZWUrayXmjsu4FdijvPNI4IopsYF4K2yoRhyQIpbzzXQpbzzScUNybGLSD2cdnoo6rZvwIz9doQoZGBKnbXm52O1Lxroa/Z3TtBmDcfPgimV0DWZOPcVqnR3nmlcUxlJobsrqVtdKm0d7uakFH8zuam4IopP0M/brk1kv9l+Z3Nb9l+Z3NL8aDyY0o1QRB2QfhOfcoLYzbibj8Qz8ihaILXAyd42hG1TN20Xd2B+SFUzu0cWevIRTKqVMpbyFM2ifxO5rpQRyk6Gjay69slgon8Tua69j+Z3NJ8aG5MPNVROqoT2O93Ncuob3c0VBHcmZUfLpyb5n9PNG2ZuqN5vPyCDs1K/cL+9GPN31jmU0vSFRL7X1O8qRtVLhZ/wAzua37A/idzS8EG36GBrKJ9oQLqJ/E7monUDtdzXLGgOT9BdS0IStashednrsQ9Widp5rdFkYd5KqoRQjmzprb5N58uAXbo97l6qN9WMMdqFdSzvkp1G+xXKugipW7lGK7QltSg45nmVILNx5lV+OKXZPnJvoNNrCgq2sDNDPoDfzKiFKD6pljiK5yJXV3Owu3n0XPsRnJ71Ixil1V110dxvsAps7XxO81oMICYWWxFzXOH43jkT6Ldn0c94uaTMgdydyJxWjqlS1Wi6TffvvuW3tBbN0jYpWulovgicuIWzEQL9p8VNsoog7aHl4zELr7MURY7PUqu1KQzmfnJwCd0eiTyetWaHXz1SR3m7OEHS7Dyor32c3d/gsdZSframVv0ZWs8F8FpvD25TtESELfu5BK3Q62C02HuPnmEQyngoquI+jcjKYlLN6Ggt0aaxdimpWMROj7DUrvDKQ7zdzOSmk2Uk1FbAvZKajQzxjJWGn0LJiazQ4gnAkCIxd3oO2aLq2aPaCWOghzb8dqdwaJrLF6F9xugQcEMWwYnDDhKYwBfM3XcEDaAcRippplGtEgoYx9bVMyz7/oLKLTH1mi2iLz5YqbY3ggbZSu/shVg0XoCrVaHkimwm4nHAmeHJMD0Uf7lRriSRBEYTt4JvjbVk3minRTjZiuHUE8r2UtJY4Q4ZeiFdZ1NuiididzIu2lEMoKepZ+uEwpWVM3oCFrLLJhEfZ4wHNOLLo9znBrGy7wHFOf2YJ7VQNJuIjZOfcUYxcuic8kUUi0WXA7VC+yfXdM+SuOk9BvpiYDm3iRxjuSerZcwi7XYYyT6K5WspQ9SgcBhEynlelE+iXikc/oDAJ4sEgEWU4x9Zrl1mKaCiT9C5NdFdH61brtAa24a7rpkxIbiR6Jk2+hW0uyous8Lh1JXm09B3wdSq1xBAi9syBgcDiqtbrG+k4sqNIIuM4hU2IppiepTUIZemVamhQy9FMLiTWegAASJnwUut+VS0I1YN29S06OvJnPfkl5HdBGgGQwN1daalY/yl/qmtAt6h1ReXZXSWXco8EV0fs2rRY8tu17QJuk6z3gRyXT3gezpm4TwvhwJg93JLKatoRRfZR6lPqc/MruhZi4Q3EwBxcQPmpnAezPxv8A6imnRho12zdezH428kbr9yn/AF/8LJYtFOs9NrGsZMS5xJlx2m7Dd/dFkVWOa0Bl2tm4zJkmY3wi7bZZJh5gA9YkidsDZgpRZesPvHG52cxe3KF0kZ0xfZLC8t1Cym4OlkOJiACDiL8O4XCFRtK6NNCo+nk03fCQHC84xMdy9LbZ+z946dZ2fxqmdM6IFpeNYu7N5+EJXpFcTuVFNttQC7NG2R4cLlFaqIEuiYxnYOCIsVCN3D9V0muJaKfIOZZy4arcXEAd5AXolh0UaFIU2hktbrl18udnPJVDo7SHtmSfeb/U1eg1qTOv1j2Pxu/NvTYFaZH6l7SA6TKtOo1uq0w1wbOteCWmZjffw4KZliJZqPaxzXTTgk4NBE4Y9XuuhGmm3XHWPZd752t3rmnRb1es7tv9741ejLZ5tpHRpovfTPuugH8pgjwKT2x4FyuPS6kPbuvJubnPuhVi0WcYxN4F85mMlhbSmz0424ImsgkAqwdH9Fe1qgkAtpgGDgXEmJ3XeCT2Szgforn0TpDVfefdzj8SSLuWjsjagNW03nUcGtw14k5CCML+1PHipKQqOAubAcbwXC9zi2LxeL5jgurIzsdY9g+98CKp0xq9o9vb/qLTEwyFmn9Ha9Iu1QHU75BJJFxOW+VU69CF6BaaY9nV6xwdn+VUytRk5qOek0zR9O3TQku1xuTiy0FGyyX4DbmmVGhG1T7KNlg0ZYvZsaNVsvGsTN87MMp81I1726p1W9Y6wlzjeWm7s47kWaXWb1jgcxu3LltPq0+scsx+A7ltSpaMLdshYx18tbjBGsT2zMdnDrKr6Y0d7OoQBcRIzu4q3Op9rrHtN2fl3JP0jpjWbeT1d21Tyr8SmJ/kUq104klLKLQSrBbKI4oCjQGMR3qMXo0hWgtFirVa0iRi4HMNvjvMBXWvRc4ABrBJLY1iB1JjBuHUA4cAkvRSj96YJHUOEbRtCsLaPZ6zu2/Z+fctGH9JlzP8gF1Wo4PGq246xvcC3Va10dm43AcyEv6SaC9tTcNVuuxocHCb5m7DC5PK1Hq1es7PMf8AxjctuojWd1ndke8dr1Sid0eJ17OQL8pHIwl7W3qy6aYNZ3xO/qKQNgOkwOKkn2bF0SVRATLRVjc6k0hxEzdA2naEs0hamwIk3ZAkc4hDWXS9oa0BhaGiY5neioNxFk96HNDTLxSpgYNq1CBOP3lSbu9ZQqvLhOvMlw1hkcNih0RZg5jL/wB5VM8H1E5p2Zx6romTyu55JZJWwRlpFWdQGpJF+s68SDjuUtjp3YngSSOSKtFLqG/3nHnBWrFT6vJdJuikEi3DoYw60VCdUT2W79+5LndHaf2ptAPMEOJcQJ6ocbh3K7WmuR7QQL9Uc9c7FXxRIttKRE03m+7Br9y51RGMpW7I6fQymQD7U3z7rcp37lUrdZNSo9gcYa9zbovgxPgvU6NIgNIDfeH9V+C830mJtFUf6j/6iktlMTt7FYoYiSQRmpWUpOJHAwp3VCMBEfQWPI1gdqDLqiSlTjMncTcrp+zNOD95g3Wwbjfd4Ko02fW6QvS3WhkOB1Z1Izx625NiSd2RzyariVevoVjbQyiHSHCS6Bd2vRMP2WpZ1cyMG5A+iltzgbfSiIDe739yaudJGHadn8W5dSTZNylS34PPrbZQx72NcYa4gRF8GJwUNOlkSTfnuR+lB99V+N3mUGwrNKzbCqJqVKTiRwTrQujm1XlrnEDVmTBziL+KUUXXqy9FP+qfgP8AU1dDckhcmotoLp6ApxPtPdJwbiIWaL0ex9PWc6DrRF2F23inLeyLh2DnuG5DaAOrSyveMT8K1cFyRj5y4sD0joxjKZc10kGIuSv2W881ZtMOmi7DtBIQpZVUtFcMrjs0xinYzeVw1TMU0MxjZ9Gtc1pL4JGF1ygttjazUh062OF2HqmthqdRmGBzQWlHz7LDH/1WppcTKm+RwdHs/GcRszSrSNENeWgkgZ9wKtOtjhi3PeNyr2mR967u8glyxSQ+JtsR1WX4nmoHUsr0bVF6HrhZzSlok0dZw+o1hcQHGJnBOx0fp3fem9xGWQPok+hT98z4grY20ukXCNc5/lO5aMSTWzPlbT0VqzaLY41g6oR7MwMOt2tvBSaQ0FSZTqOFUksbIEtvRujXEPtcAYnP41Jpx7vZ1hd/0xn8SZJcRXJ8jy+3sG/PM+SWMaJTa2NBN5Strb5n9UI20aHSZ1bzIHegLCYb3u/qKYW5ouEjNBWJktMX9Z39RTx/SBtch10eeTRokm8uq+OsfmnNOte0kRAdyaBB81RdG2zUfUj8sfykfNcW3SD3U3Ak4Oz2oyxScyUZJQ/c60ppNweQDiRmRkMpjwU2jLY64OuaB+IHNV0vkjuTClVWmeJcaM8Mjuz1Ot0tsziTFW8tMQ3LWu7e9BWjpJRdaadUB4Y1jmns60uDoga28ZqgNrLoVlD4UWUz0v8Aa+zwBFW433Nki/PX3qjaW0iXVnvpzquc5wBLZguJvxvhLDVKjL0Y40nYOfoaUnVH9YTwluXAKF9oqF0/Nvop9Gv6nf8ANCNfeuW21SH6SdsZWO1VJGtMcW/IK9u6TWczdUvAybjfPvbwvOGVVI2skcPKDd9l1qaepG0sqgP1GtggxJ7WAneM0yb0qs4jq1LiTg3Ofzb1502suxWScA6Y10rpEvqvcyQHEkTFwJnCELQNV0wfEDyQgqI/Rr8UJKl0PF2+zqnWqNdHzHzCtHRrSopkuqNJkRdG0H5Ksk9c/WSOouuSNeaDfgug6RUojUd2Y93YFDo/TDGs1XB060yI3beCrDaimp1V1sTiizW3S7HMLWh0kzJhKhWft8UF7ZdfaErt9hSroZMc+Bf4lSUq7tqFs1a4LKdVALLLQt7Q1oIJI4KG1WxrtSAerjMX4eiWU6ly3rpuTqhOKuxu/SrL+qcjlklGkbXrOLmiAfRD1qqDrVlzbfZySXRHWrOn9UPaXPGfiVj6l4XNtqXd66tjWdaLt5p1Wude0EEidhVgPSSkDOo43yB1cxCppqKCrXTqxWk+yz0ukDGurHVJ9oZF4u7XquLd0rY5tQezMvbqgy249a+4b1UatdA166dQFdGtIWl5NxuyvPyKV69QntDvJU1aqhW1FpgqRKTtkz2PPvD+UeikoPcwRM4nA596i9uNoXJrDai7ZypbGVl6N17zIM/lqnDgxTO6JVyCJx/063zan9JlkztdZ3Av+bF2WWCJL7Q7x84WJ/UTu/4NSwxqv5KyOg9X8X+xw/qhSU+g1T8XPUHm9O22jR+VGu7iQPJyLsltsUgCyOn8zz5SU/3Ob+pE/t8Xr/ZW3dCKg99ve+mP+a5HQ92daiOL2/JeiVKtFousjLtp/RA/5wwOhtlojuJS/cZTvhx+imfsbttNH+Zx8mrf7JN/8mn3Nqn/AIL0H/NakdWnSbwZ+qT2jpNaQSJaODR813z5fYyw434EFl6NECBXMbqNQ/Jbb0K/1Kh4UH/MhOh0itR9/wD2t9Ftml7W7Co/u/QJPmy+/wC/sP8ADD0LaXQUnA1v/wAQPN6Ib/h7UOGv3tYP+ab2Y2x5xrH+dPqejKxHW1u/9UVlyPyJKEI+ClH/AA+rf3LR5Ss/YKt+Jg4uCtDtDVC/b/E35G5MWdHjF8efkF3yz9gcYrwUcdCHDGvRHF/6Imz9EtX/ALqkOBlWQ9FXXkvAHwu+YCms/RhuOu6PhA83KbzT6soow7K43oxTmTamHuJ8lMOj9L/yR3McrK3o9SGL+bm+UI2z6JojC/mfIBcskn5FaiU86Bpj9848KfqVx/kojqvcf4APHWXoDdH0wOx4H5las1mabwwAbw2TyT/lYlo88/yZ+1S09Buze0c/kF6Q6gBg1v1wC4dAxLRx/uulyRya9FHs+hX5VJG5jj/xRbNAHMv7qZ+ZCsFZtPEVQx35TdyC5o6SIMEh42iQlTGf+BVS0Ici8/wD/wBlKdAujB3+0fNWNj2uAMG/aoLXadQAgYmMf0VOGrJ8yqWvQb9jhxSy0aHcM16GajtmzLalekaVV7iA2Rtgea6ScUGM03RRf8ocTijKfRhzsarO9zfJWJmgahxgd/ooa+jC332k7Ab+SnykU14F9LoLONTkAfOFzV6EUR2q8fyzyEpjSsFWR1XRwKM+xbRmqRtkpOisVOidkH/cPPwt9UBa+ilmydWd/IPVWyz2UF7xs2gIqpZQBPUN03gJ1y9i80eVWnouCeprd8HyAXVHoDXdg10bSFfv2g9n+6p/wgjxBWHps3OnycfmEPlyLplPji/BSnf4Z1/xN5kfJRH/AA0tP5P5grZa+nTv3bI4wfKFX7T0krudJc/uuXLLmZ3xw8oU2HQ9c/uakbS0gcymVLQVYiNUDHF7B81dW2il7tnc7eWAH/eQpDpV4ubRAOwvaPBgcsD+qk/BsWKioUuiFbIsE73Ov/hBTSw9EHXazpg5Ndt/NCdNtNsfhTpM3uLnHlcpW2C0PjXtJA2U2hvib0fuJPtiOCRPW0KyDrGJjYMO9Cs0FS15Ae7hcOerHinDLA0e86dpcZ8Fv7FTmSJ+Ik+ZTOTJIFOjGQJDBj2iT8wgBoqyzJ1XHY0E+AJT0vpNGDe6EqtfSGg0kGq0bmy4+C6bYYWd0qFJvZpx/wDWG+JaPNTMeT2aVQ/xBrfBySVumNmbgHPO0j1NyDq9PPw0ubvkApqEn4KUWsUqpwbTaN5c8+IAR7LOc9Xl+qoLOmlVxuDG9xPmVaLPb3OaDrTIGC04sbIZZUN/Zme3HAD5rqR+I95jyVNtNof9oALnauySnlB2CrGGyUpHVe12cHrv1txJcOSHOnbK25oE7meqp+nqwZUcB3XpF9qMqTgaIpNHpR6U0h2Wk47BgjLDpo1HQGxjedy8uoWkyrt0SMkknKBuuvRjGmLkSUbLPUtDi2ZHJC6ItT3tOs7Pgpq/YdvB8UFoAdQ34meRCvStGW9MN0m77smVVn2m9WjSrgKRn6+gqNaawnFSzLZfB0Mm1kZZaglV6laL03sD1JIrIudl7LVFbq2qBcDf4LqxdgIbSkEN481sf6TF5GIqSMMkut9Co53UcGjbJBRjTd3JNpx0EOa6ClyfpGg9hLdHPxc/X/K6Y8CiKdZtO409TeACOar9LpA9lzoPgtV+kzjcAB4rPaXRo4t9lo+1tuhwvWVK52KoaNq69QSc+Cs5Kvj2iGTTpAllM1Kh8kVWaIPBBUbnvIzRVR93cnQjKLpUCTgq5aSrDpogEghvh5qsWrv5qaWzVF6NG4A3b+aDe94K6NogQbx4qEWsDLxVUhWz0mt0hsTe1X19zZjk1B1OndlZdTpk8GgeZXlLay79ss6/4+C8so/qWz0at/iIfdpc3R4AIdvTuu43NYOAnxJVA9qibJVvVPs8a8C/O2enf5/UcAQ+JGV3ilVo0jUL73uPFx8kpstpuieUrHVzKCxpeBeTLRStw1L1T9KWga5hMRaOrkq9pGtefr+yaMdnRdHLq622ul/tFI16rwDzH2jHS4DevRbK+GgDILzfQYhwON/1C9Csh6uHjMepSVslkdkVqZNQHP65Js15DUvJGvdzUz3g53Zbz6I0TspfSStFQyZKQmumvSmBUOarzqiVRNMXoa2Worx0Tq9bdEfzXnwHgvPbG+/6yV16MvGsCTAALjvJuHz5pXGmdN/iXitUGE5HyKg0OfuxvDvMIOBJ6zuyc+Cl0c2Gs3yOY1vkmW2ZugjTFXqScOqeINx8F59bXQ4jMXK+W0RTMnCWngZA8dVeeaRqdacj5i70PelmrZbEzKdVONG2og4/2VYp2iSmlgf1hx5FI4lmz0/RtQezbfl9dy4t8GBOf1/dC6JqdQZDD4Xeh+aKtDQe7w4Ky6Mb7Cm4JTp5sjeEzot+tvBBdIQAyThtzHD0Ql0GHZRrVXgxggzab1HpCveRclpqkFSUTXZcujtf7wTP18lcddUDopaC52rrCNh27th4K5Nc4YwR9Z+vNUjozZOzKL4LpUtoq3Hghw86xEjv+vVatcapkhp2mIREKJpt/WN6rlpeQmfSCvDyAdbeLlX6lXejCJo5aMqVFAXLT3KPWVkhGxe2ouvaLlrRJEHAxhkclvUF1+MeXC5aeJm5G/aKehUUAYL7j+uzC9biADtw+filcQqQ9s1tIF313rZte0z5ckmZVJRNO7FScEiinYzNuKWWqrJWVbSMByQ9IazhrLowC5HbGOOAW2mDvW6rjBg4d2Iu8VxaHXgkd3emoXkNdGWuHAq60tMN1RF0ZRIH6rz6iYPM92QRbatxvMX7sNqnKA1pl1p6RDnXm7z/AERP2gi+ZJ/2jv8ArkqSK0GeQ+eC263GLiTPrEbkvFgo705atZ52Ycskm11LaHySJN15nZnCCD0yiPY1sdS+Pr6uVv0K4Eby4Du7PlKodmqxenmj9IlhbuM+BHzU5wGu0eiMN7uA8db0RllrdSldMR4scFUbHpvHu8B+qYjTUUmQR7nyHzSJE5IcaarHUqNmJgjkI8QV57aqgcHRkdYcDAP/AB5I/SumXO19kbfwn1KrtOuJk4CQd4Nw80eNjxdIk9pfKa2GreCkZABiTn38LkdY6oG3EY5XZoyiPyPVNFWkOYCIBiHA4OHrj4hSWh5/FuBme4/Xiqlom3tENJ7jn3wmTtIiLyYz4bUhFrZZbNaroOOY+YSfpJaXOEEjcSbjuI/F9bkM7SlMXF3WGBvVc6QaXDxAkHPfvXdhihFbat5QorKC0Vpxv3qAVVRR0U5Fh0bVdTc14MAmA73Sdk5HcVfrDbyWjW+vReZ6KtpZrReDAIN4PEJpZtJuaQaZkH92ThEzqnl+qDiI3Z6ELQw3k88PrkVVOkOlDJ1akt3eUnHgp9HabpPOo+48r9+WKF6S2OnGs0kZdWDzjHvS+dgKba6hN6W1HoyviAZjwM+SAqC6b+/LjctMYiuRwXrWuuiwTnn/AHmL+CxlMHOOKfiJyFIK6CxYrkTespBUnHJYsQORMyrC69stLEtIezsOXDqsXrFiCWxjsWqTJbfxXD6slYsXNHI6Y6USyosWJGFM6NTNRGosWIBI3VMua4lYsROsnY7BTNrXraxKPYfZ7UQFMdIdWDeLvCCsWJKDegO0W6bsAhXVFixNQLOjUlSUqixYg0EOs9sOcI8aQ4LFiRxQURV9Inu7rkDXtU4m/asWLlFHMAqVFF7RYsVUhGyWhatXBE09IAGWi/isWLmgWTfbw7t45OGP68PJcutr2jGW7Z89ixYl4oNi+0V9ZCOetLFWKEbOHEFY2qRcCsWKgh//2Q==" alt="img">
                <div class="venue-info">
                    <h2>Satara</h2>
                    <p>Swaraj sanskruti hall</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRH-CKcdu_zhq4rn6qH91KfiZHEoPNY5NPaXA&s " alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>Aanuradha</p>
                     
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT376OzK13pZ_wfutrgq8wU-druhr-NiXbxug&s" alt="img">
                <div class="venue-info">
                    <h2>Sangli</h2>
                    <p>Heaven cafe</p>
                   
                </div>
            </div>
            <div class="venue-box">
                <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhIWFhUVFRYVFxgVFRUVFxUVFRUXFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICUtLS0tLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBEQACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAABAgMEAAUGB//EAD0QAAEDAgQDBgUBBwIHAQAAAAEAAhEDIQQSMUFRYYEFInGRobETMsHR8EIGFFJicoLhsvEjM0OSosLSFf/EABoBAAIDAQEAAAAAAAAAAAAAAAABAgMEBQb/xAA5EQACAgEDAQUGBAUDBQEAAAAAAQIDEQQSITEFEyJBUTJhcYGRoRQjscEzQlLR8BVi4QYkQ3KiRP/aAAwDAQACEQMRAD8A/D0wGLDAMGDMHYxrHmPNABYyQTItFjqbxZGSSjlZyBMicCgaKVw6czpl3ek/qknvc7ymkl0HJtvLEARkiO95MSSYECTMDgOSOPJEnNvqPQDb5iR3TlgA97YGTYc0yBOUxhQAykivqEKWSTRam3TgTE+X3UkVtPGS4ZBIkGCRImDzE3jxUkEUaKNRzXSwwSC3YWcC0iTyJVix5nRhHKSK4DDGo6NALuMTA4xueAW2mlzlhFU5KPU+qq4kNGWI1cQABFyQ2BYEmSY3jaFcvzHFLo+F/wCq9qXz6IxJJvMv8/zyK4CuZP8AS09TVaD52KTe6G/1jOXy42/ZBP8Alfx+mMr7GP8AajFd3LlHec6SdYPeYB0eb+HWMeXjPkn9UXUrEefd9z5Nyoa2vBCftAcAAL3vIg2ECDO8yfLmqWyGGib3yIsIna5nYndQZfCXBEFRZVNlXNEEzBtAg3mZvpaBrxSRULTcLlwJsdDHeIsTYyJ23UycpbnkOHr5XZoDrEQ4SLgjTrPiAoSYiMqIDJCGARgsb4Co4K2zlpj0JRFKTJ5KMJi3D0THux0IlRIGFYS4o6nABkXnQgkRxGyRJxwkyaZEKAOTGEIEVoVnMcHNJaRMEGDcQfQkIAUhCDHGQJgFMBmCd48UMXVgUkJIoxtibWje950G+iY2uB2BWIqwaKQ3U0icVyaZfUc0augNHg0QB0A9Foqry+OprlLbHJ72DpNY2BcNuSP1OFrcgTA5ldGyPiWlj1azN+kfT5/oYZtzlj/Ev+f0FbmcbC5kxOzBmI9AP7VU5p1WXR88Qh7l0H/Lx8EacHUgvv8AwjyfS+y0SglN1ryrx+oSS6e79pA7cGZruQa4dJp/+jVkhxXRZ6px/dFlHkvc8fqfMPChb1IzWXki91ysjIsm4qKb8xZSBl3G2ug1MWE3Sbywlh9ASgrwKUNkgSq2x4AEsgaG0XFpcGktbAJ2EzEnaYPkpCRahWaGOaWAuMQ6TLYmQBvP0QSZ2Gptc4B78jd3QTHQXKTKzOrUyxBLDEoYx8Li3U3Zm6gEXAOog2KYGYlRyBjWItCSkByYHJoDkDHbEGZm0cOc9Enkax5gTEcgQ9N5aQ4RIgjQ3HEGx8CmgZxKYDOA2MjmI9JQhPGeB25cuhzTrIy5YMiNZmLqaAATwRZejWc0EAkBwhw4gEEA9QCrELBRitiicOp7mDwuRv8AORLj/A3h4ldNSho6XfPr5L1foFknLLxwvuzVjHBp+GLgHUA32YIMeO1yqXCdNHif5lvX9/twVpcY82+v6/2IgjMYNgYB4hsuJI5wfNX3QSnTp49Fy/2Jt+JL0Tf9iuGq9x88j5un6LRR49Zb8MfYrx+ZheuP/n/k2Y0yQOOdnnDm/wCormVvd2bu/oln6PkVc2oxfph/LPJ8tUsT+eClY0zXOGODJUdtHX6fnFY5dSiTW3GBAosqYXN87bbEapDWMCNKYNFKuW8A62kizb2da50uI0PG0ZMRImygSWcYAEAygeYiTB22KYkdmSyNhLkIT5CBvtp5RPuFaiWMLJqq46abaUNDQ4mQ0ZrwLnUgRolklFLPJgJTyHmLKgRMqylpSjUymcodrZwkXBH1lAAaY2BsRedxrbdJjTwKpCOSGOX2AygETe8meN4tyA13TEdTeWmQb9Dy3SY08AIQDQwbYmRYi15MzcWi0cdwpIQExMZCDDQWlTGWDpgQBE3veT+q+3IKWSOMsLFOI8Ht9nYfIPiOF/0DiePguxotNnxy6EEnKe1G2mcsudeLnm79Lfr5KmuS7Q1Xev8Ahw4j7/eQXi5j71H92ZhUuXHUX8XGw/OQVmm/7nVuzyjwiyKz0+C+HmOx2UuFjDSOIJdYEEG/ykhPSS7/AFc7fJcL4Iaacm/V4+SGoHuvHJn+p6v7Jk5aiyT9WRi/HF+s2bcW7uk7ioD0cMv0Cy9jQ73T20vz3IqoW6Ki/PcvueJ2o2Hk8b+d/rHRYdPJumO7quH8jdF76oy9x5lRDMrFcCNRBVLZBhNQyDMkRr3vliAQbEAACDaLIQIQkREdb8rfnFMnlYODlXIixnuAjLIteTN4gxYQOSRKLx0JBIGWolsjNOW85SAdLXM7wpJjwPhsO6oSG6gF2oFmiTryCGIkUIiFWokhXKLGKmMUqAiIIiIOadZtEaRGvOVlLBUAMwgEEiQCJGkjcTsmAHEEkgQJsNYGwlABc6YsBAi03vqef2SwNvJz2lpIIIIMEEQQeBCYBFQwWzYkEjiRMH1PmgDmtJsATYmBewEk+AAJ6IBvPUEpiCmIo9lmmQZBsDJEEiCNuPWU0PlnTN1IB4/OHipoMe839m4UOOZ3yj1PBbtLp3ZIqslhHrCoSZjk0eyu7TvaxoqX4pe0/REdv/jzy+ZP0XoDFPAhs2FyeJOp9/IK7Uf9ppO6h1fBPoty8+I/D1JNIGWRM3ImDewE+SlVFabSuS64+5akq05LolhADrHm7/TA/wDpLsmGymUn72Qri04r3NlaB7r/AAaPIE/VT7DbeWyqv/xfFm2sZa8fyA9QZ9iFR2JPZqLIejCDwvhL9TzO0rtB5eoP2J8ljnB16i2r35+TNNXG+Po8/Jnl1Q2R3rGJse7OojePVQk3jgg0m+SLqhJkkk8SZ0sLlUlTOp1C0ggwQQQeBFwUCFcZTGjmCTCgGClemGlzSQSDEtcC2xIMEfMOBBUXnJOO3HPUigRwKMkkh2lGRYyEFSiyDWC2Lqtc6WNyCBaSdAJMnib9VZn1JYA6o3Jlyd6Qc8mcsfLGkbylkfQgD+fVDWQTEUREC7TSwjQDnfjruspb1AgQzyCbCBwmfVA2BMQz6ZABIs4EjmASD6goAIqnvXnMIJNzrOp0NtUmsklNpNLzFY4gggkEXBFiDxBT69RJtdBU8AFBEMpgPTmRFzIi032sdUySeB3MIJBEEEgg6gixBUkhNm6l2a4ls2Dm5pBB7skdDIIgrRTX3ksIhKSSPTeBAa2Mo2HLiuzZdHQ0Ozz8viVx8K72XyKtqfq2AhvOLOd1081i7K0znJ32Ll8jUHjb/NLl+4zMqEy23euZAJABmxOmwtrdKc3qtXn+VFuVnPkuEK+qJLuRNuQV3assVxrj5sjZFqMYerGeYAHBt/GJ/wDZaYLutJL4EpS8U2vJYKUXWf4j0aFHsV4wQxh1G+k6SJ/Uwj/xbHssOils7QtX+4rlwrEvKR51QTTIO1+gsfQqztWKr1kZ/wBSNUZLv1/uj+h4zwRZZJdSuSwII/Os/TyVTK8DZmwREm0HSONt/wDCimNpZwgNfEi1xGgduDLTsbajnxScg5Qub80USXV5OfrrI2MRPRIJLD4FlAkg5kieeMAQROBTQsDFymTbyCUsiK0aQcHHM0ZRMEwXXAhvE3nwBVnkIiVERNrWwbmduBuNeFp9FlLWJCeBHIA5AHGPugDkAcgAFMAoAKYDNUkBalTkhrd+KnBbpYRFs9uGsaGtmdyY1Xf01KrjmRCMd7z5LqLT1DQbnU8Bv+c1xbJvX6nj2I9BblKTm/ZXQfE1RoNBYfRdrV3fhtPtj1ZOGVW5vrIjTdALpubDw/LrJoK8Rz6lm1NxghDeG8S1vSZP1WfUT7zV48lwGd1zfoitZ0n84/YLo66SjpStr8mUvVhoHuu5vd6ABPsjy/zyJTX5kDcx92co8srly1Lb2nZ8SCjmy1ES27mnckHqul25HNELF5MJPFMJ+jPFrsPD/cWXKfOGXW+pAqODOhYUGBygMr8d2TJ+kuzaCZAjXXomSQj6hIAgCJvEEzxO+m+ii2MRIQqRI5AmMExHFSySwCUsiOlSyGDpSFglKpySBKBnSgDpQB0oABQByACmAUAFMAhSQHr4SlkbJ1P5C7Gj0+3xMpzue1FM25WftXVvC09fV9SVvGKofMoywk6uv4DYLZ2dpVXFZIuKm1THoupmrPm3RYdZa9RqMLojS/FLjoh3Hb+FdRNVxz6IKv5psWmbj+UF3X8lcfRZlY5MpreIOQXbfmgW/tOS7pIdkcVRXvHoHujmXfRXdmvGCU/4sDYXWb/b/qA+q5Wo47QfxI//AKJr/OgcV85PG/1XoNXDvdHKPuIVrdROPpkwY/U/93nr9F57Tzcq1nyJLx1KRgcp59xUSKolwSAq2SQCUiSBmSA6UMDpURnIEdKkB0pgcgYYHH0UkIEc1ECCqJHIA5AHJgEIA5AHIAISAITQBUkB6GBw0d49OXNb9LRueWVzfBoJldDUahaerd5kopVRc31Y1Nsnk255nYLj6KnvJ95MrjmEXOXVjOdqV37rVTU35ltUO7hvfVkaQvPD3/PZcfRx53Mm+IY9QbeJWvWzxTjzYrfBVj1Gpj5jzA8tVVoo4QThiCiFzbjr9Eu034ooL4vMYjUWnI3+76LZouEhTi++RofOX+0+hn6LmdorGtz7kKSxq/kiuL1aeX57L0lDU62vcLTZVkomLFzAPi0/ReVqk65yh6MWnitsoejPNJVu9kXHAhVUnkAKtjAUDQISGcgZygxMCYHSmgOUhnKIHKQjkhiBirJYFQI5AHIAITA5AHIAIQAQmBpwtGbnQeq0aene8kWzY6pJXYhiCz6DrjnxMUvjxOi4V10tTbx0Ic3T56IuDlGUdfFdzSVKERP86aj5IlWqkW6/ZYe0Lu8s2ryNE5ZljyRzXwI4/n3V9EdsUJNykl5AdVg7WHqsmum5WbV5BdLNij6DU6sBthcE7/m626WPCCUsySRzq8HTbmsetm3bgLJfmIq2t3GiNjx4hbtM/Cgdn5qNDavdAjUEecrndpzxqE/ciFssahS9yHq1Q6m0xpG/h913NFY3BApbdQzPWgtcDtdcTXR7vVN+o/Z1DXqYg1hd3s0H+Etn1CqtcusfuQ1GY+yOKVHNE1Mv9kqnFrjnjP2M7nZt8s/MNOhRJMmpG3yT1SkrscY+4nZYlwl9zJUptk5SY2mJ6wrFW/MujJ+Yham4EsgMKLjglkEhRwMBPJIQJHD1TQgEpkjkgAmByQCSoEgJCOTA5ABQByYHIAIQBSjTk8t1bVHexNm0u2Gmy6dUVFYIqO54FBhY9bqH7EfmSsePChqOuboE9FTh5IS8EcIsCurdd3VbkWw/LrcmZyZd+dFxNOnOeZEalxyPN/BdVNRTfoW1rHJJxseZ91x8uU8sqhzJstN/AQuzVwsEo/xCb3a/nJcq95tZHrYWGjf6V09NxFEX/ERakbDx+q5vaPM4v3C1H8RMpRP/AAvD/P2XW0M/AhW8WqQs3HMLN2xDxRmi3UrEoyRhqiOhhYovKHYsojKZQ0MHJiwLKTBIUlRyNCEqDZNI5QGBRYjimhnJjAgDkwAlkBVAYEAFAHIA5MDkAGEAFjJMBOMdzwBsbAELoVQUVgWASpXWd3EnxFAiSAFzaouciqC82aJ2Gi7daSQo+KXJznWXP11rm1BErZbpKK6EqfFT08dqJ9OAzbxVl88Vv3lj4gK3UBYqY5kVw4Q4PuurB8MKl4sk3HX83XIm8zyRjzPJYmw/p+q6lLwkRf8AERSk6x8Vg12XKPzDU+1Eth3WcOZ91t0MvCLULoyea3gVo18N9OfQuu8VWSGIF/Fcal5WAg90cmaVYVM6U8kWAlJhgCgMEqDJHTyUQOJ5e6QAnkhNACVMYEgOTA5IBFAZyAOhABAQAYTA5ABhNIZelZX1dRDBa1hckopYywlc62bnIra3PI1NsCdz7LZp60kE+mB2rZOxQiWR/LjkZ9MkeK48VKc8shCLbchalMgLow4RZtbEJWfVSTaSCx54Gw7CSYChS1HxMrnNQjyXaGts4SeRI9IhaXKTjmLwUwdjy4vBnIMfKsK6ltRWo0iJG31XSqfQWPGjqT9o9+Sq1EopptZJXxeYsvQHeNtfHcKelkvIVq/LQnELpWLdW0W1+KrHuJ1hIBAXnY8MpqnhYIilP6Sr8ClJAdS5FNr3CTySLeRSSy8YJDjDu2HqFoehuccxWRk3CNQsUoyTw0MQqtiLYavkM5Wnk5ocPIqE4qf/AAV2Q3Lq18DQK9NzpdSbHBhLB9UtkksKX7leyaWFL68knU2F1u43h8xCn4lH1+xPfJL1+xB7QDYyOMQpRfqWReVyMHHl5LfG+Tjt4x8B7hcqrdcfUW4gsJM5ABCYBCB4GQM6ECKspwJVsI8EsFMvJaoxWB7R20HcFTdLK2ohJ+Q3wDOlgq6a35jXCC9dGHBGMcvJWkG7hZdTbnglN54LZ2cD0UKo8lm/bHGDLUAm09VqQ4LCyX/cXiDAvp3mnzg2XNnapTeDN38ZPhP6MLMHFs7PGSR4WButFc9scpMbsysKLE+EJufJa5exk2Rr8PQ10qbRo49SPqsiqT6kPw0X1RSvTB/WZj80WyuEVwiyvSqD8JGiw8/MqrUVJotsqlhF6TCX2AvGqhQ1Dlma6EYQy/Id3ZlZ7jkaXRrELZ/qNVaxKWMmKGvogvE8fFGOtgKrZmm638pjzC49l9bnlSRVDUUylxJGErX30duNq+JqUMhFQjf88UoahxfTJLu4rqVZhXuuAQdjMqb1TT3R4LqtP3nEepQ4as3UT5fUJ/6pbNY3p/Q0T7PvqWZwZnqNqE3a7o1ZbNQ5e0zMtPY+kX9DMad/uIVeclUoOLPX7N7OpHWsM3ACR63WO+6yHSPHxMeu30pOOJfDOV9gYvsSq0y0dYIClRqa5rGeRaSTvi3FdOvQ8mqwgwYnkZWvBfhEy4xE2T2oaSFCMBgb4nII59RYIqssDCYByoGdCACgZswOBe+S0SBfbwm/NW1155HGLZqrdn1G3LY6g69fFbY0TfREo88IWlg6muX2+6ruboXj4JWLu47pGv8A/PrxJYWjiRbx3XO/F155ZFU2NZjFs0VeyaoA/VPCR7wt2mnKa9lozSnOLxOOPiYqeDLouwSY7z2N9zZbLV3a5Z0atLNwzx82WPZzonNT6VqJPkHEriy1EZS5yFOitt5WDP8ADhdGuLaykV2VSjLb6F8PSqASGEj+g+8KyeILxFvc4juxwbWueB/ynT4GPULmuUG+WatGtRHxVxyvhkSuHn5mR4tMrpURysIdyk5ZsWGSoYBxvkMeBjzVl2IJqTBQjCO59CzsA+fkPQLJDUVZxuRsq00rI7lEZ+HcDBEGNwunXVu5jyPunDrgNPBu4EdCFTfjHUrureEWZhgCDJFtR48VmhJPoZ56axrG0rVqP0BDh/MBPnqrvwsJc45OFd2fVuzJYfxEfWqfK3M3kHE35ALnanTVp5lgjX2Zmazz8sHj4nODDxy+UDx2UIRjjETow0stP7aaTIimRdocOcg+yi2s4Zr7mcFvrT+wGPBPfeR4D6j7JpJGKUpuWW+T0Kbg4QHz1E+yi0kN3WPje/qZa2Di/wAWP6j9f8Ib9xXvkukmZ3Yc65gfCSjcXKqU4b5S6BBcREN8oPmhRWc5LlKdleHGOF5+ZSm4lsGoQOFyPdJwWcqJnq0NEsyctr+HUQFrbFk89PdT2Sl0Zlu01tT8L+qM7qTCd46Ke2ZXHOPH9ijMCwiQ8jxbPsVJVXN8Qz8CLVyWVHKIOwkbj1VncW/0v6Ed79GYQspoGzJgdmQByAOBQM2s7TrRAqvAAgd5wgaZRew5KxWND3MH75Umc7p4kknzV0dVZjG4cZOPQ0Ue2K7dKrvOfUrLZVG2W6fJVOtTnvbefiEdqVc2b4jsx1MmfNThXCPRGn8RYlt3DntCo75nuN5uSb8b7rXXdOPslSfi3FWdp1hpUcPAx7JzhvfjWS6d9s0lKXBZva9SQTUdI0JvHmorSaZc4NEddeljcNiO1qrxDqjiPLTwWiFndvwFTlKxpzBTxldos+oG8nPA905apTfiSb95q7iezxRe37GsdqaE1qjiLw5z7HiDKxKmE8qUEvp/Y6VN9Oniu7m37ui+qNlTtmq65rVNIvVe4EHbvGI5LpaXFK9fkjNffTY8xgl9/wBRm9vvADfj1ABo1tR4b5NMb7KOphXdy0voU2S7yOxRSXuSL0/2hrOMfGqNjRxrVYHgJKww7N08ZbpQT+RdG+2uKWM/Jf2Bje2MQ67sU98wDFR23KV3NPKlcQhj5ISlC18wX0QGftDiQI+PUi2r3GI0iTZV29nxuz4UaXOG3G1L5F6P7UVWxJzETdznk32s4W8FypdiUwt38omtSsNNL6L+wO0f2kdWAzNbI0LX1gbcviR6FdOhdx7P7HMtrqseZZT+X9hT2+9wAvbjWri3OKglczXURs5ZF03342teHz4T+fTJ5mIxIe69JkbtzVIJvJJL5m+xWKqhVrOWWajtWUK3C+Kf7fQ8fE4VzDIAjoVLh+ycWvXQ3eAi0Sbt8p9lCXBsWqpbzahalGNj1CipJlTlVKX5byasJhnjvNI6ifcKm2da4kF+moUN1s8fUocpP/FmRuwNb591VpSivy+fjk534aTeKWmvfkpUwgIllZhHAu73snG6S4nF/JG6tWUwxN/QyNAabk2/hgrWuVwbdLdSvFPI1Wu5/dbJHCBPVWV1pM06rXTuW1PK96Q37i/+Eei72i0+5Z8PzOb3b9BHsLT8seYWnUzdS8KS+GRxrkn0NLWiLgrl/jtR/UzQ4+q+yPnMi5GDAMGBAwOagQqAOQM5IBgVJAVbTJ2KmkTUJehVmGdvZTUQ7tmgYXg70W7T6eUuY9R92xXsc3UddlouhdBeKInFoWVhk8jRpwlLMfkLvAws9s9iznB0tDQ7Zey5fAfGuIOWHNHAuJCVK3Lc+feaNdNwl3aTivRvJmDlpOa2NKmmNNDtepqRapFG1FOL5LVYyzaqvi8lqmMH+K01LnxZIuYTUHNaZPT45zkrdjJuqfn+Fz7ZR/lKHIk554rHN8lbY1OvtDb7lZbOuTVVZFrY4x582JiLG5B8DKqi01kz6nSKD4afwBQL57hIPJQsjGS8RRDQO97Usmiq12tS/VZI7G8VnRq7Gr0q32R+jIPriO62OclTVOfaeSvU26aS2xrQv724cOolEqIFFOvlp1iKX0BUc83c3/xhOEorhMou7Rd090mgNq2jIPX7qzHOcly19ajhwXxL0qr2izSByBhCtin1K12hS3jC/QvQ7Uj5gPUK5XyTymbtLqqVndh/Eep2m0CGkkcI+67FHakIr8ytNjv1aisVSyvQ884z+RvkpPtKlvPdI5nfM8bMvP5KzpSAIQwbwehR7IeW5i5jRzcJ8gs71MU8dTLZq4ReEm2Y6rA0kSHRuNFenlZNMJ5WWgB44Jlyml5D/G4AIwT773Ieli3De3DZSTwNaia4zwbqeMpR3s08B90pWWfy4OhTfo8Zszn0GPaFPZh6kn2U4XaiL9oslrNGvZgSq4wu0mFu/HX4w5cGK22Nj8KFYwnY+SjC2tvxsitPY+kWa6FFo+YkK9wpksxZtoqVb8eUPVoMP/LzErNGLTe5o0XUU2L8lSbIPwbhqIW+nRStjmODm2UTr9tYE+AQrJdn3RWcFZwHFUKrDxIkmXY0cVvr0dUlneT3DZBxVj0sYcxkhg+KQn+Osr4STItCOryqLdfKa5SItknVFzp2ZK8ilyplIQ1FsmJA8dFTOW1ZNGnr3yxlL49DU+iTbLTHMELH3sfayy/XydEPHCPxiIcG8XmBxBCS1EJcI5mk1kJ2Yy4lqmGGWe8SqY3eLHB2r7dCq8u3MviZaYbPe+yvbbXhPM3bpcwJ1wJ7uiIOWPEVwjNrxjNxrwMs2S7iGc4F+GhnJnc9XlvdroXp9o1GiA6yplp65PLRTPSwk84IOrEmSroxSWC6Ne1YRow1dg+ZkqiyFjfhZVKFqeYMo6tT/gSUbfU0q2/HMI/Q8JWDOQBq7PZLr03PHBs+pVNssLh4KbZYj1wenjqmVtsMGDiSLdAs9Ucv28mSmG6XNmTxCVtR0UBSJBBQIIKQwpgFMZWlVLdE3zwW12yg8xNTMbU2Pood3DzN0NdqX0Y5dUdrJVkZRXQm3qbOZZHZiKjNCQnJRmsMnXqNRRwngrRxGYzUe5XQ1F1McVcFldsbp7tTJj4msz9BPVW09oatr8yQav8ABrijPzIUqTnm10rdX5zZRRpp3PEEGrQc0wVGOoUlmJK7SWVPEilPDPcJDSh6yMeGy2vQ3zWVFsjUpkWIUlduWUyiyiyMsNYGdg3gTlMKr8TW3jPJOXZ2ojHc48EqTATBMIlPCyjPTTGc9sngtXw+WCHB3gs8NQ58OLRr1GhVCU4TUhX4tpEFgniLJRralncyNnaFM4bJVrPqjIXKzCORKQA5GEVF6OOeLZjConTCXkZ56euTy0erh+0mgXYDxkArFZpZN8Nna7Nv0dEHG1ZMuPxVN+jADyV+nqlBeKWTPqZV2WudfT0MlPDlxgLRKaisss0+hlf7I1bBuaJIHQqNd0ZvCZZqeyr9PHdPGDNlV5z+7Y4w7tQCoOaXVl60VzWVFnMp3h0jp9EnLjK5M1kJQ6rk3NwFM/8AXH/aVm/EW/0fcqV8fPJ88tBYFIGjZR7TqMENdA8AqpUwlzIplpq5PLIV8Q9/zOJ8fsrI1xj7KLIVRh7KJhSLMBhGRpBDUZHtGyoyGxnZUBgIamPAYTBFqVUt0Q1lYNFN0q3mJpGPfy8lX3MTb/qd+PIk+sTqrlwY7L5z5YMylkq3M4FAZL0Kl7nLzF0fEvhqJQ6M9KjSbr83Mmf8I4RGWpfWTNgrEaKiddU3lmyj/qC6mO2MlgnVOb5hKtiowWIlFvaNl0t03kR1N8d14jg77rLZ3cXlorl/1HbWtmco8+rgqlzlU1qq+mTmy7UrnLJke0jVXqWS38UpdGJlTyiDtQpaeCW5EO9QpQPcmLKY8lWVIUHEpnDLyMXI2jg3HqFtUjRPb6mqGqnD2XgJruNiSU4wS6IunrrbFtlLKL0MGTrb3VigypWG1tHL8ri319FCem3dUbKu0LKfYZkxFF5MyHeFklTt4Rl1OqlfLdN8kxXqC2XT+VVOhNnNdcGzxkG0KBpBhA8DBqWSWBsqMk8BAQNIcBJstjFDBqWSarQ4pI3E1Rkb4SW4mqEXoNYPmEqE3J9GaqK6I+3HJV+KYPlYFGNcn7TLrdZRFYhAxVas7LUuDj3W7/LBKVIy5CE0GSgTyLIwRkNxtwD8rpmPbqN1n1GXHg5+s3S4PpqWOoZe80T/AC79DouJKOo3eFs4UqLt3hZ4OPxt+5DRyufMrs6ZT2+M6+lrkl4nkwMxBBmZPO6ulBSWGarKVNYPSo9uwIIlYJdnrOUznT0GXmJixuPa+4ELRRS61jJfVQ4LDFwOIaDf/dSvhKS4HbXJrg+gpmjUbcAe65Mu+qZy5K6uWep5HaOCYD3TK6GmvnJeI30Xya5PNOGJ0C2KxGpWpdRHUXDUKakn0JqxMRTSJ5HZUhPaQksj8xM+S016SyXQSyi9PFvGt/EQfMLT+Duis7SfLN2HxDXanKeenmFGL2vxIy2Tth05NJoeXEaLsafR0XrIQvUnh8Mg7KLZvZaP9Fr9S7u0fLheFNyQwQNDBImkEIJYGQNHIJFaTZUZPCL6oObwjfTwgGpWd2NnXr0cIrMpBOUaJpsbVa6CFSRU2hCFJFDiScFNGaxE3BWJmWaEhSyZ5FqVOVCUsIz22OK4PWw/ZoInN0WKeqlnCRzp6uWSGKw7W6FW02zk+Syu6yTMRetR0Es9RTUU8EtiEc5A9ouZMTAXIyLAsoI4DKRFoZtUjQlJog4pjiu7cpbSDgj1uzMW0G8dVi1VLksoxaipvoe1WpU6jbQudCdlUuTBGU4Pk+ex2CANl6HSzdiOpTc2uTA6murXpJy5SNMXkZphb6JTofiRNGluIG67VXaFUuJEs5JVXACxWPXS08o5QOK8yQxTho49FwHbKuWYsq7qIv7yVoXat6WMktj9QUMA92gEcSV5qdkYdTsUaC672UaqnZBbBJEHhx4KpaiMuEb59jWVtOb4ZCrQa1TjNsz2011cGclWGN48gSmQycCgMjByTJxscehRr0mi1XMs1yiXxsHBUS5SCgbkK5qkiifJF9lNMyWcCkKRnkEEhD5M84qRT94dxUe7j6FfcxEdVJ1UlFItjBLoiRcpotOzJgAuTECUIRyBHIIs4FAmFMicCgTGaUiLNtDEuFpUJVxfkUzri+qN9DDF+90RuVLMspqAa3Z5avUdldq1yW1olTq1kyPYOC9K4V3I3xkpLJjrUt1wtZo3FZiSwZzZcCxuDGJmVDkMEqOQP//Z" alt="img">
                <div class="venue-info">
                    <h2>Mumbai</h2>
                    <p>Grand Banquet, Chembur</p>
                    
                </div>
            </div>
            <div class="venue-box">
                <img src=" https://images.unsplash.com/photo-1614886204233-483c58f336a4?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8ZGFuY2UlMjBoYWxsfGVufDB8fDB8fHww" alt="img">
                <div class="venue-info">
                    <h2>Daman</h2>
                    <p>The Deltin,Daman</p>
                    
                </div>
            </div>
        </div>
    </section>
    <!------------------E-invitation------------------>
    <section class="invite" id="invite">
        <div class="title">
            <h1>Card<span>Design</span></h1>
            <p>Choose the best card Design.</p>
        </div>
        <div class="invitation-row">
            <div class="invitation-box">
                <img src="  https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIbxT5OxvVBFTyaqKBGaAxVJqAj9vtyA9j4T47H5VGxQ&s " alt="NO DATA FOUND">
            </div>
            <div class="invitation-box">
                <img src="https://tse2.mm.bing.net/th?id=OIP.LCv654qelFmLc86RkJTiEgHaH6&pid=Api&P=0&h=180" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://i.pinimg.com/originals/37/49/4a/37494a1f3b29bfaaea8edc5ca74bbecb.jpg " alt="">
            </div>
            <div class="invitation-box">
                <img src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/indian-dance-event-invitation-social-media-po-design-template-cea14e1e6b26a7b1dcb47d483e3e7978_screen.jpg?ts=1615804592" alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://static.vecteezy.com/system/resources/thumbnails/037/468/551/small/dance-day-social-media-stories-flat-cartoon-hand-drawn-templates-background-illustration-vector.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://images.template.net/wp-content/uploads/2018/04/Editable-Dance-Warrior-Party-Flyer-Invitation-Template.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://www.iccr.gov.in/sites/default/files/2021-10/89f2b138-96b0-4d38-8cc9-01769812c661.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src=" https://i.pinimg.com/originals/48/a4/1b/48a41bf08b965961cdbb9a9ca5f4bd53.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="  https://s3.amazonaws.com/geotix-production-uploads/uploads/e88f8bed-4260-4af7-bda6-ccbceb60b179.jpg" alt="">
            </div>
            <div class="invitation-box">
                <img src="https://christianitymalaysia.com/wp/wp-content/uploads/2013/01/Dance-Competition-Poster.jpg" alt="">
            </div>
             
        </div>
    </section>

    <!--------------------------------------------footer section--------------------------->
     
    <!--------------------------------------------book section--------------------------->
    <section class="Book" id="invite">
        
                        
         ------   
    </section>
</body>
<script>
     let menu = document.querySelector('#menu-bar');
    let head = document.querySelector('.head .navbar');

    menu.onclick = () => {
        head.classList.toggle('active');
    };

    window.onscroll = () => {
        head.classList.remove('active');
        if (window.scrollY > 60) {
            document.querySelector('#menu-bar').classList.add('active');
        } else {
            document.querySelector('#menu-bar').classList.remove('active');
        }
    };
     

    
</script>    
</html>